// Icon set — line icons, 1.6px stroke, 24x24 viewBox by default
// All icons accept { size = 18, color = 'currentColor', strokeWidth = 1.6 }
const Icon = ({ children, size = 18, color = 'currentColor', strokeWidth = 1.6, style, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke={color} strokeWidth={strokeWidth}
       strokeLinecap="round" strokeLinejoin="round"
       style={{ display: 'block', flexShrink: 0, ...style }} {...rest}>
    {children}
  </svg>
);

const I = {
  // Brand / nav
  search:  (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Icon>,
  menu:    (p) => <Icon {...p}><path d="M3 7h18M3 12h18M3 17h18"/></Icon>,
  close:   (p) => <Icon {...p}><path d="M6 6 18 18M18 6 6 18"/></Icon>,
  chevR:   (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>,
  chevL:   (p) => <Icon {...p}><path d="m15 6-6 6 6 6"/></Icon>,
  chevD:   (p) => <Icon {...p}><path d="m6 9 6 6 6-6"/></Icon>,
  chevU:   (p) => <Icon {...p}><path d="m6 15 6-6 6 6"/></Icon>,
  arrowR:  (p) => <Icon {...p}><path d="M5 12h14M13 6l6 6-6 6"/></Icon>,
  arrowUR: (p) => <Icon {...p}><path d="M7 17 17 7M9 7h8v8"/></Icon>,
  plus:    (p) => <Icon {...p}><path d="M12 5v14M5 12h14"/></Icon>,
  minus:   (p) => <Icon {...p}><path d="M5 12h14"/></Icon>,
  check:   (p) => <Icon {...p}><path d="m5 12 5 5 9-11"/></Icon>,
  filter:  (p) => <Icon {...p}><path d="M3 6h18M6 12h12M10 18h4"/></Icon>,
  grid:    (p) => <Icon {...p}><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></Icon>,
  list:    (p) => <Icon {...p}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></Icon>,
  map:     (p) => <Icon {...p}><path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z"/><path d="M9 4v14M15 6v14"/></Icon>,
  pin:     (p) => <Icon {...p}><path d="M12 21s-7-7.5-7-12a7 7 0 1 1 14 0c0 4.5-7 12-7 12Z"/><circle cx="12" cy="9" r="2.5"/></Icon>,
  heart:   (p) => <Icon {...p}><path d="M12 20s-7-4.5-7-10a4.5 4.5 0 0 1 8.5-2A4.5 4.5 0 0 1 22 10c0 5.5-7 10-7 10Z" transform="translate(-1.5 0)"/></Icon>,
  heartFill: (p) => <Icon {...p} fill={p.color || 'currentColor'} strokeWidth={0}><path d="M12 20s-7-4.5-7-10a4.5 4.5 0 0 1 8.5-2A4.5 4.5 0 0 1 22 10c0 5.5-7 10-7 10Z" transform="translate(-1.5 0)"/></Icon>,
  bookmark: (p) => <Icon {...p}><path d="M6 4h12v17l-6-4-6 4V4Z"/></Icon>,
  share:   (p) => <Icon {...p}><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="m8 11 8-5M8 13l8 5"/></Icon>,
  star:    (p) => <Icon {...p}><path d="m12 3 2.6 6 6.4.6-4.9 4.3 1.5 6.3L12 17l-5.6 3.2 1.5-6.3L3 9.6 9.4 9 12 3Z"/></Icon>,
  starFill: (p) => <Icon {...p} fill={p.color || 'currentColor'}><path d="m12 3 2.6 6 6.4.6-4.9 4.3 1.5 6.3L12 17l-5.6 3.2 1.5-6.3L3 9.6 9.4 9 12 3Z"/></Icon>,

  // Property amenities
  bed:     (p) => <Icon {...p}><path d="M3 18v-7a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v7M3 14h18M3 18v2M21 18v2M7 11h3v-1a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1Z"/></Icon>,
  bath:    (p) => <Icon {...p}><path d="M3 12h18v3a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5v-3ZM6 12V6a2 2 0 0 1 4 0M21 19l-1 2M3 19l1 2"/></Icon>,
  ruler:   (p) => <Icon {...p}><path d="M3 8h18l-2 12H5L3 8Z"/><path d="M8 8v3M12 8v4M16 8v3"/></Icon>,
  parking: (p) => <Icon {...p}><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M10 17V8h3a3 3 0 0 1 0 6h-3"/></Icon>,
  pool:    (p) => <Icon {...p}><path d="M2 16q2 1.5 4 0t4 0 4 0 4 0 4 0M2 20q2 1.5 4 0t4 0 4 0 4 0 4 0M7 14V6a2 2 0 0 1 4 0v8M13 14V6a2 2 0 0 1 4 0v8M7 9h10M7 12h10"/></Icon>,
  gym:     (p) => <Icon {...p}><path d="M3 10v4M21 10v4M6 7v10M18 7v10M6 12h12"/></Icon>,
  wifi:    (p) => <Icon {...p}><path d="M5 12.5a10 10 0 0 1 14 0M8 16a6 6 0 0 1 8 0"/><circle cx="12" cy="19" r="1" fill="currentColor"/></Icon>,
  building: (p) => <Icon {...p}><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16M3 21h18M9 7h.01M15 7h.01M9 11h.01M15 11h.01M9 15h.01M15 15h.01M10 21v-4h4v4"/></Icon>,
  buildings: (p) => <Icon {...p}><path d="M3 21V9l5-3v15M21 21V11l-5-3M3 21h18M8 12h.01M8 16h.01M13 14h.01M16 14h.01M16 18h.01"/></Icon>,
  garden:  (p) => <Icon {...p}><path d="M12 22V12M8 12c0-2 2-4 4-4s4 2 4 4M9 7c0-2 1.5-3 3-3s3 1 3 3M5 16h14"/></Icon>,
  sun:     (p) => <Icon {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/></Icon>,
  wave:    (p) => <Icon {...p}><path d="M2 8q2 2 4.5 2T11 8t4.5-2T20 8t2 0M2 12q2 2 4.5 2T11 12t4.5-2T20 12t2 0M2 16q2 2 4.5 2T11 16t4.5-2T20 16t2 0"/></Icon>,
  key:     (p) => <Icon {...p}><circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M16 7l3 3M14 9l3 3"/></Icon>,
  shield:  (p) => <Icon {...p}><path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10Z"/></Icon>,

  // CRM / admin
  inbox:   (p) => <Icon {...p}><path d="M3 13h5l1 3h6l1-3h5M5 5h14l2 8v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6Z"/></Icon>,
  pipe:    (p) => <Icon {...p}><rect x="3" y="4" width="5" height="16" rx="1"/><rect x="10" y="4" width="5" height="12" rx="1"/><rect x="17" y="4" width="4" height="8" rx="1"/></Icon>,
  calendar:(p) => <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></Icon>,
  user:    (p) => <Icon {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></Icon>,
  users:   (p) => <Icon {...p}><circle cx="9" cy="8" r="3.5"/><circle cx="17" cy="9" r="2.5"/><path d="M2 21a7 7 0 0 1 14 0M16 21a5 5 0 0 1 6-4.5"/></Icon>,
  bell:    (p) => <Icon {...p}><path d="M6 16V11a6 6 0 0 1 12 0v5l2 3H4l2-3ZM10 21h4"/></Icon>,
  trend:   (p) => <Icon {...p}><path d="m3 17 6-6 4 4 8-9M15 6h6v6"/></Icon>,
  chart:   (p) => <Icon {...p}><path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/></Icon>,
  pie:     (p) => <Icon {...p}><path d="M12 3v9l8 5a9 9 0 1 1-8-14Z"/></Icon>,
  phone:   (p) => <Icon {...p}><path d="M5 4h4l2 5-3 2a12 12 0 0 0 5 5l2-3 5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"/></Icon>,
  mail:    (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></Icon>,
  whatsapp:(p) => <Icon {...p}><path d="M21 12a9 9 0 1 1-4.6-7.8L21 3l-1.2 4.6A9 9 0 0 1 21 12Z"/><path d="M8.5 8.5q0 2 1.5 3.5t3.5 1.5l1.5-1.5-2-1-1 .5q-1-.5-2-1.5l.5-1-1-2-1.5 1.5Z"/></Icon>,
  line:    (p) => <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="5"/><path d="M7 11.5q0 1.5 1.5 2.5t3.5 1l-1 2 4-3.5q1 0 1.5-.5T17 11.5q0-1.5-1.5-2.5T12 8.5q-2 0-3.5 1T7 11.5Z"/></Icon>,
  copy:    (p) => <Icon {...p}><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></Icon>,
  edit:    (p) => <Icon {...p}><path d="M14 4l6 6L9 21H3v-6L14 4Z"/></Icon>,
  trash:   (p) => <Icon {...p}><path d="M4 7h16M9 7V4h6v3M6 7v13a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7M10 11v7M14 11v7"/></Icon>,
  more:    (p) => <Icon {...p}><circle cx="6" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="18" cy="12" r="1.4" fill="currentColor"/></Icon>,
  download:(p) => <Icon {...p}><path d="M12 3v13m-5-5 5 5 5-5M5 21h14"/></Icon>,
  upload:  (p) => <Icon {...p}><path d="M12 21V8m-5 5 5-5 5 5M5 3h14"/></Icon>,
  cog:     (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5.6 5.6 4.2 4.2M19.8 19.8l-1.4-1.4M5.6 18.4l-1.4 1.4M19.8 4.2l-1.4 1.4"/></Icon>,
  logout:  (p) => <Icon {...p}><path d="M14 4h5a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5M10 17l5-5-5-5M15 12H3"/></Icon>,
  globe:   (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Icon>,
  flag:    (p) => <Icon {...p}><path d="M5 22V4l8 2 6-2v12l-6 2-8-2"/></Icon>,
  fire:    (p) => <Icon {...p}><path d="M12 22c-4 0-7-3-7-7 0-3 2-5 3-7 0 2 2 3 3 3 0-3-1-5 1-8 1 3 7 6 7 12 0 4-3 7-7 7Z"/></Icon>,
  clock:   (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></Icon>,
  document:(p) => <Icon {...p}><path d="M6 3h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M14 3v5h5M8 13h8M8 17h6"/></Icon>,
  camera:  (p) => <Icon {...p}><path d="M3 8h4l2-3h6l2 3h4v11H3V8Z"/><circle cx="12" cy="13" r="3.5"/></Icon>,
  calc:    (p) => <Icon {...p}><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h8"/></Icon>,
  sparkle: (p) => <Icon {...p}><path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M6 18l3-3M15 9l3-3"/></Icon>,
  compare: (p) => <Icon {...p}><path d="M12 3v18M7 7l-4 4 4 4M17 7l4 4-4 4"/></Icon>,
  info:    (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/></Icon>,
  warning: (p) => <Icon {...p}><path d="M12 3 2 21h20L12 3ZM12 10v5M12 18h.01"/></Icon>,
  flame:   (p) => <Icon {...p}><path d="M12 22c-4.5 0-7-3-7-7s2-5 4-7c0 1 2 3 3 3 0-3-1-6 0-9 4 6 7 7 7 13 0 4-3 7-7 7Z"/></Icon>,
  thb:     (p) => <Icon {...p}><path d="M9 4v16M9 4h4a3 3 0 0 1 0 6H9M9 10h5a3 3 0 0 1 0 6H9M11 2v3M11 19v3"/></Icon>,
  swap:    (p) => <Icon {...p}><path d="M3 8h14l-3-3M21 16H7l3 3"/></Icon>,
  refresh: (p) => <Icon {...p}><path d="M4 12a8 8 0 0 1 13.5-5.8L21 9M3 15l3.5 2.8A8 8 0 0 0 20 12M21 3v6h-6M3 21v-6h6"/></Icon>,
  external:(p) => <Icon {...p}><path d="M15 3h6v6M10 14 21 3M14 5H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9"/></Icon>,
  layers:  (p) => <Icon {...p}><path d="m12 3 9 5-9 5-9-5 9-5ZM3 13l9 5 9-5M3 18l9 5 9-5"/></Icon>,
  tag:     (p) => <Icon {...p}><path d="M3 12V4h8l10 10-8 8L3 12ZM7 8h.01"/></Icon>,
  receipt: (p) => <Icon {...p}><path d="M5 3v18l3-2 3 2 3-2 3 2 3-2V3H5ZM9 8h6M9 12h6M9 16h4"/></Icon>,
  badge:   (p) => <Icon {...p}><circle cx="12" cy="9" r="6"/><path d="m9 14-2 7 5-3 5 3-2-7"/></Icon>,
};

window.I = I;
