// ─────────────────────────────────────────────────────────────
// Admin: Lead Pipeline (Kanban)
// ─────────────────────────────────────────────────────────────
function LeadPipeline({ goto }) {
  const [sort, setSort] = React.useState('score');
  const stages = [
    { id: 'new',          label: 'New',         color: '#3a5d8a' },
    { id: 'qualified',    label: 'Qualified',   color: 'var(--amber)' },
    { id: 'viewing',      label: 'Viewing',     color: 'var(--teal)' },
    { id: 'negotiating',  label: 'Negotiating', color: 'var(--coral-2)' },
    { id: 'follow-up',    label: 'Follow-up',   color: 'var(--champagne-2)' },
    { id: 'won',          label: 'Won',         color: 'var(--green)' },
  ];

  return (
    <AdminShell
      active="pipeline"
      onNav={(k) => goto && goto(`admin-${k}`)}
      title="Lead pipeline"
      subtitle={`${LEADS.length} active leads · ฿324M pipeline value · drag cards to update stage`}
      actions={
        <>
          <span className="seg">
            <button className="is-active">Pipeline</button>
            <button>Table</button>
          </span>
          <select className="select" style={{ width: 160, height: 34 }} value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="score">Sort: Score</option>
            <option value="value">Sort: Value</option>
            <option value="age">Sort: Age</option>
          </select>
        </>
      }
    >
      {/* Filter bar */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
        <input className="input" placeholder="Search by name, country, project…" style={{ width: 320, height: 36 }}/>
        <Chip2 label="All agents"/>
        <Chip2 label="All countries"/>
        <Chip2 label="All sources"/>
        <Chip2 label="Budget: any"/>
        <Chip2 label="Priority: Hot only" active/>
        <Chip2 label="Last 30d"/>
        <button className="btn btn-sm btn-ghost" style={{ marginLeft: 'auto' }}><I.download size={13}/> Export</button>
      </div>

      {/* Kanban */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12, alignItems: 'start' }}>
        {stages.map(stage => {
          const items = LEADS.filter(l => l.stage === stage.id);
          const totalValue = items.reduce((s, l) => s + l.value, 0);
          return (
            <div key={stage.id} className="kcol">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 2px' }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: stage.color }}/>
                <span style={{ fontSize: 13, fontWeight: 500 }}>{stage.label}</span>
                <span style={{ fontSize: 11, color: 'var(--ink-4)' }}>{items.length}</span>
                <button style={{ marginLeft: 'auto', background: 'transparent', border: 0, color: 'var(--ink-4)', cursor: 'pointer' }}><I.more size={13}/></button>
              </div>
              <div style={{ padding: '0 2px 8px', fontSize: 11, color: 'var(--ink-4)' }} className="t-mono">
                ฿{(totalValue / 1_000_000).toFixed(1)}M total
              </div>
              {items.map(l => <KanbanCard key={l.id} l={l} onOpen={() => goto && goto('admin-lead', l.id)}/>)}
              <button style={{ padding: '8px', background: 'transparent', border: '1px dashed var(--line)', borderRadius: 8, color: 'var(--ink-4)', fontSize: 12, cursor: 'pointer' }}>
                <I.plus size={11} style={{ display: 'inline', verticalAlign: -2 }}/> Add lead
              </button>
            </div>
          );
        })}
      </div>
    </AdminShell>
  );
}

function Chip2({ label, active, onClick }) {
  return (
    <button onClick={onClick} style={{ height: 32, padding: '0 12px', borderRadius: 999, border: '1px solid ' + (active ? 'var(--ink)' : 'var(--line)'), background: active ? 'var(--ink)' : 'var(--paper)', color: active ? 'var(--bone)' : 'var(--ink-2)', fontSize: 12.5, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      {label} <I.chevD size={11}/>
    </button>
  );
}

function KanbanCard({ l, onOpen }) {
  const isHot = l.priority === 'hot';
  return (
    <div onClick={onOpen} style={{ background: 'var(--paper)', borderRadius: 10, padding: 12, border: '1px solid var(--line-soft)', cursor: 'grab', position: 'relative' }} className="lift">
      {isHot && <span style={{ position: 'absolute', top: 0, left: 0, width: 3, height: '100%', background: 'var(--coral)', borderRadius: '10px 0 0 10px' }}/>}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="avatar avatar-sm" style={{ background: 'var(--sand)', fontSize: 10 }}>{l.name.split(' ').map(s => s[0]).join('').slice(0, 2)}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {l.name} <CountryFlag c={l.country}/>
          </div>
          <div style={{ fontSize: 10, color: 'var(--ink-4)' }}>{l.id}</div>
        </div>
        {isHot && <I.flame size={13} color="var(--coral)"/>}
      </div>
      <div style={{ marginTop: 8, fontSize: 11.5, color: 'var(--ink-3)' }}>{l.interest}</div>
      <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 12, fontWeight: 500, fontFamily: 'var(--font-display)' }} className="t-num">฿{(l.value / 1_000_000).toFixed(1)}M</span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 10, color: 'var(--ink-4)' }}>
          <span style={{ width: 28, height: 4, background: 'var(--line-soft)', borderRadius: 99, overflow: 'hidden' }}>
            <span style={{ display: 'block', width: `${l.score}%`, height: '100%', background: l.score > 80 ? 'var(--coral)' : l.score > 60 ? 'var(--champagne)' : 'var(--ink-4)' }}/>
          </span>
          {l.score}
        </span>
      </div>
      <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 4, paddingTop: 8, borderTop: '1px solid var(--line-soft)' }}>
        <span style={{ fontSize: 10, color: 'var(--ink-4)' }}>{l.last}</span>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 3 }}>
          <button style={iconBtn('#25D366')} onClick={(e) => e.stopPropagation()}><I.whatsapp size={10}/></button>
          <button style={iconBtn('#06C755')} onClick={(e) => e.stopPropagation()}><I.line size={10}/></button>
          <button style={iconBtn('var(--coral)')} onClick={(e) => e.stopPropagation()}><I.phone size={10}/></button>
        </div>
      </div>
    </div>
  );
}

window.LeadPipeline = LeadPipeline;
