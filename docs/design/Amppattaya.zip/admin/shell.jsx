// ─────────────────────────────────────────────────────────────
// Admin: shared sidebar shell + dashboard data
// ─────────────────────────────────────────────────────────────

// Mock leads
const LEADS = [
  { id: 'L-1042', name: 'Sven Larsson',     country: 'SE', lang: 'EN', source: 'Google Ads',   stage: 'qualified',  priority: 'hot',     budget: '15M', interest: 'Skyharbor 2BR', last: '2 hrs ago',  channel: 'whatsapp', agent: 'a2', score: 92, value: 14_800_000, age: 4 },
  { id: 'L-1041', name: 'Anna Markova',     country: 'RU', lang: 'RU', source: 'Referral',     stage: 'viewing',    priority: 'hot',     budget: '40M',  interest: 'Penthouse Wongamat', last: '12m ago',  channel: 'line', agent: 'a3', score: 88, value: 39_500_000, age: 7 },
  { id: 'L-1040', name: 'Lin Wei',          country: 'CN', lang: 'CN', source: 'WeChat',       stage: 'negotiating',priority: 'hot',     budget: '8M',   interest: 'Jomtien 1BR',    last: '1 hr ago',   channel: 'whatsapp', agent: 'a5', score: 84, value: 7_100_000, age: 12 },
  { id: 'L-1039', name: 'David Wong',       country: 'SG', lang: 'EN', source: 'Direct',       stage: 'qualified',  priority: 'warm',    budget: '12M',  interest: '2BR Wongamat',   last: '4 hrs ago',  channel: 'email', agent: 'a2', score: 76, value: 11_500_000, age: 2 },
  { id: 'L-1038', name: 'Khun Nattapong',  country: 'TH', lang: 'TH', source: 'Walk-in',       stage: 'won',        priority: 'won',     budget: '6M',   interest: 'Studio Central',  last: '1 day ago',  channel: 'phone', agent: 'a4', score: 100, value: 5_900_000, age: 18 },
  { id: 'L-1037', name: 'Marcus Schmidt',   country: 'DE', lang: 'EN', source: 'Property portal', stage: 'new',     priority: 'new',     budget: '20M',  interest: 'Pratumnak Villa', last: 'Just now',   channel: 'whatsapp', agent: 'a1', score: 68, value: 28_500_000, age: 0 },
  { id: 'L-1036', name: 'Andrew Phillips',  country: 'UK', lang: 'EN', source: 'Email campaign', stage: 'follow-up',priority: 'warm',    budget: '5M',   interest: 'Studio Jomtien',  last: '3 days ago', channel: 'email', agent: 'a4', score: 55, value: 4_650_000, age: 26 },
  { id: 'L-1035', name: 'Yulia Petrova',    country: 'RU', lang: 'RU', source: 'Instagram',    stage: 'viewing',    priority: 'warm',    budget: '7M',   interest: '1BR Jomtien',     last: '5 hrs ago',  channel: 'whatsapp', agent: 'a3', score: 71, value: 6_800_000, age: 9 },
  { id: 'L-1034', name: 'Chen Hua',         country: 'CN', lang: 'CN', source: 'WeChat',       stage: 'new',        priority: 'new',     budget: '30M',  interest: 'Penthouse Pratumnak', last: '30m ago', channel: 'line', agent: 'a5', score: 80, value: 28_900_000, age: 1 },
  { id: 'L-1033', name: 'Pierre Dubois',    country: 'FR', lang: 'EN', source: 'Direct',       stage: 'lost',       priority: 'lost',    budget: '4M',   interest: 'Studio',           last: '2 weeks',    channel: 'email', agent: 'a1', score: 30, value: 3_200_000, age: 45 },
  { id: 'L-1032', name: 'Igor Volkov',      country: 'RU', lang: 'RU', source: 'Referral',     stage: 'qualified',  priority: 'warm',    budget: '18M',  interest: 'Villa Bang Saray', last: '6 hrs ago',  channel: 'whatsapp', agent: 'a3', score: 73, value: 18_900_000, age: 5 },
  { id: 'L-1031', name: 'Khun Apinya',     country: 'TH', lang: 'TH', source: 'Walk-in',       stage: 'follow-up',  priority: 'warm',    budget: '10M',  interest: 'Sea-view 2BR',     last: '1 day ago',  channel: 'phone', agent: 'a4', score: 65, value: 9_800_000, age: 14 },
];

// Mock viewings
const VIEWINGS = [
  { id: 'V-301', leadId: 'L-1042', date: '2026-05-22', time: '10:00', project: 'Skyharbor Residences', unit: 'Tower A · 28-12', agent: 'a2', status: 'confirmed' },
  { id: 'V-302', leadId: 'L-1041', date: '2026-05-22', time: '14:00', project: 'Skyharbor Residences', unit: 'Tower B · 41-04', agent: 'a3', status: 'confirmed' },
  { id: 'V-303', leadId: 'L-1040', date: '2026-05-23', time: '11:00', project: 'Jomtien Bay Tower',    unit: 'Tower A · 18-22', agent: 'a5', status: 'pending' },
  { id: 'V-304', leadId: 'L-1035', date: '2026-05-23', time: '15:30', project: 'Jomtien Bay Tower',    unit: 'Tower B · 09-14', agent: 'a3', status: 'confirmed' },
  { id: 'V-305', leadId: 'L-1039', date: '2026-05-24', time: '10:00', project: 'Skyharbor Residences', unit: 'Tower A · 22-08', agent: 'a2', status: 'confirmed' },
  { id: 'V-306', leadId: 'L-1032', date: '2026-05-24', time: '16:00', project: 'Pratumnak Villas',     unit: 'Villa 06',         agent: 'a3', status: 'pending' },
];

window.LEADS = LEADS;
window.VIEWINGS = VIEWINGS;

// ─── Sidebar nav ───
function AdminShell({ active, onNav, children, title, subtitle, actions }) {
  return (
    <div className="frame" style={{ background: 'var(--paper-warm)', display: 'flex' }}>
      {/* Sidebar */}
      <aside style={{ width: 248, background: 'var(--paper)', borderRight: '1px solid var(--line-soft)', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
        <div style={{ padding: '20px 18px 16px' }}>
          <Logo size={18}/>
        </div>
        <div style={{ padding: '8px 14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderRadius: 8, background: 'var(--paper-warm)', border: '1px solid var(--line-soft)' }}>
            <I.search size={14} color="var(--ink-4)"/>
            <span style={{ fontSize: 12, color: 'var(--ink-4)', flex: 1 }}>Search…</span>
            <span className="kbd">⌘K</span>
          </div>
        </div>
        <nav style={{ padding: '12px 12px', flex: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
          <div style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '10px 12px 6px' }}>Workspace</div>
          {[
            { id: 'dashboard', i: I.grid, label: 'Dashboard', badge: '' },
            { id: 'pipeline',  i: I.pipe, label: 'Lead pipeline', badge: '12' },
            { id: 'leads',     i: I.inbox, label: 'All leads', badge: '348' },
            { id: 'viewings',  i: I.calendar, label: 'Viewings', badge: '6' },
            { id: 'follow',    i: I.bell, label: 'Follow-ups', badge: '4' },
          ].map(n => <NavItem key={n.id} active={active === n.id} onClick={() => onNav && onNav(n.id)} {...n}/>)}

          <div style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '18px 12px 6px' }}>Inventory</div>
          {[
            { id: 'properties', i: I.building, label: 'Properties', badge: '184' },
            { id: 'projects',   i: I.buildings, label: 'Projects', badge: '8' },
            { id: 'approval',   i: I.document, label: 'Content approval', badge: '3' },
          ].map(n => <NavItem key={n.id} active={active === n.id} onClick={() => onNav && onNav(n.id)} {...n}/>)}

          <div style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '18px 12px 6px' }}>Insights</div>
          {[
            { id: 'marketing', i: I.trend, label: 'Marketing', badge: '' },
            { id: 'reports',   i: I.chart, label: 'Reports', badge: '' },
          ].map(n => <NavItem key={n.id} active={active === n.id} onClick={() => onNav && onNav(n.id)} {...n}/>)}
        </nav>
        <div style={{ padding: '12px 14px', borderTop: '1px solid var(--line-soft)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8 }}>
            <img src={AGENTS[0].avatar} style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{AGENTS[0].name}</div>
              <div style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>Senior Advisor</div>
            </div>
            <button style={{ background: 'transparent', border: 0, color: 'var(--ink-4)' }}><I.cog size={14}/></button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="scroll-y" style={{ flex: 1, height: '100%', overflowY: 'auto' }}>
        {/* Top bar */}
        <header style={{ padding: '22px 32px', borderBottom: '1px solid var(--line-soft)', background: 'var(--paper)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5 }}>
          <div>
            <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 30, letterSpacing: '-0.015em', lineHeight: 1, fontWeight: 400 }}>{title}</h1>
            {subtitle && <p style={{ margin: '6px 0 0', fontSize: 13, color: 'var(--ink-4)' }}>{subtitle}</p>}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {actions}
            <button style={{ width: 36, height: 36, borderRadius: 999, background: 'var(--paper-warm)', border: '1px solid var(--line-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              <I.bell size={15}/>
              <span style={{ position: 'absolute', top: 4, right: 4, width: 7, height: 7, borderRadius: '50%', background: 'var(--coral)' }}/>
            </button>
            <button className="btn btn-sm btn-paper"><I.plus size={13}/> New lead</button>
          </div>
        </header>
        <div style={{ padding: '24px 32px 40px' }}>{children}</div>
      </main>
    </div>
  );
}

function NavItem({ active, onClick, i: Ic, label, badge }) {
  return (
    <button onClick={onClick} className={`snav ${active ? 'is-active' : ''}`} style={{ width: '100%', border: 0, textAlign: 'left' }}>
      <Ic size={15}/>{label}
      {badge !== '' && <span className="snav-badge">{badge}</span>}
    </button>
  );
}

// ─── Status badge ───
function StageBadge({ stage }) {
  const map = {
    new:         { l: 'New',        c: 'blue' },
    qualified:   { l: 'Qualified',  c: 'amber' },
    viewing:     { l: 'Viewing',    c: 'teal' },
    negotiating: { l: 'Negotiating',c: 'coral' },
    'follow-up': { l: 'Follow-up',  c: 'champagne' },
    won:         { l: 'Won',        c: 'green' },
    lost:        { l: 'Lost',       c: 'red' },
  };
  const v = map[stage] || { l: stage, c: 'paper' };
  const cmap = { blue: 'tag-blue', amber: 'tag-amber', teal: 'tag-teal', coral: 'tag-coral', champagne: 'tag-champagne', green: 'tag-green', red: 'tag-red', paper: 'tag-paper' };
  return <span className={`tag ${cmap[v.c]}`}>{v.l}</span>;
}

function PriorityDot({ p }) {
  const c = p === 'hot' ? 'var(--coral)' : p === 'warm' ? 'var(--champagne)' : p === 'won' ? 'var(--green)' : p === 'lost' ? 'var(--ink-4)' : 'var(--blue)';
  return <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--ink-3)' }}>
    <span style={{ width: 7, height: 7, borderRadius: '50%', background: c }}/>{p.charAt(0).toUpperCase() + p.slice(1)}
  </span>;
}

function CountryFlag({ c }) {
  const map = { SE:'🇸🇪',RU:'🇷🇺',CN:'🇨🇳',SG:'🇸🇬',TH:'🇹🇭',DE:'🇩🇪',UK:'🇬🇧',FR:'🇫🇷',US:'🇺🇸' };
  return <span style={{ fontSize: 14 }}>{map[c] || '🌐'}</span>;
}

Object.assign(window, { AdminShell, NavItem, StageBadge, PriorityDot, CountryFlag, LEADS, VIEWINGS });
