// ─────────────────────────────────────────────────────────────
// Admin: Dashboard Overview
// ─────────────────────────────────────────────────────────────
function AdminDashboard({ goto }) {
  const [period, setPeriod] = React.useState('7d');
  return (
    <AdminShell
      active="dashboard"
      onNav={(k) => goto && goto(`admin-${k}`)}
      title="Good morning, Apinya"
      subtitle="3 hot leads need a reply · 6 viewings this week · ฿4.2M closed yesterday"
      actions={
        <span className="seg">
          {['Today', '7d', '30d', 'YTD'].map(k => <button key={k} className={period === k.toLowerCase() ? 'is-active' : ''} onClick={() => setPeriod(k.toLowerCase())}>{k}</button>)}
        </span>
      }
    >
      {/* KPI tiles */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        <KPI title="New leads" value="48" delta="+12%" tone="good" sparkline={[12, 18, 14, 22, 19, 24, 28]}/>
        <KPI title="Qualified rate" value="62%" delta="+4 pp" tone="good" sparkline={[55, 58, 60, 58, 61, 62, 62]}/>
        <KPI title="Viewings booked" value="14" delta="+3" tone="good" sparkline={[8, 10, 12, 11, 13, 14, 14]}/>
        <KPI title="Pipeline value" value="฿324M" delta="+฿28M" tone="good" sparkline={[280, 285, 295, 300, 305, 318, 324]}/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 20, marginTop: 24 }}>
        {/* Lead funnel + chart */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Pipeline funnel</h3>
              <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>Conversion rate: new → won is 11.4%, up from 8.2% last quarter.</p>
            </div>
            <button className="btn btn-sm btn-ghost">View full funnel <I.arrowR size={12}/></button>
          </div>

          <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              ['New',          410, '#3a5d8a', '100%'],
              ['Qualified',    254, '#4d7c98', '62%'],
              ['Viewing',      168, '#6da08f', '41%'],
              ['Negotiating',   82, 'var(--coral-2)', '20%'],
              ['Won',           47, 'var(--green)', '11.4%'],
            ].map(([l, v, c, pct], i, arr) => {
              const width = (v / arr[0][1]) * 100;
              return (
                <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                  <div style={{ width: 100, fontSize: 13, color: 'var(--ink-3)' }}>{l}</div>
                  <div style={{ flex: 1, position: 'relative' }}>
                    <div style={{ width: `${width}%`, height: 36, background: c, borderRadius: 6, display: 'flex', alignItems: 'center', paddingLeft: 14, color: '#fff', fontSize: 13, fontWeight: 500 }}>
                      {v} leads
                    </div>
                  </div>
                  <div style={{ width: 60, fontSize: 12, color: 'var(--ink-3)', textAlign: 'right' }} className="t-mono">{pct}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Source breakdown */}
        <div className="card" style={{ padding: 24 }}>
          <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Top lead sources</h3>
          <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>This {period}</p>
          <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              ['Google Ads',     142, '34%', '#4a90e2'],
              ['WhatsApp inbound', 88, '21%', '#25D366'],
              ['Referrals',       72, '17%', 'var(--champagne)'],
              ['Property portals',58, '14%', 'var(--coral)'],
              ['WeChat / LINE',   34, '8%',  '#06C755'],
              ['Walk-in',         16, '4%',  'var(--ink-4)'],
            ].map(([n, v, p, c]) => (
              <div key={n}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 5 }}>
                  <span>{n}</span>
                  <span className="t-mono">{v} <span style={{ color: 'var(--ink-4)' }}>· {p}</span></span>
                </div>
                <div className="progress" style={{ height: 6 }}><div style={{ width: p, background: c }}/></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 20, marginTop: 20 }}>
        {/* Hot leads */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Needs reply now</h3>
              <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>SLA: 30 minutes · {LEADS.filter(l => l.priority === 'hot').length} hot leads waiting</p>
            </div>
            <button className="btn btn-sm btn-paper">View all <I.arrowR size={12}/></button>
          </div>
          <table className="tbl" style={{ marginTop: 18 }}>
            <thead>
              <tr><th>Lead</th><th>Interest</th><th>Score</th><th>Channel</th><th>Last contact</th><th></th></tr>
            </thead>
            <tbody>
              {LEADS.filter(l => l.priority === 'hot' || l.priority === 'new').slice(0, 5).map(l => (
                <tr key={l.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span className="avatar avatar-sm" style={{ background: 'var(--sand)' }}>{l.name.split(' ').map(s => s[0]).join('').slice(0, 2)}</span>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{l.name} <CountryFlag c={l.country}/></div>
                        <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{l.id} · budget {l.budget}</div>
                      </div>
                    </div>
                  </td>
                  <td>{l.interest}</td>
                  <td>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ width: 44, height: 6, background: 'var(--line-soft)', borderRadius: 99, overflow: 'hidden' }}>
                        <div style={{ width: `${l.score}%`, height: '100%', background: l.score > 80 ? 'var(--coral)' : l.score > 60 ? 'var(--champagne)' : 'var(--ink-4)' }}/>
                      </div>
                      <span style={{ fontSize: 11.5, fontFamily: 'var(--font-mono)' }}>{l.score}</span>
                    </span>
                  </td>
                  <td>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12.5 }}>
                      {l.channel === 'whatsapp' && <I.whatsapp size={13} color="#25D366"/>}
                      {l.channel === 'line' && <I.line size={13} color="#06C755"/>}
                      {l.channel === 'email' && <I.mail size={13}/>}
                      {l.channel === 'phone' && <I.phone size={13}/>}
                      {l.channel}
                    </span>
                  </td>
                  <td style={{ fontSize: 12, color: 'var(--ink-3)' }}>{l.last}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'end' }}>
                      <button title="WhatsApp" style={iconBtn('#25D366')}><I.whatsapp size={12}/></button>
                      <button title="LINE" style={iconBtn('#06C755')}><I.line size={12}/></button>
                      <button title="Call" style={iconBtn('var(--coral)')}><I.phone size={12}/></button>
                      <button className="btn btn-sm btn-paper" style={{ height: 28 }}>Open <I.arrowR size={11}/></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Today's viewings */}
        <div className="card" style={{ padding: 24 }}>
          <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Today's viewings</h3>
          <p style={{ margin: '4px 0 18px', fontSize: 12, color: 'var(--ink-4)' }}>22 May 2026 · 6 scheduled</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {VIEWINGS.slice(0, 4).map(v => {
              const lead = LEADS.find(l => l.id === v.leadId);
              return (
                <div key={v.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', background: 'var(--paper-warm)', borderRadius: 10 }}>
                  <div style={{ width: 50, textAlign: 'center', fontFamily: 'var(--font-mono)', flexShrink: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{v.time}</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lead?.name || 'Lead'} <CountryFlag c={lead?.country}/></div>
                    <div style={{ fontSize: 11, color: 'var(--ink-4)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{v.unit}</div>
                  </div>
                  <span className={`tag tag-${v.status === 'confirmed' ? 'green' : 'amber'} tag-sm`}>{v.status}</span>
                </div>
              );
            })}
          </div>
          <button className="btn btn-paper btn-block" style={{ marginTop: 14 }}><I.calendar size={14}/> Open calendar</button>
        </div>
      </div>

      {/* Follow-up reminders + recent activity */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: 20 }}>
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Follow-up reminders</h3>
            <span className="tag tag-coral">4 overdue</span>
          </div>
          <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { lead: 'Sven Larsson',     time: 'Was due 2h ago', action: 'Send floor plan for Skyharbor 2BR', overdue: true },
              { lead: 'Anna Markova',     time: 'Due in 1h',      action: 'Confirm pickup for viewing',          overdue: false },
              { lead: 'Andrew Phillips',  time: 'Was due yesterday', action: 'Quote net yield for Jomtien studio', overdue: true },
              { lead: 'Marcus Schmidt',   time: 'Due in 3h',      action: 'Send 2026 market report PDF',          overdue: false },
              { lead: 'Khun Apinya',      time: 'Due tomorrow',   action: 'Visa-stamp documents follow-up',       overdue: false },
            ].map((r, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: r.overdue ? 'rgba(217,106,78,.06)' : 'var(--paper-warm)', borderRadius: 10, borderLeft: r.overdue ? '3px solid var(--coral)' : '3px solid transparent' }}>
                <I.clock size={14} color={r.overdue ? 'var(--coral)' : 'var(--ink-4)'}/>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 500 }}>{r.action}</div>
                  <div style={{ fontSize: 11, color: r.overdue ? 'var(--coral-2)' : 'var(--ink-4)' }}>{r.lead} · {r.time}</div>
                </div>
                <button className="btn btn-sm btn-paper" style={{ height: 26 }}>Do it</button>
              </div>
            ))}
          </div>
        </div>

        <div className="card" style={{ padding: 24 }}>
          <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Team activity</h3>
          <p style={{ margin: '4px 0 18px', fontSize: 12, color: 'var(--ink-4)' }}>Last 24 hours</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              { who: AGENTS[1], t: 'Booked viewing for Sven Larsson', when: '12m ago', i: I.calendar },
              { who: AGENTS[2], t: 'Closed deal — Penthouse Wongamat ฿39.5M', when: '2h ago', i: I.check, hot: true },
              { who: AGENTS[3], t: 'Added 3 new units to Jomtien Bay', when: '4h ago', i: I.plus },
              { who: AGENTS[0], t: 'Marked Sven Larsson as qualified', when: '6h ago', i: I.trend },
              { who: AGENTS[4], t: 'Replied to Lin Wei on WeChat', when: '8h ago', i: I.line },
            ].map((a, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'start', gap: 12 }}>
                <img src={a.who.avatar} style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }}/>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12.5 }}>
                    <strong style={{ fontWeight: 500 }}>{a.who.name}</strong> {a.t}
                    {a.hot && <span className="tag tag-green tag-sm" style={{ marginLeft: 8 }}>WON</span>}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--ink-4)', marginTop: 2 }}>{a.when}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminShell>
  );
}

function KPI({ title, value, delta, tone, sparkline }) {
  const max = Math.max(...sparkline);
  const min = Math.min(...sparkline);
  const w = 110, h = 40;
  const points = sparkline.map((v, i) => `${(i / (sparkline.length - 1)) * w},${h - ((v - min) / (max - min || 1)) * (h - 6) - 3}`).join(' ');
  return (
    <div className="card" style={{ padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'start', justifyContent: 'space-between', marginBottom: 14 }}>
        <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>{title}</span>
        <svg width={w} height={h} className="spark" viewBox={`0 0 ${w} ${h}`}>
          <polyline points={points} fill="none" stroke={tone === 'good' ? 'var(--green)' : 'var(--coral)'} strokeWidth="1.8"/>
        </svg>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, letterSpacing: '-0.02em', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 11.5, color: tone === 'good' ? 'var(--green)' : 'var(--coral)', marginTop: 6, fontFamily: 'var(--font-mono)' }}>{tone === 'good' ? '↑' : '↓'} {delta} vs last period</div>
    </div>
  );
}

function iconBtn(c) {
  return { width: 26, height: 26, borderRadius: 6, background: c, border: 0, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' };
}

window.AdminDashboard = AdminDashboard;
window.iconBtn = iconBtn;
