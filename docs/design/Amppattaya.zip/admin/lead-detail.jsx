// ─────────────────────────────────────────────────────────────
// Admin: Lead Detail (CRM-style)
// ─────────────────────────────────────────────────────────────
function LeadDetail({ goto, leadId }) {
  const l = LEADS.find(x => x.id === leadId) || LEADS[0];
  const agent = AGENTS.find(a => a.id === l.agent);
  const [tab, setTab] = React.useState('activity');

  return (
    <AdminShell
      active="leads"
      onNav={(k) => goto && goto(`admin-${k}`)}
      title={
        <span style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={() => goto && goto('admin-pipeline')} style={{ background: 'transparent', border: 0, color: 'var(--ink-4)', cursor: 'pointer' }}><I.chevL size={16}/></button>
          {l.name} <CountryFlag c={l.country}/>
        </span>
      }
      subtitle={`${l.id} · ${l.source} · ${l.lang} · Created ${l.age} days ago`}
      actions={
        <>
          <button style={iconBtn('#25D366')}><I.whatsapp size={14}/></button>
          <button style={iconBtn('#06C755')}><I.line size={14}/></button>
          <button style={iconBtn('var(--coral)')}><I.phone size={14}/></button>
          <button className="btn btn-sm btn-paper"><I.mail size={13}/> Email</button>
          <button className="btn btn-sm btn-coral"><I.calendar size={13}/> Book viewing</button>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20 }}>
        {/* Main column */}
        <div>
          {/* Stage + score band */}
          <div className="card" style={{ padding: 22, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <StageBadge stage={l.stage}/>
                <PriorityDot p={l.priority}/>
                <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>Score</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 120, height: 8, background: 'var(--line-soft)', borderRadius: 99, overflow: 'hidden' }}>
                    <div style={{ width: `${l.score}%`, height: '100%', background: l.score > 80 ? 'var(--coral)' : 'var(--champagne)' }}/>
                  </div>
                  <span className="t-mono" style={{ fontSize: 13, fontWeight: 500 }}>{l.score}</span>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {['New', 'Qualified', 'Viewing', 'Negotiating', 'Won'].map((s, i, arr) => (
                  <button key={s} className="btn btn-sm" style={{ height: 30, background: i <= 1 ? 'var(--ink)' : 'var(--paper)', color: i <= 1 ? 'var(--bone)' : 'var(--ink-3)', border: '1px solid var(--line)' }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'flex', borderBottom: '1px solid var(--line-soft)' }}>
              {[
                ['activity', 'Activity', 12],
                ['notes', 'Notes', 4],
                ['files', 'Files', 6],
                ['interest', 'Interests', 3],
                ['deals', 'Deals', 1],
              ].map(([id, l_, n]) => (
                <button key={id} onClick={() => setTab(id)}
                  style={{ flex: 1, padding: '14px 0', background: tab === id ? 'var(--paper-warm)' : 'transparent', border: 0, borderBottom: tab === id ? '2px solid var(--ink)' : '2px solid transparent', fontSize: 13, fontWeight: 500, color: tab === id ? 'var(--ink)' : 'var(--ink-4)', cursor: 'pointer' }}>
                  {l_} <span style={{ color: 'var(--ink-4)' }}>{n}</span>
                </button>
              ))}
            </div>

            {/* Activity timeline */}
            <div style={{ padding: 24 }}>
              {/* Composer */}
              <div style={{ display: 'flex', alignItems: 'start', gap: 12, padding: 14, background: 'var(--paper-warm)', borderRadius: 10, marginBottom: 24 }}>
                <img src={AGENTS[0].avatar} style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }}/>
                <div style={{ flex: 1 }}>
                  <textarea placeholder="Log a call, note, or send a message…" style={{ width: '100%', minHeight: 64, padding: 10, border: 0, borderRadius: 8, background: 'var(--paper)', fontSize: 13, resize: 'none', fontFamily: 'inherit' }}/>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
                    <button className="btn btn-sm btn-ghost" style={{ height: 28 }}><I.whatsapp size={12}/> WhatsApp template</button>
                    <button className="btn btn-sm btn-ghost" style={{ height: 28 }}><I.document size={12}/> Send brochure</button>
                    <button className="btn btn-sm btn-ghost" style={{ height: 28 }}><I.clock size={12}/> Schedule reminder</button>
                    <button className="btn btn-sm btn-coral" style={{ marginLeft: 'auto', height: 28 }}>Send</button>
                  </div>
                </div>
              </div>

              {/* Timeline */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 18, position: 'relative' }}>
                <div style={{ position: 'absolute', left: 11, top: 16, bottom: 16, width: 1, background: 'var(--line-soft)' }}/>
                {[
                  { time: '2 hrs ago',  who: agent.name, action: 'WhatsApp message sent', body: '"Hi Sven, here\u2019s the floor plan + projected yield for Tower A 28-12. Happy to walk you through tomorrow."', i: I.whatsapp, c: '#25D366' },
                  { time: '4 hrs ago',  who: agent.name, action: 'Viewing booked', body: 'Skyharbor Residences · Tower A 28-12 · 22 May, 10:00', i: I.calendar, c: 'var(--coral)' },
                  { time: 'Yesterday',  who: agent.name, action: 'Note added', body: 'Sven\u2019s wife wants 2 BR, not 1 BR. Adjust shortlist.', i: I.document, c: 'var(--ink-4)' },
                  { time: '2 days ago', who: 'AMP bot', action: 'Lead scored 92 — moved to Hot', body: 'Triggered by: budget verified + LinkedIn match + project click 3×', i: I.sparkle, c: 'var(--coral-2)' },
                  { time: '2 days ago', who: agent.name, action: 'First call · 18 min', body: 'Identified buyer profile: investment, 2BR, sea-view, Wongamat preferred', i: I.phone, c: 'var(--teal)' },
                  { time: '4 days ago', who: 'Google Ads', action: 'Lead created', body: 'Source: campaign "Pattaya Investment Q2" · Term: "buy condo pattaya"', i: I.tag, c: 'var(--blue)' },
                ].map((e, i) => (
                  <div key={i} style={{ display: 'flex', gap: 12, position: 'relative' }}>
                    <div style={{ width: 24, height: 24, borderRadius: '50%', background: e.c, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, zIndex: 2 }}>
                      <e.i size={12}/>
                    </div>
                    <div style={{ flex: 1, paddingBottom: 4 }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{e.action} <span style={{ color: 'var(--ink-4)', fontWeight: 400 }}>· {e.who}</span></div>
                      <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 4, lineHeight: 1.5 }}>{e.body}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-4)', marginTop: 4 }}>{e.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Shortlist */}
          <div className="card" style={{ padding: 22, marginTop: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 400 }}>Shortlist · 3 projects</h3>
              <button className="btn btn-sm btn-paper"><I.plus size={12}/> Add property</button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginTop: 14 }}>
              {PROJECTS.slice(0, 3).map(p => (
                <div key={p.id} style={{ background: 'var(--paper-warm)', borderRadius: 10, padding: 12, border: '1px solid var(--line-soft)' }}>
                  <div style={{ aspectRatio: '16/10', borderRadius: 6, background: `url(${p.cover}) center/cover`, marginBottom: 8 }}/>
                  <div style={{ fontSize: 12.5, fontWeight: 500 }}>{p.name}</div>
                  <div style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>From ฿{(p.startingPriceTHB / 1_000_000).toFixed(1)}M · {p.area}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right rail */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Contact */}
          <div className="card" style={{ padding: 22 }}>
            <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--ink-3)' }}>Contact</h4>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Field2 i={<I.phone size={13}/>} v="+46 70 234 5678" sub="Stockholm · GMT+2"/>
              <Field2 i={<I.mail size={13}/>} v={`sven.l@mail.com`} sub="opens 92% of mails"/>
              <Field2 i={<I.whatsapp size={13}/>} v="WhatsApp +46 70 ..." sub="online now"/>
              <Field2 i={<I.globe size={13}/>} v="amppattaya.com · 28 visits" sub="last: 12m ago"/>
            </div>
          </div>

          {/* Buyer profile */}
          <div className="card" style={{ padding: 22 }}>
            <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--ink-3)' }}>Buyer profile</h4>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <Row k="Budget" v={`฿${l.budget}M`}/>
              <Row k="Bedrooms" v="2 BR · Sea view"/>
              <Row k="Areas" v="Wongamat · Pratumnak"/>
              <Row k="Timeline" v="Within 3 months"/>
              <Row k="Purpose" v="Investment + holiday"/>
              <Row k="Cash buyer" v="Yes · funds verified"/>
              <Row k="Visa" v="Tourist · doesn't reside"/>
            </div>
          </div>

          {/* Assigned advisor */}
          <div className="card" style={{ padding: 22 }}>
            <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--ink-3)' }}>Assigned advisor</h4>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 14 }}>
              <img src={agent.avatar} style={{ width: 42, height: 42, borderRadius: '50%', objectFit: 'cover' }}/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{agent.name}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{agent.role}</div>
              </div>
              <button className="btn btn-sm btn-ghost" style={{ height: 28 }}>Reassign</button>
            </div>
          </div>

          {/* Next action */}
          <div style={{ padding: 22, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 14 }}>
            <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>Suggested next action</span>
            <h4 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 400, lineHeight: 1.2 }}>Send 5-year ROI projection for Skyharbor 2BR</h4>
            <p style={{ margin: '8px 0 16px', fontSize: 12, color: 'rgba(248,244,234,.6)', lineHeight: 1.5 }}>Sven clicked the yield calculator 4 times in the last 2 days but hasn't received a custom forecast yet.</p>
            <button className="btn btn-sm" style={{ background: 'var(--champagne)', color: 'var(--ink)', width: '100%' }}>Generate & send <I.arrowR size={12}/></button>
          </div>
        </div>
      </div>
    </AdminShell>
  );
}

function Field2({ i, v, sub }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--paper-warm)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-3)', flexShrink: 0 }}>{i}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{v}</div>
        <div style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>{sub}</div>
      </div>
    </div>
  );
}

function Row({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5 }}>
      <span style={{ color: 'var(--ink-4)' }}>{k}</span>
      <span style={{ color: 'var(--ink)', fontWeight: 500 }}>{v}</span>
    </div>
  );
}

window.LeadDetail = LeadDetail;
