// ─────────────────────────────────────────────────────────────
// Admin Mobile: Dashboard + Lead Detail
// ─────────────────────────────────────────────────────────────

function AdminMobileDashboard() {
  return (
    <div className="frame scroll-y" style={{ background: 'var(--paper-warm)', paddingBottom: 80 }}>
      <div className="statusbar"><span>9:41</span><span style={{ display: 'flex', gap: 4 }}>•••• 5G ▮</span></div>

      {/* Top bar */}
      <div style={{ padding: '4px 18px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <img src={AGENTS[0].avatar} style={{ width: 38, height: 38, borderRadius: '50%', objectFit: 'cover' }}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>Good morning</div>
          <div style={{ fontSize: 14, fontWeight: 500 }}>Khun Apinya</div>
        </div>
        <button style={{ width: 38, height: 38, borderRadius: 999, background: 'var(--paper)', border: '1px solid var(--line)', position: 'relative' }}>
          <I.bell size={16}/>
          <span style={{ position: 'absolute', top: 6, right: 6, width: 7, height: 7, borderRadius: '50%', background: 'var(--coral)' }}/>
        </button>
      </div>

      {/* Hero CTA */}
      <div style={{ margin: '0 18px 18px', padding: 20, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 16 }}>
        <span className="t-eyebrow" style={{ color: 'var(--coral)' }}>3 hot leads waiting</span>
        <h2 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.015em', lineHeight: 1.1, fontWeight: 400 }}>
          Sven Larsson hasn't heard back in 2h.
        </h2>
        <p style={{ margin: '8px 0 16px', fontSize: 13, color: 'rgba(248,244,234,.6)' }}>His 5y ROI projection is ready to send.</p>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{ background: '#25D366', color: '#fff', border: 0, padding: '10px 14px', borderRadius: 8, fontSize: 12.5, fontWeight: 500 }}><I.whatsapp size={14} style={{ verticalAlign: -3, marginRight: 6 }}/>Reply</button>
          <button style={{ background: 'rgba(248,244,234,.12)', color: 'var(--bone)', border: '1px solid rgba(248,244,234,.18)', padding: '10px 14px', borderRadius: 8, fontSize: 12.5, fontWeight: 500 }}>Open lead</button>
        </div>
      </div>

      {/* Today KPIs */}
      <div style={{ padding: '0 18px', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
        {[['48', 'New leads today', '+12%'], ['14', 'Viewings booked', '+3'], ['฿324M', 'Pipeline value', '+฿28M'], ['62%', 'Qualify rate', '+4pp']].map(([v, l, d]) => (
          <div key={l} style={{ padding: 16, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.015em' }}>{v}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-4)', marginTop: 2 }}>{l}</div>
            <div style={{ fontSize: 10.5, color: 'var(--green)', marginTop: 6, fontFamily: 'var(--font-mono)' }}>↑ {d}</div>
          </div>
        ))}
      </div>

      {/* Hot leads */}
      <div style={{ padding: '22px 18px 8px', display: 'flex', alignItems: 'end', justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0, fontSize: 16, fontWeight: 500 }}>Hot leads · need reply</h3>
        <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>See all</span>
      </div>
      <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {LEADS.filter(l => l.priority === 'hot').slice(0, 4).map(l => (
          <div key={l.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 14, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <span className="avatar avatar-sm" style={{ background: 'var(--sand)', fontSize: 11 }}>{l.name.split(' ').map(s => s[0]).join('').slice(0, 2)}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.name} <CountryFlag c={l.country}/></div>
              <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{l.interest} · {l.last}</div>
            </div>
            <button style={iconBtn('#25D366')}><I.whatsapp size={12}/></button>
            <button style={iconBtn('var(--coral)')}><I.phone size={12}/></button>
          </div>
        ))}
      </div>

      {/* Today viewings */}
      <div style={{ padding: '22px 18px 8px', display: 'flex', alignItems: 'end', justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0, fontSize: 16, fontWeight: 500 }}>Today's viewings</h3>
        <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>6 scheduled</span>
      </div>
      <div style={{ padding: '0 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {VIEWINGS.slice(0, 3).map(v => {
          const lead = LEADS.find(l => l.id === v.leadId);
          return (
            <div key={v.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
              <div style={{ width: 50, textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 500 }}>{v.time}</div>
                <div style={{ fontSize: 9.5, color: 'var(--ink-4)' }}>45m</div>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lead?.name}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-4)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{v.unit}</div>
              </div>
              <span className={`tag tag-${v.status === 'confirmed' ? 'green' : 'amber'} tag-sm`}>{v.status[0].toUpperCase() + v.status.slice(1)}</span>
            </div>
          );
        })}
      </div>

      {/* Bottom nav */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'var(--paper)', borderTop: '1px solid var(--line)', padding: '8px 0 24px', display: 'flex', justifyContent: 'space-around' }}>
        {[
          { i: I.grid, l: 'Home', active: true },
          { i: I.pipe, l: 'Pipeline' },
          { i: I.calendar, l: 'Viewings' },
          { i: I.bell, l: 'Inbox' },
        ].map((n, i) => (
          <button key={i} style={{ background: 'transparent', border: 0, color: n.active ? 'var(--ink)' : 'var(--ink-4)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
            <n.i size={20}/>
            <span style={{ fontSize: 10 }}>{n.l}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Mobile Lead Detail ───
function AdminMobileLead() {
  const l = LEADS[0];
  const agent = AGENTS.find(a => a.id === l.agent);
  return (
    <div className="frame scroll-y" style={{ background: 'var(--paper-warm)', paddingBottom: 100 }}>
      <div className="statusbar"><span>9:41</span><span style={{ display: 'flex', gap: 4 }}>•••• 5G ▮</span></div>

      <div style={{ padding: '4px 18px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button style={{ width: 36, height: 36, borderRadius: 999, background: 'var(--paper)', border: '1px solid var(--line)' }}><I.chevL size={16}/></button>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 500 }}>{l.name} <CountryFlag c={l.country}/></div>
          <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{l.id}</div>
        </div>
        <button style={{ width: 36, height: 36, borderRadius: 999, background: 'var(--paper)', border: '1px solid var(--line)' }}><I.more size={16}/></button>
      </div>

      {/* Stage / score */}
      <div style={{ margin: '0 18px 14px', padding: 16, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <StageBadge stage={l.stage}/>
          <PriorityDot p={l.priority}/>
        </div>
        <div style={{ marginTop: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--ink-4)', marginBottom: 4 }}>
            <span>Lead score</span>
            <span className="t-mono" style={{ fontSize: 13, color: 'var(--ink)', fontWeight: 500 }}>{l.score}</span>
          </div>
          <div className="progress" style={{ height: 7 }}><div style={{ width: `${l.score}%`, background: 'var(--coral)' }}/></div>
        </div>
      </div>

      {/* Quick action grid */}
      <div style={{ padding: '0 18px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
        {[
          { i: <I.whatsapp size={18}/>, l: 'WhatsApp', c: '#25D366' },
          { i: <I.phone size={18}/>,    l: 'Call',     c: 'var(--coral)' },
          { i: <I.mail size={18}/>,     l: 'Email',    c: 'var(--ink)' },
          { i: <I.calendar size={18}/>, l: 'Viewing',  c: 'var(--teal)' },
        ].map((a, i) => (
          <button key={i} style={{ padding: 14, background: 'var(--paper)', border: '1px solid var(--line-soft)', borderRadius: 12, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
            <div style={{ width: 40, height: 40, borderRadius: 999, background: a.c, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{a.i}</div>
            <span style={{ fontSize: 11, fontWeight: 500 }}>{a.l}</span>
          </button>
        ))}
      </div>

      {/* Next action card */}
      <div style={{ margin: '14px 18px', padding: 16, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 14 }}>
        <span style={{ fontSize: 10, color: 'var(--champagne)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Suggested next action</span>
        <div style={{ marginTop: 6, fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 400 }}>Send 5y ROI projection for Skyharbor 2BR</div>
        <button style={{ marginTop: 12, background: 'var(--champagne)', color: 'var(--ink)', border: 0, padding: '10px 14px', borderRadius: 8, fontSize: 12.5, fontWeight: 500 }}>Generate & send <I.arrowR size={12} style={{ verticalAlign: -2 }}/></button>
      </div>

      {/* Profile */}
      <div style={{ margin: '14px 18px', padding: 16, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
        <h4 style={{ margin: 0, fontSize: 12, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--ink-4)' }}>Buyer profile</h4>
        <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[['Budget', `฿${l.budget}M`], ['Interest', l.interest], ['Areas', 'Wongamat · Pratumnak'], ['Timeline', 'Within 3 months'], ['Cash buyer', 'Yes · verified']].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
              <span style={{ color: 'var(--ink-4)' }}>{k}</span>
              <span style={{ fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div style={{ margin: '14px 18px', padding: 16, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
        <h4 style={{ margin: 0, fontSize: 12, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--ink-4)' }}>Recent activity</h4>
        <div style={{ marginTop: 12, position: 'relative', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ position: 'absolute', left: 9, top: 8, bottom: 8, width: 1, background: 'var(--line-soft)' }}/>
          {[
            ['WhatsApp sent', '2h', '#25D366', I.whatsapp],
            ['Viewing booked', '4h', 'var(--coral)', I.calendar],
            ['Note added', '1d', 'var(--ink-4)', I.document],
            ['Score → 92 hot', '2d', 'var(--coral-2)', I.sparkle],
          ].map(([t, time, c, Ic], i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 20, height: 20, borderRadius: '50%', background: c, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', zIndex: 1 }}>
                <Ic size={10}/>
              </span>
              <span style={{ flex: 1, fontSize: 13 }}>{t}</span>
              <span style={{ fontSize: 11, color: 'var(--ink-4)' }}>{time}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Sticky bottom */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '12px 18px 24px', background: 'var(--paper)', borderTop: '1px solid var(--line)', display: 'flex', gap: 8 }}>
        <button className="btn btn-paper" style={{ flex: 0.6 }}>Reassign</button>
        <button className="btn btn-coral" style={{ flex: 1 }}>Move to Negotiating <I.arrowR size={14}/></button>
      </div>
    </div>
  );
}

Object.assign(window, { AdminMobileDashboard, AdminMobileLead });
