// ─────────────────────────────────────────────────────────────
// Admin: Viewing Appointment Calendar
// ─────────────────────────────────────────────────────────────
function AdminCalendar({ goto }) {
  return (
    <AdminShell
      active="viewings"
      onNav={(k) => goto && goto(`admin-${k}`)}
      title="Viewings"
      subtitle="14 confirmed this week · 4 pending · 2 cancellations"
      actions={
        <>
          <span className="seg">
            <button>Day</button>
            <button className="is-active">Week</button>
            <button>Month</button>
          </span>
          <button className="btn btn-sm btn-paper"><I.chevL size={12}/></button>
          <span style={{ fontSize: 13, fontWeight: 500, padding: '0 8px' }}>18 – 24 May 2026</span>
          <button className="btn btn-sm btn-paper"><I.chevR size={12}/></button>
          <button className="btn btn-sm btn-coral"><I.plus size={13}/> Schedule viewing</button>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20 }}>
        {/* Calendar */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {/* Days header */}
          <div style={{ display: 'grid', gridTemplateColumns: '60px repeat(7, 1fr)', borderBottom: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}>
            <div/>
            {[['Mon', 18], ['Tue', 19], ['Wed', 20], ['Thu', 21], ['Fri', 22, true], ['Sat', 23], ['Sun', 24]].map(([d, num, today]) => (
              <div key={d} style={{ padding: '12px 8px', textAlign: 'center', borderLeft: '1px solid var(--line-soft)' }}>
                <div style={{ fontSize: 10.5, color: 'var(--ink-4)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{d}</div>
                <div style={{ marginTop: 4, fontFamily: 'var(--font-display)', fontSize: 22, color: today ? 'var(--coral)' : 'var(--ink)' }}>{num}</div>
              </div>
            ))}
          </div>

          {/* Time grid */}
          <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '60px repeat(7, 1fr)' }}>
            {/* Hour rows */}
            {['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'].map((hour, hi) => (
              <React.Fragment key={hour}>
                <div style={{ padding: '4px 8px', borderBottom: '1px solid var(--line-soft)', fontSize: 10.5, color: 'var(--ink-4)', height: 56 }} className="t-mono">{hour}</div>
                {[0, 1, 2, 3, 4, 5, 6].map(d => (
                  <div key={d} style={{ borderBottom: '1px solid var(--line-soft)', borderLeft: '1px solid var(--line-soft)', height: 56, position: 'relative' }}/>
                ))}
              </React.Fragment>
            ))}

            {/* Events overlay */}
            {[
              { day: 0, top: 10, height: 56, lead: 'David Wong',     project: 'Skyharbor 28-12', agent: AGENTS[1], tone: 'coral', status: 'confirmed' },
              { day: 1, top: 66, height: 56, lead: 'Marcus Schmidt', project: 'Pratumnak Villa 06', agent: AGENTS[0], tone: 'teal', status: 'confirmed' },
              { day: 2, top: 122, height: 56, lead: 'Lin Wei',       project: 'Jomtien Bay 18-22', agent: AGENTS[4], tone: 'amber', status: 'pending' },
              { day: 3, top: 290, height: 56, lead: 'Yulia Petrova', project: 'Jomtien Bay 09-14', agent: AGENTS[2], tone: 'coral', status: 'confirmed' },
              { day: 4, top: 66, height: 80, lead: 'Sven Larsson',   project: 'Skyharbor 28-12', agent: AGENTS[1], tone: 'coral', status: 'confirmed', big: true },
              { day: 4, top: 290, height: 56, lead: 'Anna Markova',  project: 'Skyharbor 41-04', agent: AGENTS[2], tone: 'coral', status: 'confirmed' },
              { day: 4, top: 402, height: 56, lead: 'Igor Volkov',   project: 'Bang Saray Villa', agent: AGENTS[2], tone: 'teal', status: 'confirmed' },
              { day: 5, top: 178, height: 56, lead: 'Andrew Phillips', project: 'Jomtien Studio', agent: AGENTS[3], tone: 'champagne', status: 'follow-up' },
              { day: 6, top: 234, height: 56, lead: 'Chen Hua',      project: 'Pratumnak PH',     agent: AGENTS[4], tone: 'amber', status: 'pending' },
            ].map((ev, i) => {
              const toneColors = { coral: 'var(--coral)', teal: 'var(--teal)', amber: 'var(--amber)', champagne: 'var(--champagne)' };
              return (
                <div key={i} style={{
                  position: 'absolute', top: ev.top, left: `calc(60px + ${(ev.day) * (100 / 7)}% - ${60 * ev.day / 7}px)`,
                  width: `calc((100% - 60px) / 7 - 4px)`,
                  height: ev.height,
                  margin: '2px',
                  background: 'var(--paper)',
                  borderLeft: `3px solid ${toneColors[ev.tone]}`,
                  borderRadius: 6,
                  padding: '4px 6px',
                  boxShadow: 'var(--shadow-sm)',
                  fontSize: 10.5, lineHeight: 1.25,
                  overflow: 'hidden',
                }}>
                  <div style={{ fontWeight: 500, fontSize: 11, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ev.lead}</div>
                  <div style={{ color: 'var(--ink-4)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ev.project}</div>
                  {ev.big && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
                      <img src={ev.agent.avatar} style={{ width: 16, height: 16, borderRadius: '50%', objectFit: 'cover' }}/>
                      <span style={{ fontSize: 10, color: 'var(--ink-3)' }}>{ev.agent.name.split(' ')[0]}</span>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Current time line */}
            <div style={{ position: 'absolute', top: 168, left: 60, right: 0, height: 1, background: 'var(--coral)', zIndex: 4 }}>
              <span style={{ position: 'absolute', left: -8, top: -4, width: 10, height: 10, borderRadius: '50%', background: 'var(--coral)' }}/>
              <span style={{ position: 'absolute', left: -56, top: -8, fontSize: 10, color: 'var(--coral)', fontWeight: 500, fontFamily: 'var(--font-mono)' }}>11:48</span>
            </div>
          </div>
        </div>

        {/* Right rail */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Today */}
          <div className="card" style={{ padding: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500 }}>Friday, 22 May</h4>
              <span className="tag tag-coral tag-sm">Today</span>
            </div>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {VIEWINGS.slice(0, 4).map(v => {
                const lead = LEADS.find(l => l.id === v.leadId);
                return (
                  <div key={v.id} style={{ display: 'flex', gap: 12, padding: '10px 12px', background: 'var(--paper-warm)', borderRadius: 8 }}>
                    <div style={{ width: 38, textAlign: 'center', flexShrink: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 500, fontFamily: 'var(--font-mono)' }}>{v.time}</div>
                      <div style={{ fontSize: 10, color: 'var(--ink-4)' }}>45m</div>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lead?.name} <CountryFlag c={lead?.country}/></div>
                      <div style={{ fontSize: 10.5, color: 'var(--ink-4)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{v.unit}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pending confirmations */}
          <div className="card" style={{ padding: 20 }}>
            <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500 }}>Awaiting confirmation · 4</h4>
            <p style={{ margin: '4px 0 14px', fontSize: 11.5, color: 'var(--ink-4)' }}>Send a reminder via WhatsApp</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {VIEWINGS.filter(v => v.status === 'pending').map(v => {
                const lead = LEADS.find(l => l.id === v.leadId);
                return (
                  <div key={v.id} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12 }}>
                    <span className="avatar avatar-sm" style={{ background: 'var(--sand)', fontSize: 10 }}>{lead?.name.split(' ').map(s => s[0]).join('').slice(0, 2)}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lead?.name}</div>
                      <div style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>{v.date} · {v.time}</div>
                    </div>
                    <button style={iconBtn('#25D366')}><I.whatsapp size={11}/></button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Agent workload */}
          <div className="card" style={{ padding: 20 }}>
            <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500 }}>Agent workload · this week</h4>
            <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {AGENTS.map((a, i) => {
                const count = [4, 6, 3, 5, 2][i];
                return (
                  <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <img src={a.avatar} style={{ width: 26, height: 26, borderRadius: '50%', objectFit: 'cover' }}/>
                    <span style={{ flex: 1, fontSize: 12, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</span>
                    <span style={{ fontSize: 11, color: 'var(--ink-4)' }} className="t-mono">{count} viewings</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </AdminShell>
  );
}

// ─────────────────────────────────────────────────────────────
// Admin: Marketing Performance
// ─────────────────────────────────────────────────────────────
function AdminMarketing({ goto }) {
  return (
    <AdminShell
      active="marketing"
      onNav={(k) => goto && goto(`admin-${k}`)}
      title="Marketing performance"
      subtitle="May 2026 · 410 leads sourced · ฿84M revenue attributed · CAC ฿4,200"
      actions={
        <>
          <span className="seg">
            <button>7d</button>
            <button className="is-active">30d</button>
            <button>90d</button>
            <button>YTD</button>
          </span>
          <button className="btn btn-sm btn-paper"><I.download size={13}/> Export</button>
        </>
      }
    >
      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14 }}>
        <KPI title="Total leads" value="410" delta="+18%" tone="good" sparkline={[280, 290, 320, 340, 360, 388, 410]}/>
        <KPI title="Cost / lead" value="฿1,840" delta="-฿120" tone="good" sparkline={[2200, 2100, 2000, 1950, 1900, 1880, 1840]}/>
        <KPI title="Lead → Deal" value="11.4%" delta="+3 pp" tone="good" sparkline={[8, 8.2, 9, 9.5, 10, 10.8, 11.4]}/>
        <KPI title="Cost per deal (CAC)" value="฿16,140" delta="-฿4k" tone="good" sparkline={[24, 22, 20, 19, 18, 17, 16]}/>
        <KPI title="ROAS" value="74×" delta="+12×" tone="good" sparkline={[40, 48, 55, 60, 64, 70, 74]}/>
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 20, marginTop: 20 }}>
        {/* Revenue chart */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Revenue attributed by source</h3>
              <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>Last 30 days · ฿84M total</p>
            </div>
          </div>
          <div style={{ marginTop: 28, height: 240, position: 'relative' }}>
            <svg viewBox="0 0 600 240" style={{ width: '100%', height: '100%' }}>
              {[0, 1, 2, 3].map(i => <line key={i} x1="0" x2="600" y1={60 * i} y2={60 * i} stroke="var(--line-soft)" strokeWidth="1"/>)}
              {/* Stacked bars */}
              {Array.from({ length: 12 }).map((_, i) => {
                const x = 20 + i * 48;
                const heights = [
                  [80, 'var(--blue)'],          // ads
                  [40, '#25D366'],              // whatsapp
                  [25, 'var(--champagne)'],      // referrals
                  [15, 'var(--coral)'],         // portals
                ].map(([h, c]) => [h + Math.sin(i / 2) * 15, c]);
                let y = 220;
                return (
                  <g key={i}>
                    {heights.map(([h, c], j) => {
                      y -= h;
                      return <rect key={j} x={x} y={y} width="28" height={h} fill={c}/>;
                    })}
                    <text x={x + 14} y={234} textAnchor="middle" fontSize="9" fill="var(--ink-4)">M{i + 1}</text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div style={{ display: 'flex', gap: 18, marginTop: 8, fontSize: 11.5 }}>
            {[['Google Ads', 'var(--blue)'], ['WhatsApp', '#25D366'], ['Referrals', 'var(--champagne)'], ['Portals', 'var(--coral)']].map(([n, c]) => (
              <span key={n} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 10, height: 10, borderRadius: 2, background: c }}/>{n}
              </span>
            ))}
          </div>
        </div>

        {/* Buyer countries */}
        <div className="card" style={{ padding: 24 }}>
          <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Buyer countries</h3>
          <p style={{ margin: '4px 0 18px', fontSize: 12, color: 'var(--ink-4)' }}>Leads · last 30d</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[
              ['🇷🇺', 'Russia', 88, '#dc4848'],
              ['🇨🇳', 'China', 72, '#dc8a48'],
              ['🇬🇧', 'United Kingdom', 64, '#48a3dc'],
              ['🇩🇪', 'Germany', 56, 'var(--champagne)'],
              ['🇫🇷', 'France', 44, '#5a8a48'],
              ['🇸🇪', 'Sweden', 32, 'var(--ink)'],
              ['🇺🇸', 'United States', 28, 'var(--teal)'],
              ['🇸🇬', 'Singapore', 18, 'var(--coral)'],
            ].map(([fl, n, c, color]) => (
              <div key={n}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                  <span>{fl} {n}</span>
                  <span className="t-mono">{c}</span>
                </div>
                <div style={{ height: 5, background: 'var(--line-soft)', borderRadius: 99 }}>
                  <div style={{ width: `${(c / 88) * 100}%`, height: '100%', background: color, borderRadius: 99 }}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Campaigns table */}
      <div className="card" style={{ marginTop: 20, padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--line-soft)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Active campaigns</h3>
            <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>Live attribution by AMP tracking</p>
          </div>
          <button className="btn btn-sm btn-paper"><I.plus size={13}/> New campaign</button>
        </div>
        <table className="tbl">
          <thead><tr><th>Campaign</th><th>Channel</th><th>Spend</th><th>Leads</th><th>Cost / lead</th><th>Deals</th><th>Revenue</th><th>ROAS</th><th></th></tr></thead>
          <tbody>
            {[
              { name: 'Pattaya Investment Q2',    ch: 'Google Ads',       spend: 145_000, leads: 88, deals: 12, rev: 28_500_000, dot: 'var(--blue)' },
              { name: 'Wongamat Luxury',           ch: 'Google Ads',       spend: 92_000,  leads: 54, deals: 8,  rev: 18_400_000, dot: 'var(--blue)' },
              { name: 'WeChat — China HNW',        ch: 'WeChat moments',   spend: 78_000,  leads: 34, deals: 4,  rev: 14_200_000, dot: '#dc8a48' },
              { name: 'Russian portal NumberOne',  ch: 'Property portal',  spend: 38_000,  leads: 41, deals: 5,  rev: 9_800_000,  dot: 'var(--coral)' },
              { name: 'LinkedIn Foreign Buyers',   ch: 'LinkedIn Ads',     spend: 62_000,  leads: 28, deals: 3,  rev: 6_900_000,  dot: '#48a3dc' },
              { name: 'Instagram — Penthouses',    ch: 'Instagram',        spend: 28_000,  leads: 22, deals: 2,  rev: 4_400_000,  dot: 'var(--champagne)' },
            ].map((c, i) => {
              const cpl = c.spend / c.leads;
              const roas = c.rev / c.spend;
              return (
                <tr key={i}>
                  <td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span style={{ width: 6, height: 6, borderRadius: '50%', background: c.dot }}/><strong style={{ fontWeight: 500 }}>{c.name}</strong></div></td>
                  <td><span style={{ fontSize: 12 }}>{c.ch}</span></td>
                  <td><span className="t-mono">฿{c.spend.toLocaleString()}</span></td>
                  <td><span className="t-mono">{c.leads}</span></td>
                  <td><span className="t-mono">฿{cpl.toFixed(0)}</span></td>
                  <td><span className="t-mono">{c.deals}</span></td>
                  <td><span className="t-mono" style={{ fontWeight: 500 }}>฿{(c.rev / 1_000_000).toFixed(1)}M</span></td>
                  <td><span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><span className="t-mono" style={{ color: roas > 100 ? 'var(--green)' : 'var(--ink)' }}>{roas.toFixed(0)}×</span></span></td>
                  <td><div style={{ display: 'flex', gap: 4 }}><button style={iconBtn('var(--paper-warm)')}><I.edit size={11} color="var(--ink)"/></button></div></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}

Object.assign(window, { AdminCalendar, AdminMarketing });
