// ─────────────────────────────────────────────────────────────
// Admin: Property / Project Management
// ─────────────────────────────────────────────────────────────
function AdminProperties({ goto }) {
  const [tab, setTab] = React.useState('properties');
  return (
    <AdminShell
      active={tab}
      onNav={(k) => goto && goto(`admin-${k}`)}
      title="Inventory"
      subtitle="184 properties across 8 projects · 3 awaiting approval"
      actions={
        <>
          <span className="seg">
            <button className={tab === 'properties' ? 'is-active' : ''} onClick={() => setTab('properties')}>Properties</button>
            <button className={tab === 'projects' ? 'is-active' : ''} onClick={() => setTab('projects')}>Projects</button>
          </span>
          <button className="btn btn-sm btn-paper"><I.upload size={13}/> Import CSV</button>
          <button className="btn btn-sm btn-coral"><I.plus size={13}/> Add property</button>
        </>
      }
    >
      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <input className="input" placeholder="Search by unit, project, agent…" style={{ width: 320, height: 36 }}/>
        <Chip2 label="All projects"/>
        <Chip2 label="All statuses"/>
        <Chip2 label="Price: any"/>
        <Chip2 label="Completeness: any"/>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="tbl">
          <thead>
            <tr>
              <th><span className="check"></span></th>
              <th>Unit</th>
              <th>Project</th>
              <th>Type · Size</th>
              <th>Price</th>
              <th>Status</th>
              <th>Completeness</th>
              <th>Views</th>
              <th>Inquiries</th>
              <th>Updated</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {PROPERTIES.concat(PROPERTIES).slice(0, 12).map((u, idx) => {
              const p = PROJECTS.find(x => x.id === u.projectId);
              const completeness = [92, 78, 100, 65, 88, 100, 71, 84, 95, 60, 92, 78][idx % 12];
              const status = ['Active', 'Active', 'Active', 'Draft', 'Active', 'Reserved', 'Active', 'Active', 'Draft', 'Active', 'Active', 'Sold'][idx % 12];
              const statusColor = status === 'Active' ? 'green' : status === 'Reserved' ? 'amber' : status === 'Sold' ? 'red' : 'paper';
              return (
                <tr key={`${u.id}-${idx}`}>
                  <td><span className="check"></span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 36, height: 36, borderRadius: 6, background: `url(${u.cover}) center/cover` }}/>
                      <div>
                        <div style={{ fontSize: 12.5, fontWeight: 500 }}>{u.unit}</div>
                        <div style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>{u.id}</div>
                      </div>
                    </div>
                  </td>
                  <td><span style={{ fontSize: 12.5 }}>{p?.name}</span></td>
                  <td>
                    <div style={{ fontSize: 12.5 }}>{u.type}</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{u.sqm} m²</div>
                  </td>
                  <td><span className="t-mono" style={{ fontWeight: 500 }}>฿{(u.priceTHB / 1_000_000).toFixed(1)}M</span></td>
                  <td><span className={`tag tag-${statusColor} tag-sm`}>{status}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 80, height: 6, background: 'var(--line-soft)', borderRadius: 99, overflow: 'hidden' }}>
                        <div style={{ width: `${completeness}%`, height: '100%', background: completeness === 100 ? 'var(--green)' : completeness >= 80 ? 'var(--champagne)' : 'var(--coral)' }}/>
                      </div>
                      <span className="t-mono" style={{ fontSize: 11 }}>{completeness}%</span>
                    </div>
                  </td>
                  <td><span className="t-mono" style={{ fontSize: 12 }}>{[182, 88, 412, 24, 156, 0, 76, 244, 18, 88, 312, 0][idx % 12]}</span></td>
                  <td><span className="t-mono" style={{ fontSize: 12 }}>{[12, 4, 28, 0, 8, 2, 5, 14, 0, 3, 22, 0][idx % 12]}</span></td>
                  <td><span style={{ fontSize: 11.5, color: 'var(--ink-4)' }}>{['2h ago', '1d ago', '4h ago', '3d ago', '6h ago', '2d ago', '1d ago', '12h ago', '4d ago', '5h ago', '8h ago', '1w ago'][idx % 12]}</span></td>
                  <td>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'end' }}>
                      <button style={iconBtn('var(--paper-warm)')} title="View" onClick={(e) => { e.stopPropagation(); goto && goto('property', u.id); }}>
                        <I.external size={11} color="var(--ink)"/>
                      </button>
                      <button style={iconBtn('var(--paper-warm)')} title="Edit">
                        <I.edit size={11} color="var(--ink)"/>
                      </button>
                      <button style={iconBtn('var(--paper-warm)')} title="More">
                        <I.more size={11} color="var(--ink)"/>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {/* Pagination */}
        <div style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}>
          <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>1–12 of 184 properties</span>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <button className="btn btn-sm btn-ghost" style={{ height: 28, width: 28, padding: 0 }}><I.chevL size={12}/></button>
            {[1, 2, 3, 4].map(n => (
              <button key={n} style={{ width: 28, height: 28, borderRadius: 6, border: 0, background: n === 1 ? 'var(--ink)' : 'transparent', color: n === 1 ? 'var(--bone)' : 'var(--ink-3)', fontSize: 12, cursor: 'pointer' }}>{n}</button>
            ))}
            <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>… 16</span>
            <button className="btn btn-sm btn-ghost" style={{ height: 28, width: 28, padding: 0 }}><I.chevR size={12}/></button>
          </div>
        </div>
      </div>
    </AdminShell>
  );
}

window.AdminProperties = AdminProperties;
