// ─────────────────────────────────────────────────────────────
// Shared UI: Logo, Topbar, Footer, ProjectCard, PropertyCard,
// CurrencyPicker, LocalePicker, ContactStrip, Trust, FAQ
// ─────────────────────────────────────────────────────────────

const { useShare } = window;

// ─── Brand ───
function Logo({ size = 22, color, mark = false }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: color || 'inherit' }}>
      <svg width={size + 6} height={size + 6} viewBox="0 0 32 32" style={{ flexShrink: 0 }}>
        <rect x="0.5" y="0.5" width="31" height="31" rx="6" fill="none" stroke="currentColor" strokeWidth="1.2"/>
        <path d="M9 23 L16 9 L23 23 M12 18 L20 18" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      {!mark && (
        <span style={{ fontFamily: 'var(--font-display)', fontSize: size + 2, letterSpacing: '0.04em', lineHeight: 1 }}>
          AMP <span style={{ fontStyle: 'italic', fontWeight: 400 }}>Pattaya</span>
        </span>
      )}
    </span>
  );
}

// ─── Currency / locale pickers ───
function CurrencyPill() {
  const { currency, setCurrency } = useShare();
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <button onClick={() => setOpen(o => !o)}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: 32, padding: '0 10px', borderRadius: 'var(--r-pill)', background: 'transparent', border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 500, color: 'inherit' }}>
        <I.thb size={14}/> {currency}
        <I.chevD size={12}/>
      </button>
      {open && (
        <div onClick={() => setOpen(false)}
          style={{ position: 'absolute', top: '110%', right: 0, background: 'var(--paper)', border: '1px solid var(--line-soft)', borderRadius: 10, padding: 4, minWidth: 140, zIndex: 30, boxShadow: 'var(--shadow-md)', color: 'var(--ink)' }}>
          {Object.keys(window.CURRENCIES).map(code => (
            <button key={code} onClick={() => setCurrency(code)}
              style={{ display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'space-between', padding: '8px 10px', border: 0, background: currency === code ? 'var(--sand-soft)' : 'transparent', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>
              <span>{code}</span>
              <span className="t-mono" style={{ fontSize: 11, color: 'var(--ink-4)' }}>{window.CURRENCIES[code].symbol}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function LocalePill() {
  const { locale, setLocale } = useShare();
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <button onClick={() => setOpen(o => !o)}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: 32, padding: '0 10px', borderRadius: 'var(--r-pill)', background: 'transparent', border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 500, color: 'inherit' }}>
        <I.globe size={14}/> {locale}
        <I.chevD size={12}/>
      </button>
      {open && (
        <div onClick={() => setOpen(false)}
          style={{ position: 'absolute', top: '110%', right: 0, background: 'var(--paper)', border: '1px solid var(--line-soft)', borderRadius: 10, padding: 4, minWidth: 160, zIndex: 30, boxShadow: 'var(--shadow-md)', color: 'var(--ink)' }}>
          {window.LOCALES.map(l => (
            <button key={l.code} onClick={() => setLocale(l.code)}
              style={{ display: 'flex', width: '100%', alignItems: 'center', gap: 8, padding: '8px 10px', border: 0, background: locale === l.code ? 'var(--sand-soft)' : 'transparent', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}>
              <span style={{ fontSize: 14 }}>{l.flag}</span>
              <span>{l.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Top bar (dark variant + light variant) ───
function Topbar({ active, onNav, tone = 'light', sticky = true }) {
  const dark = tone === 'dark';
  const nav = [
    { id: 'home',     label: 'Home' },
    { id: 'buy',      label: 'Buy' },
    { id: 'projects', label: 'New Projects' },
    { id: 'areas',    label: 'Areas' },
    { id: 'invest',   label: 'Invest' },
    { id: 'contact',  label: 'Contact' },
  ];
  return (
    <header style={{
      position: sticky ? 'sticky' : 'static', top: 0, zIndex: 20,
      background: dark ? 'rgba(20,32,31,.78)' : 'rgba(248,244,234,.88)',
      backdropFilter: 'saturate(160%) blur(14px)',
      WebkitBackdropFilter: 'saturate(160%) blur(14px)',
      borderBottom: `1px solid ${dark ? 'rgba(248,244,234,.08)' : 'var(--line-soft)'}`,
      color: dark ? 'var(--bone)' : 'var(--ink)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 28, padding: '14px 40px' }}>
        <Logo size={20}/>
        <nav style={{ display: 'flex', gap: 4, marginLeft: 12 }}>
          {nav.map(n => (
            <button key={n.id} onClick={() => onNav && onNav(n.id)}
              style={{
                padding: '8px 14px', borderRadius: 999, background: 'transparent', border: 0, cursor: 'pointer',
                color: active === n.id ? (dark ? 'var(--bone)' : 'var(--ink)') : (dark ? 'rgba(248,244,234,.7)' : 'var(--ink-3)'),
                fontWeight: 500, fontSize: 14,
                background: active === n.id ? (dark ? 'rgba(248,244,234,.08)' : 'rgba(20,32,31,.05)') : 'transparent',
              }}>
              {n.label}
            </button>
          ))}
        </nav>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
          <CurrencyPill/>
          <span style={{ width: 1, height: 16, background: dark ? 'rgba(248,244,234,.18)' : 'var(--line-soft)' }}/>
          <LocalePill/>
          <button className="btn btn-sm btn-ghost" style={{ borderColor: dark ? 'rgba(248,244,234,.2)' : 'var(--line)', color: dark ? 'var(--bone)' : 'var(--ink)' }}>
            <I.user size={14}/> Sign in
          </button>
          <button className="btn btn-sm btn-coral">
            Book a viewing <I.arrowR size={14}/>
          </button>
        </div>
      </div>
    </header>
  );
}

// ─── Footer ───
function Footer({ tone = 'dark' }) {
  const dark = tone === 'dark';
  return (
    <footer style={{ background: dark ? 'var(--ink)' : 'var(--sand-soft)', color: dark ? 'var(--bone)' : 'var(--ink)', padding: '60px 40px 32px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr 1.2fr', gap: 40 }}>
        <div>
          <Logo size={22} color={dark ? 'var(--bone)' : 'var(--ink)'}/>
          <p style={{ marginTop: 14, fontSize: 13, lineHeight: 1.6, color: dark ? 'rgba(248,244,234,.65)' : 'var(--ink-3)', maxWidth: 280 }}>
            Pattaya's investor-grade property advisory.
            Licensed brokerage est. 2018. Member, Thai Real Estate Association.
          </p>
          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <FooterIcon><I.whatsapp size={16}/></FooterIcon>
            <FooterIcon><I.line size={16}/></FooterIcon>
            <FooterIcon><I.mail size={16}/></FooterIcon>
            <FooterIcon><I.phone size={16}/></FooterIcon>
          </div>
        </div>
        <FooterCol title="Browse" items={['New projects', 'Resale condos', 'Pool villas', 'Off-plan deals', 'Recently reduced']}/>
        <FooterCol title="Invest" items={['Foreign ownership', 'Rental yields', 'Cost calculator', 'Capital gains', 'Tax & legal']}/>
        <FooterCol title="Company" items={['About AMP', 'Our team', 'Press', 'Privacy', 'Careers']}/>
        <div>
          <div className="t-eyebrow" style={{ color: dark ? 'rgba(248,244,234,.5)' : 'var(--ink-4)', marginBottom: 14 }}>Office</div>
          <p style={{ fontSize: 13, lineHeight: 1.6, color: dark ? 'rgba(248,244,234,.8)' : 'var(--ink-2)' }}>
            333/12 Pratumnak Road<br/>
            Banglamung, Chonburi 20150<br/>
            Mon–Sat · 9:00–19:00 ICT
          </p>
          <div style={{ marginTop: 14, fontSize: 13 }}>
            <a href="#" style={{ color: dark ? 'var(--bone)' : 'var(--ink)' }}>+66 38 123 4567</a>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 48, paddingTop: 24, borderTop: dark ? '1px solid rgba(248,244,234,.1)' : '1px solid var(--line)', fontSize: 12, color: dark ? 'rgba(248,244,234,.5)' : 'var(--ink-4)' }}>
        <span>© 2026 AMP Pattaya Property Co., Ltd · License #BR-2018-0992</span>
        <span style={{ display: 'flex', gap: 18 }}>
          <span>Terms</span>
          <span>Privacy</span>
          <span>Disclosure</span>
        </span>
      </div>
    </footer>
  );
}

function FooterCol({ title, items }) {
  return (
    <div>
      <div className="t-eyebrow" style={{ color: 'inherit', opacity: 0.5, marginBottom: 14 }}>{title}</div>
      <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 9 }}>
        {items.map(i => <li key={i} style={{ fontSize: 13, opacity: 0.85, cursor: 'pointer' }}>{i}</li>)}
      </ul>
    </div>
  );
}

function FooterIcon({ children }) {
  return (
    <button style={{ width: 36, height: 36, borderRadius: 999, background: 'rgba(248,244,234,.08)', border: '1px solid rgba(248,244,234,.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'inherit', cursor: 'pointer' }}>
      {children}
    </button>
  );
}

// ─── Project card (large + small) ───
function ProjectCard({ project: p, size = 'lg', onClick }) {
  const { shortlist, toggleShortlist, currency } = useShare();
  const saved = shortlist.includes(p.id);
  const stop = (e) => { e.stopPropagation(); };
  return (
    <article onClick={onClick} className="card lift listing-card" style={{ background: 'var(--paper)', cursor: 'pointer' }}>
      <div className="photo" style={{ aspectRatio: size === 'lg' ? '4/3' : '3/2' }}>
        <img className="zoom-on-hover" src={p.cover} alt={p.name}/>
        <div style={{ position: 'absolute', top: 12, left: 12, display: 'flex', gap: 6 }}>
          {p.tag && <span className={`tag tag-${p.tagTone}`}>{p.tag}</span>}
        </div>
        <button onClick={(e) => { stop(e); toggleShortlist(p.id); }}
          style={{ position: 'absolute', top: 10, right: 10, width: 36, height: 36, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: saved ? 'var(--coral)' : 'var(--ink)' }}>
          {saved ? <I.heartFill size={16}/> : <I.heart size={16}/>}
        </button>
        <div style={{ position: 'absolute', bottom: 10, left: 12, color: '#fff', display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 500, textShadow: '0 1px 4px rgba(0,0,0,.4)' }}>
          <I.pin size={12}/> {p.area}
        </div>
      </div>
      <div style={{ padding: size === 'lg' ? '18px 20px 20px' : '14px 16px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8, marginBottom: 4 }}>
          <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: size === 'lg' ? 24 : 19, letterSpacing: '-0.01em', lineHeight: 1.15, fontWeight: 400 }}>{p.name}</h3>
        </div>
        <p style={{ margin: 0, fontSize: 12.5, color: 'var(--ink-4)' }}>{p.developer} · {p.completion}</p>
        <div className="divider" style={{ margin: '14px 0' }}/>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 12 }}>
          <Metric label="From" value={window.fmtPrice(p.startingPriceTHB, currency, { short: true })}/>
          <Metric label="Yield" value={`${p.rentalYieldPct}%`}/>
          <Metric label="Foreign quota" value={`${p.foreignQuotaPct}% of 49%`}/>
          <Metric label="Beach" value={p.distance_beach_m === 0 ? 'Beachfront' : `${p.distance_beach_m}m`}/>
        </div>
      </div>
    </article>
  );
}

function Metric({ label, value }) {
  return (
    <div>
      <div className="t-eyebrow" style={{ fontSize: 9.5, letterSpacing: '0.14em' }}>{label}</div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, letterSpacing: '-0.01em' }}>{value}</div>
    </div>
  );
}

// ─── Property card (compact, for listings) ───
function PropertyCard({ property: u, project: p, onClick }) {
  const { currency } = useShare();
  return (
    <article onClick={onClick} className="card lift" style={{ cursor: 'pointer' }}>
      <div className="photo" style={{ aspectRatio: '4/3' }}>
        <img className="zoom-on-hover" src={u.cover} alt={u.unit}/>
        {u.hot && <span className="tag tag-coral" style={{ position: 'absolute', top: 10, left: 10 }}><I.flame size={11}/> High interest</span>}
        <div style={{ position: 'absolute', bottom: 10, left: 12, color: '#fff', fontSize: 11.5, fontWeight: 500, textShadow: '0 1px 4px rgba(0,0,0,.5)' }}>
          {p ? `${p.name} · ${u.view}` : u.view}
        </div>
      </div>
      <div style={{ padding: '14px 16px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 2 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em' }}>
            {window.fmtPrice(u.priceTHB, currency, { short: true })}
          </span>
          <span style={{ fontSize: 11, color: 'var(--ink-4)' }}>{u.listed}</span>
        </div>
        <div style={{ fontSize: 13, color: 'var(--ink-3)', marginBottom: 10 }}>{u.unit}</div>
        <div style={{ display: 'flex', gap: 12, fontSize: 12, color: 'var(--ink-2)', alignItems: 'center' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><I.bed size={13}/> {u.bedrooms || 'Studio'}</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><I.bath size={13}/> {u.baths}</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><I.ruler size={13}/> {u.sqm} m²</span>
        </div>
      </div>
    </article>
  );
}

// ─── Trust strip (logos / metrics) ───
function TrustBar({ tone = 'sand' }) {
  const dark = tone === 'dark';
  const items = [
    ['฿4.2B', 'transacted 2025'],
    ['1,840', 'units sold'],
    ['96%', 'buyer NPS'],
    ['62%', 'foreign buyers'],
    ['12 yrs', 'in Pattaya'],
  ];
  return (
    <div style={{ background: dark ? 'var(--ink)' : 'var(--sand-soft)', color: dark ? 'var(--bone)' : 'var(--ink)', padding: '32px 40px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {items.map(([v, l], i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 36, letterSpacing: '-0.02em', lineHeight: 1 }}>{v}</span>
            <span style={{ fontSize: 12, color: dark ? 'rgba(248,244,234,.6)' : 'var(--ink-4)', marginTop: 4 }}>{l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Section header (eyebrow + display title + optional link) ───
function SectionHead({ eyebrow, title, kicker, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between', gap: 32, marginBottom: 28 }}>
      <div style={{ flex: 1, maxWidth: 720 }}>
        {eyebrow && <div className="t-eyebrow" style={{ marginBottom: 12 }}>{eyebrow}</div>}
        <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 44, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>
          {title}
        </h2>
        {kicker && <p style={{ margin: '12px 0 0', fontSize: 15, color: 'var(--ink-3)', maxWidth: 540 }}>{kicker}</p>}
      </div>
      {action && <div style={{ flexShrink: 0 }}>{action}</div>}
    </div>
  );
}

// ─── Lead form (inline / hero) ───
function LeadForm({ compact = false, dark = false, source = 'hero' }) {
  const [data, setData] = React.useState({ name: '', phone: '', email: '', whatsapp: true, budget: '5-10M', bedrooms: '1-2 BR', when: 'Within 3 months' });
  const [errors, setErrors] = React.useState({});
  const [sent, setSent] = React.useState(false);
  const set = (k, v) => setData(d => ({ ...d, [k]: v }));

  const submit = () => {
    const e = {};
    if (!data.name.trim()) e.name = 'Required';
    if (!data.phone.trim() && !data.email.trim()) e.phone = 'Phone or email required';
    setErrors(e);
    if (Object.keys(e).length === 0) setSent(true);
  };

  if (sent) {
    return (
      <div style={{
        padding: compact ? 24 : 32,
        background: dark ? 'rgba(248,244,234,.08)' : 'var(--paper)',
        color: dark ? 'var(--bone)' : 'var(--ink)',
        borderRadius: 'var(--r-lg)', border: dark ? '1px solid rgba(248,244,234,.18)' : '1px solid var(--line-soft)',
      }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--green-pale)', color: 'var(--green)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
          <I.check size={24}/>
        </div>
        <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.01em' }}>Thank you, {data.name.split(' ')[0]}.</h3>
        <p style={{ margin: '8px 0 16px', fontSize: 14, color: dark ? 'rgba(248,244,234,.7)' : 'var(--ink-3)' }}>
          Your dedicated advisor will reach you within 30 minutes on {data.whatsapp ? 'WhatsApp' : 'phone'}.
        </p>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-sm" style={{ background: '#25D366', color: '#fff' }}><I.whatsapp size={14}/> Open WhatsApp</button>
          <button className="btn btn-sm" style={{ background: '#06C755', color: '#fff' }}><I.line size={14}/> Open LINE</button>
        </div>
      </div>
    );
  }

  const inputStyle = {
    height: 48, width: '100%', padding: '0 14px', borderRadius: 'var(--r-md)',
    background: dark ? 'rgba(248,244,234,.06)' : 'var(--paper)',
    border: dark ? '1px solid rgba(248,244,234,.18)' : '1px solid var(--line)',
    color: dark ? 'var(--bone)' : 'var(--ink)',
    fontSize: 14,
  };

  return (
    <div style={{
      padding: compact ? 20 : 26,
      background: dark ? 'rgba(20,32,31,.55)' : 'var(--paper)',
      backdropFilter: dark ? 'blur(20px)' : 'none',
      color: dark ? 'var(--bone)' : 'var(--ink)',
      borderRadius: 'var(--r-lg)', border: dark ? '1px solid rgba(248,244,234,.16)' : '1px solid var(--line-soft)',
      boxShadow: dark ? '0 24px 60px -20px rgba(0,0,0,.4)' : 'var(--shadow-md)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <div className="t-eyebrow" style={{ color: dark ? 'rgba(248,244,234,.5)' : 'var(--ink-3)' }}>Get price & floor plan</div>
          <h3 style={{ margin: '6px 0 0', fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em' }}>Speak to an advisor</h3>
        </div>
        <span style={{ fontSize: 11, color: dark ? 'rgba(248,244,234,.5)' : 'var(--ink-4)' }}>
          <span className="dot dot-green" style={{ marginRight: 4 }}/> Reply in 30 min
        </span>
      </div>

      <div style={{ display: 'grid', gap: 10 }}>
        <input style={inputStyle} placeholder="Your name *" value={data.name} onChange={e => set('name', e.target.value)}/>
        {errors.name && <span style={{ fontSize: 11, color: 'var(--coral)' }}>{errors.name}</span>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <input style={inputStyle} placeholder="Phone (with code)" value={data.phone} onChange={e => set('phone', e.target.value)}/>
          <input style={inputStyle} placeholder="Email" value={data.email} onChange={e => set('email', e.target.value)}/>
        </div>
        {errors.phone && <span style={{ fontSize: 11, color: 'var(--coral)' }}>{errors.phone}</span>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <select style={inputStyle} value={data.budget} onChange={e => set('budget', e.target.value)}>
            {['Under 3M', '3-5M', '5-10M', '10-20M', '20-50M', '50M+'].map(o => <option key={o}>{o}</option>)}
          </select>
          <select style={inputStyle} value={data.bedrooms} onChange={e => set('bedrooms', e.target.value)}>
            {['Studio', '1-2 BR', '2-3 BR', '3+ BR / Villa'].map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
        <select style={inputStyle} value={data.when} onChange={e => set('when', e.target.value)}>
          {['Within 1 month', 'Within 3 months', '3-6 months', 'Just researching'].map(o => <option key={o}>{o}</option>)}
        </select>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, color: dark ? 'rgba(248,244,234,.7)' : 'var(--ink-3)', cursor: 'pointer', marginTop: 4 }}>
          <span className={`check ${data.whatsapp ? 'is-on' : ''}`} onClick={() => set('whatsapp', !data.whatsapp)}>
            {data.whatsapp && <I.check size={12}/>}
          </span>
          Contact me on WhatsApp · fastest reply
        </label>
        <button onClick={submit} className="btn btn-coral btn-lg btn-block" style={{ marginTop: 4 }}>
          Send & get a same-day reply <I.arrowR size={16}/>
        </button>
        <p style={{ margin: 0, fontSize: 11, color: dark ? 'rgba(248,244,234,.5)' : 'var(--ink-4)', textAlign: 'center' }}>
          By submitting you agree to be contacted by AMP Pattaya. No spam. Unsubscribe anytime.
        </p>
      </div>
    </div>
  );
}

// ─── Mobile sticky CTA bar ───
function MobileStickyCTA() {
  return (
    <div className="stickybar">
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
        <span style={{ fontSize: 10, opacity: 0.6, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Talk to an advisor</span>
        <span style={{ fontSize: 13, fontWeight: 500 }}>Reply in 30 min · 24/7</span>
      </div>
      <div style={{ display: 'flex', gap: 6, marginLeft: 'auto' }}>
        <button style={{ width: 40, height: 40, borderRadius: 999, background: '#25D366', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', cursor: 'pointer' }}><I.whatsapp size={18}/></button>
        <button style={{ width: 40, height: 40, borderRadius: 999, background: '#06C755', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', cursor: 'pointer' }}><I.line size={18}/></button>
        <button style={{ width: 40, height: 40, borderRadius: 999, background: 'var(--coral)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', cursor: 'pointer' }}><I.phone size={18}/></button>
      </div>
    </div>
  );
}

// ─── Mobile top bar ───
function MobileTopbar({ tone = 'light', title }) {
  const dark = tone === 'dark';
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px 12px', color: dark ? 'var(--bone)' : 'var(--ink)' }}>
      <button style={{ width: 38, height: 38, borderRadius: 999, background: dark ? 'rgba(248,244,234,.12)' : 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'inherit' }}>
        <I.menu size={18}/>
      </button>
      {title ? (
        <span style={{ fontSize: 14, fontWeight: 500 }}>{title}</span>
      ) : <Logo size={16} mark/>}
      <button style={{ width: 38, height: 38, borderRadius: 999, background: dark ? 'rgba(248,244,234,.12)' : 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'inherit' }}>
        <I.search size={18}/>
      </button>
    </div>
  );
}

// ─── Mobile bottom nav ───
function MobileBottomNav({ active = 'home' }) {
  const items = [
    { id: 'home',    label: 'Home',    icon: I.building },
    { id: 'search',  label: 'Search',  icon: I.search },
    { id: 'saved',   label: 'Saved',   icon: I.heart },
    { id: 'profile', label: 'Me',      icon: I.user },
  ];
  return (
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'var(--paper)', borderTop: '1px solid var(--line-soft)', padding: '8px 0 24px', display: 'flex', justifyContent: 'space-around' }}>
      {items.map(it => (
        <button key={it.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, background: 'transparent', border: 0, color: active === it.id ? 'var(--ink)' : 'var(--ink-4)', cursor: 'pointer' }}>
          <it.icon size={20}/>
          <span style={{ fontSize: 10, fontWeight: 500 }}>{it.label}</span>
        </button>
      ))}
    </div>
  );
}

Object.assign(window, {
  Logo, CurrencyPill, LocalePill,
  Topbar, Footer, FooterCol, FooterIcon,
  ProjectCard, PropertyCard, Metric,
  TrustBar, SectionHead, LeadForm,
  MobileStickyCTA, MobileTopbar, MobileBottomNav,
});
