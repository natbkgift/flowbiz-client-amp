// ─────────────────────────────────────────────────────────────
// Website Desktop: Smart Finder (quiz-style intake)
// ─────────────────────────────────────────────────────────────
function SmartFinder({ goto }) {
  const [step, setStep] = React.useState(2);  // start at q3 so user sees mid-flow
  const total = 7;
  const [data, setData] = React.useState({
    purpose: 'invest',
    budget: 8,
    timeline: '3-months',
    bedrooms: ['1br', '2br'],
    areas: ['wongamat', 'jomtien'],
    yield: 65,
    completion: 'any',
  });

  const set = (k, v) => setData(d => ({ ...d, [k]: v }));
  const toggle = (k, v) => setData(d => ({ ...d, [k]: d[k].includes(v) ? d[k].filter(x => x !== v) : [...d[k], v] }));

  // build progress
  const progress = ((step + 1) / total) * 100;

  return (
    <div className="frame" style={{ background: 'var(--bone)', display: 'flex', flexDirection: 'column' }}>
      {/* Minimal header */}
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px 40px', borderBottom: '1px solid var(--line-soft)' }}>
        <Logo size={20}/>
        <div style={{ flex: 1, maxWidth: 400, margin: '0 40px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--ink-3)', marginBottom: 6 }}>
            <span>Step {step + 1} of {total}</span>
            <span className="t-mono">{Math.round(progress)}%</span>
          </div>
          <div className="progress"><div style={{ width: `${progress}%`, background: 'var(--coral)' }}/></div>
        </div>
        <button onClick={() => goto && goto('home')} className="btn btn-sm btn-ghost">Exit <I.close size={12}/></button>
      </header>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 480px', gap: 0, overflow: 'hidden' }}>
        {/* Left: questions */}
        <div style={{ padding: '80px 80px', overflowY: 'auto', maxHeight: '100%' }}>
          <span className="t-eyebrow" style={{ color: 'var(--coral-2)' }}>Smart Finder · 90-second brief</span>
          <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 64, letterSpacing: '-0.025em', lineHeight: 1.02, fontWeight: 400, maxWidth: 640 }}>
            What's your <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>budget</em> in THB?
          </h1>
          <p style={{ margin: '18px 0 0', fontSize: 16, color: 'var(--ink-3)', maxWidth: 560, lineHeight: 1.6 }}>
            Pattaya inventory ranges from ฿2.8M studios to ฿80M penthouses.
            Move the slider — we'll show only what's within reach.
          </p>

          {/* Q3: budget slider — big interactive */}
          <div style={{ marginTop: 56, padding: '40px 0', borderTop: '1px solid var(--line-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 28 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 80, letterSpacing: '-0.03em', lineHeight: 1 }}>
                ฿{data.budget}M
              </span>
              <span style={{ fontSize: 14, color: 'var(--ink-3)' }}>
                ≈ {window.fmtPrice(data.budget * 1_000_000, 'USD')}
              </span>
            </div>
            <input type="range" min="2" max="80" value={data.budget}
              onChange={(e) => set('budget', +e.target.value)}
              style={{ width: '100%', accentColor: 'var(--coral)', height: 4 }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontSize: 11, color: 'var(--ink-4)' }} className="t-mono">
              <span>฿2M</span><span>฿20M</span><span>฿40M</span><span>฿60M</span><span>฿80M+</span>
            </div>

            <p style={{ marginTop: 32, padding: 16, background: 'var(--paper-warm)', borderRadius: 10, fontSize: 13.5, color: 'var(--ink-2)' }}>
              <strong style={{ color: 'var(--coral-2)' }}>72 listings</strong> match this budget across 18 projects · 4 areas
            </p>
          </div>

          {/* Tiny preview of previous answers */}
          <div style={{ marginTop: 32 }}>
            <h4 style={{ margin: 0, fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Your answers so far</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 12 }}>
              <span className="tag tag-paper">Purpose: Investment</span>
              <span className="tag tag-paper">Bedrooms: 1BR · 2BR</span>
              <span className="tag tag-paper">Areas: Wongamat · Jomtien</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12, marginTop: 56 }}>
            <button onClick={() => setStep(s => Math.max(0, s - 1))} className="btn btn-lg btn-paper" disabled={step === 0}><I.chevL size={14}/> Back</button>
            <button onClick={() => setStep(s => Math.min(total - 1, s + 1))} className="btn btn-lg btn-coral" style={{ flex: 1 }}>Continue <I.arrowR size={16}/></button>
          </div>
        </div>

        {/* Right: live preview pane */}
        <aside style={{ background: 'var(--ink)', color: 'var(--bone)', padding: '64px 56px', overflow: 'auto' }}>
          <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>Live matches · updates as you answer</span>
          <h3 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 36, letterSpacing: '-0.015em', lineHeight: 1.1, fontWeight: 400 }}>
            Your shortlist is shaping up
          </h3>
          <p style={{ margin: '10px 0 0', fontSize: 13, color: 'rgba(248,244,234,.6)' }}>3 strong matches, 4 worth considering</p>

          <div style={{ marginTop: 32, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {PROJECTS.slice(0, 4).map((p, i) => {
              const match = [94, 88, 76, 64][i];
              const tone = match >= 85 ? '#7dca8e' : match >= 70 ? 'var(--champagne)' : 'rgba(248,244,234,.5)';
              return (
                <div key={p.id} style={{ display: 'flex', gap: 12, padding: 12, background: 'rgba(248,244,234,.06)', borderRadius: 12, border: '1px solid rgba(248,244,234,.1)' }}>
                  <div style={{ width: 72, height: 72, borderRadius: 8, background: `url(${p.cover}) center/cover`, flexShrink: 0 }}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: 17, letterSpacing: '-0.005em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                      <span style={{ fontSize: 11, color: tone, fontFamily: 'var(--font-mono)', flexShrink: 0 }}>{match}%</span>
                    </div>
                    <div style={{ fontSize: 11.5, color: 'rgba(248,244,234,.6)' }}>{p.area} · From ฿{(p.startingPriceTHB / 1_000_000).toFixed(1)}M</div>
                    <div style={{ marginTop: 6, height: 3, background: 'rgba(248,244,234,.1)', borderRadius: 99, overflow: 'hidden' }}>
                      <div style={{ width: `${match}%`, height: '100%', background: tone }}/>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ marginTop: 32, padding: 18, background: 'rgba(217,106,78,.08)', border: '1px solid rgba(217,106,78,.3)', borderRadius: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, fontSize: 12, color: 'var(--coral)', fontWeight: 500 }}>
              <I.sparkle size={14}/> Almost there
            </div>
            <p style={{ margin: 0, fontSize: 13, color: 'rgba(248,244,234,.8)', lineHeight: 1.5 }}>
              Answer 4 more questions to get a curated PDF brief sent to your inbox within 30 minutes.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}

window.SmartFinder = SmartFinder;
