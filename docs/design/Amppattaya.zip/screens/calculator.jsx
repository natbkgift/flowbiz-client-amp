// ─────────────────────────────────────────────────────────────
// Website Desktop: Cost Estimator
// Detailed buy-cost + rental-yield calculator
// ─────────────────────────────────────────────────────────────
function Calculator({ goto }) {
  const { currency } = useShare();
  const [price, setPrice] = React.useState(14_800_000);
  const [down, setDown] = React.useState(30);
  const [years, setYears] = React.useState(15);
  const [rate, setRate] = React.useState(6.5);
  const [occupancy, setOccupancy] = React.useState(72);
  const [adr, setAdr] = React.useState(4800);
  const [mgmtFee, setMgmtFee] = React.useState(15);

  const downAmount = price * (down / 100);
  const loan = price - downAmount;
  const monthlyRate = rate / 100 / 12;
  const months = years * 12;
  const monthlyPayment = loan > 0 ? (loan * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1) : 0;
  const transferFee = price * 0.02;
  const sinking = 42000;
  const legal = 35000;
  const totalUpfront = downAmount + transferFee + sinking + legal;

  const annualGross = adr * 365 * (occupancy / 100);
  const annualMgmt = annualGross * (mgmtFee / 100);
  const rentalTax = annualGross * 0.125;
  const cam = 80 * 80 * 12;  // 80sqm at ฿80/m²/mo
  const sinkingAnnual = 5000;
  const annualNet = annualGross - annualMgmt - rentalTax - cam - sinkingAnnual;
  const cashYield = (annualNet / price) * 100;

  // Year-over-year projection 5y
  const years5 = Array.from({ length: 5 }, (_, i) => {
    const appreciation = price * Math.pow(1.07, i + 1) - price;  // 7% YoY
    const cumNet = annualNet * (i + 1);
    return { y: i + 1, app: appreciation, net: cumNet };
  });

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="invest" onNav={goto}/>

      <section style={{ padding: '40px 40px 24px' }}>
        <span className="t-eyebrow">Investor toolkit</span>
        <h1 style={{ margin: '10px 0 0', fontFamily: 'var(--font-display)', fontSize: 64, letterSpacing: '-0.025em', lineHeight: 1.02, fontWeight: 400 }}>
          <em style={{ fontStyle: 'italic' }}>Total-cost &</em> rental yield calculator
        </h1>
        <p style={{ margin: '14px 0 0', fontSize: 16, color: 'var(--ink-3)', maxWidth: 700 }}>
          Run the numbers before you fly out. Adjust inputs on the left, see the live cash-flow,
          yield, and 5-year ROI on the right.
        </p>
      </section>

      <section style={{ padding: '24px 40px 80px', display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 32, alignItems: 'start' }}>
        {/* Inputs */}
        <div style={{ background: 'var(--paper)', borderRadius: 16, padding: 28, border: '1px solid var(--line-soft)' }}>
          <h3 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>Property</h3>
          <div style={{ marginTop: 16 }}>
            <CalcSlider label="Purchase price" value={price} min={2_000_000} max={80_000_000} step={100_000} format={(v) => window.fmtPrice(v, currency)} onChange={setPrice}/>
          </div>

          <div style={{ marginTop: 28, paddingTop: 22, borderTop: '1px solid var(--line-soft)' }}>
            <h3 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>Financing</h3>
            <CalcSlider label="Down payment" value={down} min={0} max={100} step={5} format={(v) => `${v}%`} onChange={setDown}/>
            <CalcSlider label="Mortgage term" value={years} min={5} max={30} step={1} format={(v) => `${v} years`} onChange={setYears}/>
            <CalcSlider label="Interest rate" value={rate} min={0} max={12} step={0.1} format={(v) => `${v.toFixed(1)}%`} onChange={setRate}/>
          </div>

          <div style={{ marginTop: 28, paddingTop: 22, borderTop: '1px solid var(--line-soft)' }}>
            <h3 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>Rental income</h3>
            <CalcSlider label="Avg. daily rate" value={adr} min={1500} max={12000} step={100} format={(v) => `฿${v.toLocaleString()}`} onChange={setAdr}/>
            <CalcSlider label="Occupancy" value={occupancy} min={20} max={95} step={1} format={(v) => `${v}%`} onChange={setOccupancy}/>
            <CalcSlider label="Mgmt fee" value={mgmtFee} min={0} max={30} step={1} format={(v) => `${v}%`} onChange={setMgmtFee}/>
          </div>

          <div style={{ marginTop: 22, padding: 14, background: 'var(--paper-warm)', borderRadius: 10, fontSize: 12, color: 'var(--ink-3)', display: 'flex', gap: 8 }}>
            <I.info size={14} style={{ flexShrink: 0, marginTop: 1 }}/>
            Defaults reflect 2025 AMP-managed unit averages in Wongamat (2BR, sea view).
          </div>
        </div>

        {/* Outputs */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Headline */}
          <div style={{ padding: 32, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 16, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32 }}>
            <div>
              <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Cash yield p.a.</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 60, letterSpacing: '-0.02em', lineHeight: 1, marginTop: 8, color: 'var(--champagne)' }}>{cashYield.toFixed(1)}%</div>
              <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', marginTop: 6 }}>Net of fees, taxes, CAM</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Total cash to close</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 38, letterSpacing: '-0.02em', lineHeight: 1, marginTop: 8 }}>{window.fmtPrice(totalUpfront, currency, { short: true })}</div>
              <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', marginTop: 6 }}>Down + fees + legal</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Monthly cash flow</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 38, letterSpacing: '-0.02em', lineHeight: 1, marginTop: 8 }}>+{window.fmtPrice(annualNet / 12, currency, { short: true })}</div>
              <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', marginTop: 6 }}>Net after mortgage: {window.fmtPrice(annualNet / 12 - monthlyPayment, currency, { short: true })}/mo</div>
            </div>
          </div>

          {/* Cost breakdown */}
          <div style={{ background: 'var(--paper)', borderRadius: 16, padding: 28, border: '1px solid var(--line-soft)' }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em', fontWeight: 400 }}>Upfront cost breakdown</h3>
            <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 4 }}>
              {[
                ['Down payment', downAmount, 'var(--ink)'],
                ['Transfer fee (2%)', transferFee, 'var(--coral)'],
                ['Sinking fund', sinking, 'var(--champagne)'],
                ['Legal & escrow', legal, 'var(--teal)'],
              ].map(([l, v, c], i) => {
                const pct = (v / totalUpfront) * 100;
                return (
                  <div key={l}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13 }}>
                      <span>{l}</span>
                      <span className="t-mono">{window.fmtPrice(v, currency)}</span>
                    </div>
                    <div style={{ height: 6, background: 'var(--line-soft)', borderRadius: 99, overflow: 'hidden' }}>
                      <div style={{ width: `${pct}%`, height: '100%', background: c }}/>
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{ marginTop: 16, padding: '14px 0 0', borderTop: '1px solid var(--line-soft)', display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 14, fontWeight: 500 }}>Total upfront</span>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em' }}>{window.fmtPrice(totalUpfront, currency)}</span>
            </div>
          </div>

          {/* 5-year projection */}
          <div style={{ background: 'var(--paper)', borderRadius: 16, padding: 28, border: '1px solid var(--line-soft)' }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em', fontWeight: 400 }}>5-year return projection</h3>
            <p style={{ margin: '6px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>Capital appreciation (7% YoY conservative) + cumulative net rental</p>
            <div style={{ marginTop: 22, position: 'relative', height: 200 }}>
              <svg viewBox="0 0 500 200" style={{ width: '100%', height: '100%' }}>
                {[0, 1, 2, 3, 4].map(i => <line key={i} x1="0" x2="500" y1={40 * i} y2={40 * i} stroke="var(--line-soft)" strokeWidth="1"/>)}
                {(() => {
                  const max = Math.max(...years5.flatMap(d => [d.app, d.net])) * 1.1;
                  return (
                    <>
                      {/* App bars */}
                      {years5.map((d, i) => {
                        const x = 30 + i * 95;
                        const hApp = (d.app / max) * 160;
                        const hNet = (d.net / max) * 160;
                        return (
                          <g key={i}>
                            <rect x={x} y={180 - hApp} width="32" height={hApp} fill="var(--coral)" rx="2"/>
                            <rect x={x + 36} y={180 - hNet} width="32" height={hNet} fill="var(--teal)" rx="2"/>
                            <text x={x + 35} y={195} textAnchor="middle" fontSize="11" fill="var(--ink-4)">Y{d.y}</text>
                          </g>
                        );
                      })}
                    </>
                  );
                })()}
              </svg>
            </div>
            <div style={{ display: 'flex', gap: 24, marginTop: 16, fontSize: 12 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--coral)' }}/> Capital appreciation</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--teal)' }}/> Cumulative net rental</span>
              <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', color: 'var(--ink-3)' }}>5-yr ROI: <strong style={{ color: 'var(--ink)' }}>+{(((years5[4].app + years5[4].net) / totalUpfront) * 100).toFixed(0)}%</strong></span>
            </div>
          </div>

          {/* CTA */}
          <div style={{ padding: 24, background: 'var(--sand-soft)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20 }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22 }}>Want a verified projection for a real unit?</div>
              <div style={{ fontSize: 13, color: 'var(--ink-3)', marginTop: 4 }}>We'll send a custom report based on actual comps in 24 hours.</div>
            </div>
            <button className="btn btn-coral btn-lg">Request projection <I.arrowR size={14}/></button>
          </div>
        </div>
      </section>

      <Footer/>
    </div>
  );
}

function CalcSlider({ label, value, min, max, step, format, onChange }) {
  return (
    <div style={{ marginTop: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
        <span style={{ color: 'var(--ink-3)' }}>{label}</span>
        <span className="t-mono" style={{ color: 'var(--ink)', fontWeight: 500 }}>{format(value)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(+e.target.value)}
        style={{ width: '100%', accentColor: 'var(--teal)' }}/>
    </div>
  );
}

window.Calculator = Calculator;
