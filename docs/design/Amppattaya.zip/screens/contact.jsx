// ─────────────────────────────────────────────────────────────
// Website Desktop: Contact / Lead Capture
// ─────────────────────────────────────────────────────────────
function ContactPage({ goto }) {
  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="contact" onNav={goto}/>

      {/* Hero */}
      <section style={{ padding: '64px 40px 32px', display: 'grid', gridTemplateColumns: '1fr 480px', gap: 64 }}>
        <div>
          <span className="t-eyebrow">Speak to AMP</span>
          <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 88, letterSpacing: '-0.03em', lineHeight: 0.98, fontWeight: 400 }}>
            One advisor.<br/>
            <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>Your language.</em><br/>
            Same-day reply.
          </h1>
          <p style={{ margin: '24px 0 0', fontSize: 17, color: 'var(--ink-3)', maxWidth: 540, lineHeight: 1.6 }}>
            Pick the channel that suits you. We reply within 30 minutes during ICT working hours,
            and the next morning otherwise. No call centres.
          </p>

          {/* Channel cards */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 40 }}>
            {[
              { i: <I.whatsapp size={22}/>, t: 'WhatsApp', d: '+66 81 234 5678 · fastest reply', c: '#25D366' },
              { i: <I.line size={22}/>,     t: 'LINE',     d: '@amppattaya · QR below',         c: '#06C755' },
              { i: <I.phone size={22}/>,    t: 'Phone',    d: '+66 38 123 4567 · 9–19 ICT',    c: 'var(--coral)' },
              { i: <I.mail size={22}/>,     t: 'Email',    d: 'invest@amppattaya.com',         c: 'var(--ink)' },
            ].map((ch, i) => (
              <div key={i} style={{ padding: 22, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)', display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer' }} className="lift">
                <div style={{ width: 46, height: 46, borderRadius: 12, background: ch.c, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{ch.i}</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{ch.t}</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-4)' }}>{ch.d}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Office */}
          <div style={{ marginTop: 40, padding: 24, background: 'var(--sand-soft)', borderRadius: 14 }}>
            <span className="t-eyebrow">Visit us · open without appointment</span>
            <h3 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', fontWeight: 400 }}>333/12 Pratumnak Road, Banglamung</h3>
            <p style={{ margin: '8px 0 0', fontSize: 13.5, color: 'var(--ink-3)' }}>
              Chonburi 20150, Thailand · Mon–Sat 9:00–19:00 ICT · Free valet
            </p>
            <button className="btn btn-paper" style={{ marginTop: 14 }}><I.map size={14}/> Open in Google Maps</button>
          </div>
        </div>

        <aside style={{ position: 'sticky', top: 100, alignSelf: 'start' }}>
          <LeadForm/>
        </aside>
      </section>

      {/* Team */}
      <section style={{ padding: '80px 40px' }}>
        <SectionHead eyebrow="Our team" title={<>Specialised by <em style={{ fontStyle: 'italic' }}>language &amp; investor profile</em></>}/>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16 }}>
          {AGENTS.map(a => (
            <div key={a.id} style={{ padding: 22, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)', textAlign: 'center' }} className="lift">
              <img src={a.avatar} style={{ width: 88, height: 88, borderRadius: '50%', objectFit: 'cover', margin: '0 auto 14px' }}/>
              <h4 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 20, letterSpacing: '-0.005em', fontWeight: 400 }}>{a.name}</h4>
              <div style={{ fontSize: 12, color: 'var(--ink-4)', marginTop: 4 }}>{a.role}</div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginTop: 8, fontSize: 11, color: 'var(--ink-3)' }}>
                <I.starFill size={10} color="var(--champagne)"/> {a.rating} · {a.deals} closed
              </div>
              <div style={{ marginTop: 10, fontSize: 11, color: 'var(--ink-4)' }}>{a.lang}</div>
              <button className="btn btn-sm btn-paper" style={{ marginTop: 12 }}>Book with {a.name.split(' ')[0]}</button>
            </div>
          ))}
        </div>
      </section>

      <TrustBar/>
      <Footer/>
    </div>
  );
}

window.ContactPage = ContactPage;
