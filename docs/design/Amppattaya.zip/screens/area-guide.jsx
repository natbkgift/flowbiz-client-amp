// ─────────────────────────────────────────────────────────────
// Website Desktop: Area Guide + Foreign Quota Explainer
// ─────────────────────────────────────────────────────────────
function AreaGuide({ goto, areaId }) {
  const area = window.AREAS.find(a => a.id === areaId) || window.AREAS[0];
  const { currency } = useShare();
  const areaProjects = PROJECTS.filter(p => p.area.toLowerCase().includes(area.id) || p.area.toLowerCase().replace(/\s+/g, '') === area.id);
  const fallback = PROJECTS.slice(0, 3);
  const items = areaProjects.length ? areaProjects : fallback;

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="areas" onNav={goto}/>

      {/* Area pills nav */}
      <div style={{ padding: '20px 40px', borderBottom: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', overflow: 'auto' }}>
          <span className="t-eyebrow" style={{ marginRight: 8 }}>Areas</span>
          {window.AREAS.map(a => (
            <button key={a.id} onClick={() => goto && goto('areas', a.id)}
              style={{ padding: '6px 14px', borderRadius: 999, border: '1px solid var(--line)', background: a.id === area.id ? 'var(--ink)' : 'var(--paper)', color: a.id === area.id ? 'var(--bone)' : 'var(--ink-2)', fontSize: 13, fontWeight: 500, cursor: 'pointer', whiteSpace: 'nowrap' }}>
              {a.name}
            </button>
          ))}
        </div>
      </div>

      {/* Hero */}
      <section style={{ position: 'relative', height: 560, overflow: 'hidden' }}>
        <img src={area.img} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}/>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(20,32,31,.3) 0%, rgba(20,32,31,.65) 100%)' }}/>
        <div style={{ position: 'absolute', inset: 0, padding: '64px 40px', color: 'var(--bone)', display: 'flex', flexDirection: 'column', justifyContent: 'end' }}>
          <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>Pattaya · Area guide</span>
          <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 120, letterSpacing: '-0.03em', lineHeight: 0.95, fontWeight: 400 }}>
            {area.name}
          </h1>
          <p style={{ margin: '20px 0 0', fontSize: 18, color: 'rgba(248,244,234,.85)', maxWidth: 640 }}>{area.vibe} · {area.beach}</p>
          <div style={{ display: 'flex', gap: 32, marginTop: 40 }}>
            {[['Listings', `${area.count}`], ['Median price', '฿8.4M'], ['Median yield', '6.2%'], ['YoY growth', '+11%']].map(([l, v]) => (
              <div key={l}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1 }}>{v}</div>
                <div style={{ fontSize: 11.5, color: 'rgba(248,244,234,.6)', marginTop: 4 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Body */}
      <section style={{ padding: '64px 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56 }}>
        <div>
          <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>The {area.name} thesis</h2>
          <p style={{ margin: '20px 0 0', fontSize: 16, color: 'var(--ink-2)', lineHeight: 1.7 }}>
            {area.name} sits on Pattaya's most protected stretch of beach — a private cove backed by a hillside reserve
            that prevents future high-density development. The result: low supply, high tenant retention,
            and the city's steadiest capital appreciation curve over the last decade.
          </p>
          <p style={{ margin: '14px 0 0', fontSize: 16, color: 'var(--ink-2)', lineHeight: 1.7 }}>
            Renters skew long-stay European retirees, expat families on school-year leases,
            and Bangkok C-suite weekenders. Short-stay regulation is lighter here than in Central Pattaya,
            making Airbnb-style cash flow viable.
          </p>
          <h3 style={{ margin: '40px 0 16px', fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em', fontWeight: 400 }}>Best for</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
            {['Long-term capital growth', 'Family residence', 'European retirees', 'Stable yield'].map(t => (
              <div key={t} style={{ padding: '10px 14px', background: 'var(--paper)', border: '1px solid var(--line-soft)', borderRadius: 8, fontSize: 13.5 }}>
                <I.check size={13} color="var(--green)" style={{ display: 'inline', verticalAlign: -2, marginRight: 6 }}/>
                {t}
              </div>
            ))}
          </div>
          <h3 style={{ margin: '40px 0 16px', fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em', fontWeight: 400 }}>Watch out for</h3>
          <div style={{ padding: 18, background: 'var(--paper-warm)', borderRadius: 10, fontSize: 13.5, color: 'var(--ink-2)', lineHeight: 1.6, border: '1px solid var(--line-soft)' }}>
            <strong>Foreign quota tightens here.</strong> Wongamat's prime towers regularly cap their 49% foreign allocation before launch closes.
            Reserve early — AMP holds priority allocation on 8 of the 11 active projects in this zone.
          </div>
        </div>

        {/* Mini map of the area */}
        <div>
          <div style={{ height: 460, borderRadius: 16, overflow: 'hidden', border: '1px solid var(--line-soft)', position: 'relative' }} className="map-bg">
            {items.map(p => (
              <button key={p.id} onClick={() => goto && goto('project', p.id)}
                style={{ position: 'absolute', left: `${p.coords.x}%`, top: `${p.coords.y}%`, transform: 'translate(-50%, -100%)', background: 'var(--coral)', color: '#fff', padding: '6px 10px', borderRadius: 999, fontSize: 11, fontFamily: 'var(--font-mono)', border: 0, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                {window.fmtPrice(p.startingPriceTHB, currency, { short: true })}
              </button>
            ))}
          </div>
          {/* What's nearby */}
          <div style={{ marginTop: 20, padding: 22, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
            <h4 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>What's nearby</h4>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['Wongamat Beach', '1 min walk', <I.wave size={14}/>],
                ['Terminal 21 Mall', '4 min drive', <I.tag size={14}/>],
                ['Sanctuary of Truth', '8 min drive', <I.star size={14}/>],
                ['International School (St. Andrews)', '12 min', <I.document size={14}/>],
                ['U-Tapao Airport', '32 min', <I.globe size={14}/>],
                ['Bangkok (Highway 7)', '90 min', <I.map size={14}/>],
              ].map(([n, t, i], idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 0', borderBottom: idx < 5 ? '1px solid var(--line-soft)' : 'none' }}>
                  <span style={{ color: 'var(--teal)' }}>{i}</span>
                  <span style={{ flex: 1, fontSize: 13 }}>{n}</span>
                  <span style={{ fontSize: 12, color: 'var(--ink-4)' }} className="t-mono">{t}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Projects in area */}
      <section style={{ padding: '24px 40px 80px' }}>
        <SectionHead eyebrow={`Projects in ${area.name}`} title="Current inventory"/>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {items.map(p => <ProjectCard key={p.id} project={p} onClick={() => goto && goto('project', p.id)}/>)}
        </div>
      </section>

      <Footer/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Foreign Quota Explainer
// ─────────────────────────────────────────────────────────────
function QuotaExplainer({ goto }) {
  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="invest" onNav={goto}/>

      <section style={{ padding: '80px 40px 40px', display: 'grid', gridTemplateColumns: '1fr 460px', gap: 64 }}>
        <div>
          <span className="t-eyebrow">Foreign ownership in Thailand</span>
          <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 88, letterSpacing: '-0.03em', lineHeight: 0.98, fontWeight: 400 }}>
            Yes, you can own a condo<br/>
            <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>outright</em>. Here's exactly how.
          </h1>
          <p style={{ margin: '24px 0 0', fontSize: 17, color: 'var(--ink-3)', lineHeight: 1.7, maxWidth: 620 }}>
            Thai law has allowed non-residents to own condominium units in freehold since 1979.
            The rule is simple — up to 49% of any single building can be foreign-owned, capped per project.
            Land and detached villas require different structures, which we cover below.
          </p>

          <div style={{ marginTop: 48, padding: 32, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 16, position: 'relative', overflow: 'hidden' }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 400 }}>The 49% rule, visualised</h3>
            <p style={{ margin: '8px 0 22px', fontSize: 13, color: 'rgba(248,244,234,.65)' }}>Every condominium in Thailand follows the same split.</p>
            <div style={{ display: 'flex', height: 80, borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ width: '51%', background: 'rgba(248,244,234,.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: 'var(--bone)' }}>51%</div>
                <div style={{ fontSize: 11, color: 'rgba(248,244,234,.7)' }}>Thai-owned (required)</div>
              </div>
              <div style={{ width: '49%', background: 'var(--champagne)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: 'var(--ink)' }}>49%</div>
                <div style={{ fontSize: 11, color: 'var(--ink-2)' }}>Available to foreigners</div>
              </div>
            </div>
            <p style={{ margin: '20px 0 0', fontSize: 13, color: 'rgba(248,244,234,.7)' }}>
              Once a building hits 49% foreign ownership, no further foreign-quota sales are possible until a foreign-owned unit transfers to a Thai national. We check live status before every offer.
            </p>
          </div>

          {/* Process steps */}
          <h2 style={{ margin: '64px 0 24px', fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>The 6 steps to ownership</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {[
              ['01', 'Pick a unit', 'AMP confirms the unit is within the foreign-quota allocation.'],
              ['02', 'Reservation', 'You pay a 100,000 ฿ reservation, refundable for 14 days.'],
              ['03', 'Sales contract', 'Independent lawyer reviews. Bilingual EN/TH. AMP pays for first review.'],
              ['04', 'FET form', 'Transfer purchase funds from abroad. Bank issues FET form — proof for future repatriation.'],
              ['05', 'Transfer day', 'You (or your power-of-attorney) meet at the Land Office. Title (chanote) issued same day.'],
              ['06', 'Hand-over', 'AMP property management begins immediately if you opt into the rental program.'],
            ].map(([n, t, d]) => (
              <div key={n} style={{ padding: 24, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--coral-2)', marginBottom: 8 }}>{n}</div>
                <h4 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>{t}</h4>
                <p style={{ margin: '8px 0 0', fontSize: 13, color: 'var(--ink-3)', lineHeight: 1.5 }}>{d}</p>
              </div>
            ))}
          </div>

          {/* Villa / land options */}
          <h2 style={{ margin: '64px 0 16px', fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>What about <em style={{ fontStyle: 'italic' }}>villas &amp; land?</em></h2>
          <p style={{ margin: 0, fontSize: 15, color: 'var(--ink-3)' }}>Foreigners cannot directly own land. Two legal structures make villas accessible:</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 22 }}>
            {[
              { t: '30-year lease', d: 'Lease the land for 30 years, renewable twice. Most common, cheapest, full enjoyment rights. Lease is registered at the Land Office.', tone: 'green' },
              { t: 'Thai limited company', d: 'You own the structure; a company you control owns the land. Requires 3 Thai shareholders (49/51 cap applies). AMP works with two trusted firms.', tone: 'amber' },
            ].map((it, i) => (
              <div key={i} style={{ padding: 22, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
                <h4 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>{it.t}</h4>
                <p style={{ margin: '8px 0 0', fontSize: 13, color: 'var(--ink-3)', lineHeight: 1.55 }}>{it.d}</p>
              </div>
            ))}
          </div>
        </div>

        <aside style={{ position: 'sticky', top: 100, alignSelf: 'start' }}>
          <LeadForm/>
          <div style={{ marginTop: 16, padding: 22, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <h4 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>Free 30-min legal call</h4>
            <p style={{ margin: '6px 0 14px', fontSize: 12.5, color: 'var(--ink-4)' }}>With an independent Pattaya property lawyer · in your language</p>
            <button className="btn btn-paper btn-block"><I.calendar size={14}/> Book a slot</button>
          </div>
        </aside>
      </section>

      <Footer/>
    </div>
  );
}

window.AreaGuide = AreaGuide;
window.QuotaExplainer = QuotaExplainer;
