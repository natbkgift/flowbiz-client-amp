// ─────────────────────────────────────────────────────────────
// Website Desktop: Project Detail
// Most conversion-critical page after homepage
// ─────────────────────────────────────────────────────────────
function ProjectDetail({ goto, projectId }) {
  const { currency, shortlist, toggleShortlist, toggleCompare, compare } = useShare();
  const p = PROJECTS.find(x => x.id === projectId) || PROJECTS[0];
  const [activeImg, setActiveImg] = React.useState(0);
  const [section, setSection] = React.useState('overview');
  const saved = shortlist.includes(p.id);

  // related units in this project
  const units = PROPERTIES.filter(u => u.projectId === p.id);

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="projects" onNav={goto}/>

      {/* ── Breadcrumb + actions ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px 40px', borderBottom: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--ink-4)' }}>
          <span onClick={() => goto && goto('home')} style={{ cursor: 'pointer' }}>Home</span>
          <I.chevR size={12}/>
          <span onClick={() => goto && goto('projects')} style={{ cursor: 'pointer' }}>Projects</span>
          <I.chevR size={12}/>
          <span style={{ color: 'var(--ink)' }}>{p.name}</span>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => toggleShortlist(p.id)} className="btn btn-sm btn-ghost" style={{ color: saved ? 'var(--coral)' : 'var(--ink)' }}>
            {saved ? <I.heartFill size={14} color="var(--coral)"/> : <I.heart size={14}/>} {saved ? 'Saved' : 'Save'}
          </button>
          <button onClick={() => toggleCompare(p.id)} className="btn btn-sm btn-ghost"><I.compare size={14}/> Compare</button>
          <button className="btn btn-sm btn-ghost"><I.share size={14}/> Share</button>
          <button className="btn btn-sm btn-ghost"><I.download size={14}/> Brochure</button>
        </div>
      </div>

      {/* ── Gallery ── */}
      <section style={{ padding: '24px 40px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gridTemplateRows: '260px 260px', gap: 8, borderRadius: 16, overflow: 'hidden' }}>
          <div className="photo" style={{ gridRow: '1 / span 2' }}><img src={p.gallery[0]} alt=""/></div>
          {p.gallery.slice(1, 5).map((g, i) => (
            <div key={i} className="photo">
              <img src={g} alt=""/>
              {i === 3 && (
                <button style={{ position: 'absolute', right: 12, bottom: 12, padding: '8px 14px', borderRadius: 999, background: 'rgba(255,255,255,.95)', border: 0, fontSize: 12, fontWeight: 500, cursor: 'pointer' }}>
                  <I.grid size={12} style={{ display: 'inline', verticalAlign: -2, marginRight: 6 }}/> All 48 photos
                </button>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ── Title + summary + sticky form ── */}
      <section style={{ padding: '40px 40px 0', display: 'grid', gridTemplateColumns: '1fr 400px', gap: 56, alignItems: 'start' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <span className={`tag tag-${p.tagTone}`}>{p.tag}</span>
            <span className="tag tag-paper"><I.shield size={11}/> AMP verified</span>
            <span className="tag tag-paper"><I.fire size={11}/> 14 viewings this week</span>
          </div>
          <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 72, letterSpacing: '-0.025em', lineHeight: 1, fontWeight: 400 }}>
            {p.name}
          </h1>
          <p style={{ margin: '14px 0 0', fontSize: 15, color: 'var(--ink-3)' }}>
            <I.pin size={14} style={{ display: 'inline', verticalAlign: -3, marginRight: 6 }}/>
            {p.area}, Pattaya · by <strong style={{ color: 'var(--ink)', fontWeight: 500 }}>{p.developer}</strong>
          </p>
          <p style={{ margin: '20px 0 0', fontSize: 17, color: 'var(--ink-2)', lineHeight: 1.6, maxWidth: 660 }}>
            {p.summary} {p.tagline}
          </p>

          {/* Stat row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 40 }}>
            {[
              { l: 'From price', v: window.fmtPrice(p.startingPriceTHB, currency, { short: true }), s: window.fmtPrice(p.pricePerSqmTHB, currency, { short: true }) + ' / m²' },
              { l: 'Rental yield', v: `${p.rentalYieldPct}%`, s: 'gross, projected' },
              { l: 'Completion', v: p.completion, s: p.status },
              { l: 'Foreign quota', v: `${p.foreignQuotaPct}%`, s: `of 49% allowed` },
            ].map((s, i) => (
              <div key={i} style={{ padding: '20px 22px', background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
                <div className="t-eyebrow" style={{ fontSize: 10 }}>{s.l}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 30, letterSpacing: '-0.01em', lineHeight: 1, marginTop: 8 }}>{s.v}</div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-4)', marginTop: 6 }}>{s.s}</div>
              </div>
            ))}
          </div>

          {/* Sticky section nav */}
          <div style={{ display: 'flex', gap: 4, marginTop: 48, marginBottom: 24, padding: '4px', background: 'var(--sand-soft)', borderRadius: 999, width: 'fit-content' }}>
            {[
              ['overview', 'Overview'],
              ['units', 'Units & plans'],
              ['amenities', 'Amenities'],
              ['investment', 'Investment'],
              ['location', 'Location'],
              ['developer', 'Developer'],
              ['faq', 'FAQ'],
            ].map(([id, l]) => (
              <button key={id} onClick={() => setSection(id)} style={{
                padding: '8px 14px', borderRadius: 999, border: 0,
                background: section === id ? 'var(--ink)' : 'transparent',
                color: section === id ? 'var(--bone)' : 'var(--ink-3)',
                fontSize: 13, fontWeight: 500, cursor: 'pointer',
              }}>{l}</button>
            ))}
          </div>

          {/* Overview */}
          <div style={{ marginBottom: 56 }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.01em', fontWeight: 400 }}>Why this project</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16, marginTop: 22 }}>
              {[
                { i: <I.building size={20}/>, t: `${p.floors} floors · ${p.units} units`, d: 'Boutique scale — single-tower management, fewer rental competitors.' },
                { i: <I.wave size={20}/>, t: p.distance_beach_m ? `${p.distance_beach_m}m to beach` : 'Beachfront direct access', d: 'Walking distance to the sand, fronting the protected cove.' },
                { i: <I.trend size={20}/>, t: '+14% YoY capital growth', d: 'Wongamat outperforms central Pattaya on appreciation in 2023–25.' },
                { i: <I.key size={20}/>, t: '30% on signing · balanced terms', d: 'Capital-protected payment schedule with escrow on milestones.' },
              ].map((it, i) => (
                <div key={i} style={{ padding: 22, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)', display: 'flex', gap: 16 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--sand)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--teal)', flexShrink: 0 }}>{it.i}</div>
                  <div>
                    <h4 style={{ margin: 0, fontSize: 15, fontWeight: 500 }}>{it.t}</h4>
                    <p style={{ margin: '6px 0 0', fontSize: 13, color: 'var(--ink-3)', lineHeight: 1.5 }}>{it.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Units */}
          <div style={{ marginBottom: 56 }}>
            <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between', marginBottom: 22 }}>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.01em', fontWeight: 400 }}>Available units & plans</h3>
              <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>{units.length} active listings · floor plans below</span>
            </div>
            <table className="tbl">
              <thead>
                <tr>
                  <th>Unit</th>
                  <th>Type</th>
                  <th>Size</th>
                  <th>Floor</th>
                  <th>View</th>
                  <th style={{ textAlign: 'right' }}>Price</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {units.length === 0 ? (
                  PROPERTIES.slice(0, 4).map(u => <UnitRow key={u.id} u={u} currency={currency} goto={goto}/>)
                ) : units.map(u => <UnitRow key={u.id} u={u} currency={currency} goto={goto}/>)}
              </tbody>
            </table>
            <button className="btn btn-ghost" style={{ marginTop: 20 }}>Request all 18 floor plans <I.download size={14}/></button>
          </div>

          {/* Amenities */}
          <div style={{ marginBottom: 56 }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.01em', fontWeight: 400 }}>Amenities</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 22 }}>
              {[
                ['Infinity pool', I.pool], ['Sky lobby', I.building], ['Private beach', I.wave], ['Wellness floor', I.sun],
                ['Co-work lounge', I.users], ['EV charging', I.parking], ['Concierge', I.key], ['Children\u2019s pool', I.pool],
                ['Yoga deck', I.sun], ['Library', I.document], ['Pet-friendly', I.heart], ['Smart locks', I.shield],
              ].map(([n, Ic], i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', background: 'var(--paper)', borderRadius: 10, border: '1px solid var(--line-soft)', fontSize: 13.5 }}>
                  <Ic size={16} color="var(--teal)"/>
                  {n}
                </div>
              ))}
            </div>
          </div>

          {/* Investment */}
          <div style={{ marginBottom: 56, padding: 32, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 16 }}>
            <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>Investment thesis</span>
            <h3 style={{ margin: '12px 0 0', fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.01em', fontWeight: 400 }}>
              At <em style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>฿132k/m²</em>, this prices in only 60% of comparable Wongamat resales.
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, marginTop: 28 }}>
              {[
                ['Gross yield', `${p.rentalYieldPct}%`, 'AMP-managed pool average'],
                ['Net yield (post-fees)', '5.4%', 'After 12.5% rental tax & sinking fund'],
                ['5-yr ROI projection', '38%', 'Conservative — capital + cash flow'],
              ].map(([l, v, d], i) => (
                <div key={i}>
                  <div style={{ fontSize: 11, color: 'rgba(248,244,234,.6)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{l}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 52, letterSpacing: '-0.02em', lineHeight: 1, marginTop: 8 }}>{v}</div>
                  <div style={{ fontSize: 12, color: 'rgba(248,244,234,.6)', marginTop: 8 }}>{d}</div>
                </div>
              ))}
            </div>
            <button onClick={() => goto && goto('calculator')} className="btn btn-lg" style={{ marginTop: 28, background: 'var(--champagne)', color: 'var(--ink)' }}><I.calc size={14}/> Run your own numbers</button>
          </div>

          {/* Location / map */}
          <div style={{ marginBottom: 56 }}>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.01em', fontWeight: 400 }}>Location</h3>
            <p style={{ margin: '12px 0 22px', fontSize: 14, color: 'var(--ink-3)' }}>Wongamat, north Pattaya — the quietest beach in the city, 90 minutes from Suvarnabhumi.</p>
            <div style={{ height: 320, borderRadius: 14, overflow: 'hidden', border: '1px solid var(--line-soft)', position: 'relative' }} className="map-bg">
              <button style={{ position: 'absolute', left: '60%', top: '40%', padding: '8px 12px', borderRadius: 999, background: 'var(--coral)', color: '#fff', border: 0, fontSize: 12, fontWeight: 500, transform: 'translate(-50%, -100%)' }}>
                <I.pin size={12} style={{ display: 'inline', verticalAlign: -2 }}/> {p.name}
              </button>
              {[['Terminal 21 Mall', '4 min', '32% 28%'], ['Wongamat Beach', '1 min', '70% 50%'], ['Sanctuary of Truth', '8 min', '50% 70%'], ['U-Tapao Airport', '32 min', '22% 86%']].map(([n, t, pos], i) => {
                const [x, y] = pos.split(' ');
                return (
                  <div key={i} style={{ position: 'absolute', left: x, top: y, transform: 'translate(-50%, -50%)', background: 'var(--paper)', padding: '6px 10px', borderRadius: 999, fontSize: 11.5, border: '1px solid var(--line)', boxShadow: 'var(--shadow-sm)' }}>
                    <strong>{n}</strong> · {t}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Developer */}
          <div style={{ marginBottom: 56, padding: 28, background: 'var(--paper)', borderRadius: 16, border: '1px solid var(--line-soft)', display: 'grid', gridTemplateColumns: '120px 1fr', gap: 24, alignItems: 'center' }}>
            <div style={{ width: 120, height: 120, background: 'var(--sand)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontSize: 28 }}>AMP</div>
            <div>
              <span className="t-eyebrow">Developer</span>
              <h3 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', fontWeight: 400 }}>{p.developer}</h3>
              <p style={{ margin: '8px 0 0', fontSize: 13.5, color: 'var(--ink-3)', lineHeight: 1.5 }}>
                Founded 2008. 14 completed projects, 4,200+ units delivered, ฿18B in transactions.
                EIA-approved environmental impact assessment. 100% on-time delivery 2020–2024.
              </p>
              <div style={{ display: 'flex', gap: 14, marginTop: 14 }}>
                <span className="tag tag-paper"><I.check size={11}/> EIA approved</span>
                <span className="tag tag-paper"><I.check size={11}/> Escrow protected</span>
                <span className="tag tag-paper"><I.check size={11}/> ISO 9001</span>
              </div>
            </div>
          </div>
        </div>

        {/* Sticky sidebar form */}
        <aside style={{ position: 'sticky', top: 80 }}>
          <LeadForm source={`project:${p.id}`}/>
          <div style={{ marginTop: 14, padding: 16, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <img src={AGENTS[0].avatar} style={{ width: 44, height: 44, borderRadius: '50%', objectFit: 'cover' }}/>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 500 }}>{AGENTS[0].name}</div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-4)' }}>Your project advisor · {AGENTS[0].lang}</div>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 14 }}>
              <button className="btn btn-sm" style={{ background: '#25D366', color: '#fff' }}><I.whatsapp size={14}/> WhatsApp</button>
              <button className="btn btn-sm" style={{ background: '#06C755', color: '#fff' }}><I.line size={14}/> LINE</button>
            </div>
          </div>
        </aside>
      </section>

      {/* Similar projects */}
      <section style={{ padding: '72px 40px' }}>
        <SectionHead eyebrow="Similar projects" title="You might also like" action={<button onClick={() => goto && goto('projects')} className="btn btn-ghost">All projects <I.arrowR size={14}/></button>}/>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {PROJECTS.filter(x => x.id !== p.id).slice(0, 3).map(p => <ProjectCard key={p.id} project={p} onClick={() => goto && goto('project', p.id)}/>)}
        </div>
      </section>

      <Footer/>
    </div>
  );
}

function UnitRow({ u, currency, goto }) {
  return (
    <tr onClick={() => goto && goto('property', u.id)} style={{ cursor: 'pointer' }}>
      <td>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 6, background: `url(${u.cover}) center/cover` }}/>
          <span style={{ fontWeight: 500 }}>{u.unit}</span>
        </div>
      </td>
      <td>{u.type}</td>
      <td><span className="t-mono" style={{ fontSize: 13 }}>{u.sqm} m²</span></td>
      <td><span className="t-mono" style={{ fontSize: 13 }}>{u.floor}F</span></td>
      <td>{u.view}</td>
      <td style={{ textAlign: 'right' }}><span style={{ fontWeight: 500, fontFamily: 'var(--font-display)', fontSize: 18 }}>{window.fmtPrice(u.priceTHB, currency, { short: true })}</span></td>
      <td><button className="btn btn-sm btn-paper" style={{ height: 30 }}>View <I.arrowR size={12}/></button></td>
    </tr>
  );
}

window.ProjectDetail = ProjectDetail;
