// ─────────────────────────────────────────────────────────────
// Website Desktop: Property Detail (individual unit)
// ─────────────────────────────────────────────────────────────
function PropertyDetail({ goto, propertyId }) {
  const { currency, shortlist, toggleShortlist } = useShare();
  const u = PROPERTIES.find(x => x.id === propertyId) || PROPERTIES[0];
  const p = PROJECTS.find(x => x.id === u.projectId);
  const saved = shortlist.includes(u.id);
  const [activeImg, setActiveImg] = React.useState(0);

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="buy" onNav={goto}/>

      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '20px 40px', fontSize: 13, color: 'var(--ink-4)', borderBottom: '1px solid var(--line-soft)' }}>
        <span onClick={() => goto && goto('home')} style={{ cursor: 'pointer' }}>Home</span>
        <I.chevR size={12}/>
        <span onClick={() => goto && goto('buy')} style={{ cursor: 'pointer' }}>Buy</span>
        <I.chevR size={12}/>
        <span onClick={() => goto && goto('project', p.id)} style={{ cursor: 'pointer' }}>{p.name}</span>
        <I.chevR size={12}/>
        <span style={{ color: 'var(--ink)' }}>{u.unit}</span>
      </div>

      {/* Hero: big gallery left, summary card right */}
      <section style={{ padding: '24px 40px 0', display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 24 }}>
        <div>
          <div className="photo" style={{ aspectRatio: '16/10', borderRadius: 16 }}>
            <img src={[u.cover, ...(p?.gallery || [])][activeImg]} alt=""/>
            <button style={{ position: 'absolute', right: 16, bottom: 16, padding: '10px 16px', borderRadius: 999, background: 'rgba(255,255,255,.96)', border: 0, fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
              <I.grid size={12} style={{ display: 'inline', verticalAlign: -2, marginRight: 6 }}/> View all photos
            </button>
            <button style={{ position: 'absolute', right: 152, bottom: 16, padding: '10px 16px', borderRadius: 999, background: 'rgba(255,255,255,.96)', border: 0, fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
              <I.camera size={12} style={{ display: 'inline', verticalAlign: -2, marginRight: 6 }}/> 3D tour
            </button>
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            {[u.cover, ...(p?.gallery || []).slice(0, 5)].map((g, i) => (
              <button key={i} onClick={() => setActiveImg(i)} style={{ flex: 1, aspectRatio: '4/3', borderRadius: 8, overflow: 'hidden', border: activeImg === i ? '2px solid var(--ink)' : '2px solid transparent', padding: 0, cursor: 'pointer', background: `url(${g}) center/cover` }}/>
            ))}
          </div>
        </div>

        <aside>
          <span className="tag tag-coral">{u.hot ? 'High interest' : 'Listed ' + u.listed}</span>
          <h1 style={{ margin: '12px 0 0', fontFamily: 'var(--font-display)', fontSize: 48, letterSpacing: '-0.02em', lineHeight: 1.04, fontWeight: 400 }}>
            {u.type} · {u.sqm} m²
          </h1>
          <p style={{ margin: '8px 0 0', fontSize: 14, color: 'var(--ink-3)' }}>
            {p.name} · {u.unit} · {u.view}
          </p>

          <div style={{ marginTop: 22, padding: '24px 0', borderTop: '1px solid var(--line-soft)', borderBottom: '1px solid var(--line-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 56, letterSpacing: '-0.02em', lineHeight: 1 }}>{window.fmtPrice(u.priceTHB, currency)}</span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--ink-3)', marginTop: 8 }} className="t-mono">
              {window.fmtPrice(Math.round(u.priceTHB / u.sqm), currency)} / m² · est. monthly: {window.fmtPrice(u.priceTHB * 0.0058, currency)}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 22 }}>
            <button className="btn btn-coral btn-lg" style={{ flex: 1 }}>Book private viewing <I.calendar size={14}/></button>
            <button onClick={() => toggleShortlist(u.id)} className="btn btn-paper btn-lg" style={{ width: 56, padding: 0 }}>
              {saved ? <I.heartFill size={18} color="var(--coral)"/> : <I.heart size={18}/>}
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 8 }}>
            <button className="btn btn-sm" style={{ background: '#25D366', color: '#fff' }}><I.whatsapp size={14}/> WhatsApp now</button>
            <button className="btn btn-sm" style={{ background: '#06C755', color: '#fff' }}><I.line size={14}/> LINE chat</button>
          </div>

          {/* Quick spec grid */}
          <div style={{ marginTop: 28, padding: 22, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500 }}>Unit specifications</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14, fontSize: 13 }}>
              <Spec2 l="Bedrooms" v={u.bedrooms || 'Studio'}/>
              <Spec2 l="Bathrooms" v={u.baths}/>
              <Spec2 l="Floor" v={`${u.floor} of ${p.floors}`}/>
              <Spec2 l="View" v={u.view}/>
              <Spec2 l="Parking" v="1 included"/>
              <Spec2 l="Furnished" v="Yes — Italian"/>
              <Spec2 l="Ownership" v="Freehold"/>
              <Spec2 l="Quota" v="Foreign · open"/>
            </div>
          </div>

          {/* Floor plan teaser */}
          <div style={{ marginTop: 14, padding: 20, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500 }}>Floor plan</h4>
              <button className="btn btn-sm btn-ghost" style={{ height: 28 }}><I.download size={12}/> PDF</button>
            </div>
            <div style={{ marginTop: 12, height: 180, background: 'var(--paper-warm)', borderRadius: 8, position: 'relative', border: '1px solid var(--line-soft)' }}>
              <svg viewBox="0 0 200 120" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                <rect x="10" y="10" width="180" height="100" fill="none" stroke="var(--ink-3)" strokeWidth="1.5"/>
                <line x1="10" y1="60" x2="80" y2="60" stroke="var(--ink-3)" strokeWidth="0.6"/>
                <line x1="80" y1="10" x2="80" y2="110" stroke="var(--ink-3)" strokeWidth="0.6"/>
                <line x1="80" y1="60" x2="190" y2="60" stroke="var(--ink-3)" strokeWidth="0.6"/>
                <text x="45" y="40" fontSize="6" fill="var(--ink-3)" textAnchor="middle">BR 1</text>
                <text x="45" y="88" fontSize="6" fill="var(--ink-3)" textAnchor="middle">BR 2</text>
                <text x="135" y="40" fontSize="6" fill="var(--ink-3)" textAnchor="middle">Living</text>
                <text x="135" y="88" fontSize="6" fill="var(--ink-3)" textAnchor="middle">Kitchen</text>
                <rect x="170" y="60" width="20" height="50" fill="rgba(217,106,78,.15)" stroke="var(--coral)" strokeWidth="0.6"/>
                <text x="180" y="90" fontSize="5" fill="var(--coral-2)" textAnchor="middle">Balcony</text>
              </svg>
            </div>
          </div>
        </aside>
      </section>

      {/* Tabs / detail body */}
      <section style={{ padding: '64px 40px 0', display: 'grid', gridTemplateColumns: '1fr 360px', gap: 56, alignItems: 'start' }}>
        <div>
          <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', fontWeight: 400 }}>About this unit</h3>
          <p style={{ margin: '14px 0 0', fontSize: 15, color: 'var(--ink-2)', lineHeight: 1.7, maxWidth: 720 }}>
            This corner {u.type.toLowerCase()} on the 28th floor offers uninterrupted sea views across Wongamat Bay
            and the protected cove below. Fully fitted with Italian millwork, Miele appliances,
            and Schüco aluminum-frame windows rated for typhoon-grade conditions.
            The unit faces north-east and sits within the foreign-quota allocation,
            ready for freehold transfer to non-resident buyers.
          </p>

          {/* Investment block */}
          <div style={{ marginTop: 40, padding: 28, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
            <span className="t-eyebrow">Investment numbers</span>
            <h4 style={{ margin: '10px 0 0', fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em', fontWeight: 400 }}>If rented short-stay through AMP Property Management</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, marginTop: 22 }}>
              {[
                ['Projected ADR', '฿4,800/night'],
                ['Occupancy', '74%'],
                ['Annual gross', `฿1.3M`],
                ['Net yield', '5.8%'],
              ].map(([l, v]) => (
                <div key={l}>
                  <div style={{ fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{l}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', marginTop: 4 }}>{v}</div>
                </div>
              ))}
            </div>
            <p style={{ margin: '16px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>
              Projections based on 2025 actuals of 12 comparable Wongamat units. Net of 12.5% rental tax, AMP management fee (15%), common-area fees.
            </p>
          </div>

          {/* Cost breakdown */}
          <h3 style={{ margin: '56px 0 22px', fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', fontWeight: 400 }}>Total cost to acquire</h3>
          <div className="card" style={{ padding: 0 }}>
            {[
              ['Unit price', window.fmtPrice(u.priceTHB, currency), 'base'],
              ['Transfer fee (2%)', window.fmtPrice(u.priceTHB * 0.02, currency), 'one-off'],
              ['Specific business tax', window.fmtPrice(u.priceTHB * 0.033, currency), 'developer pays'],
              ['Sinking fund', '฿42,000', 'one-off'],
              ['Legal & escrow', '฿35,000', 'one-off'],
              ['Total', window.fmtPrice(u.priceTHB * 1.025 + 77000, currency), 'estimated'],
            ].map(([l, v, hint], i, arr) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '16px 22px',
                borderTop: i ? '1px solid var(--line-soft)' : 'none',
                background: i === arr.length - 1 ? 'var(--paper-warm)' : 'transparent',
              }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: i === arr.length - 1 ? 500 : 400 }}>{l}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{hint}</div>
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: i === arr.length - 1 ? 600 : 400 }}>{v}</div>
              </div>
            ))}
          </div>

          {/* Map / location callout */}
          <h3 style={{ margin: '56px 0 22px', fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', fontWeight: 400 }}>Location</h3>
          <div style={{ height: 280, borderRadius: 14, overflow: 'hidden', position: 'relative' }} className="map-bg">
            <button style={{ position: 'absolute', left: '55%', top: '40%', padding: '8px 12px', borderRadius: 999, background: 'var(--coral)', color: '#fff', border: 0, fontSize: 12, fontWeight: 500, transform: 'translate(-50%, -100%)' }}>
              <I.pin size={12} style={{ display: 'inline', verticalAlign: -2 }}/> {p.name}
            </button>
          </div>
        </div>

        {/* Sidebar */}
        <aside style={{ position: 'sticky', top: 80, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <img src={AGENTS[1].avatar} style={{ width: 52, height: 52, borderRadius: '50%', objectFit: 'cover' }}/>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>{AGENTS[1].name}</div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-4)' }}>Listing agent · {AGENTS[1].lang}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>
                  <I.starFill size={10} color="var(--champagne)"/> {AGENTS[1].rating} · {AGENTS[1].deals} deals
                </div>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 16 }}>
              <button className="btn btn-sm btn-paper"><I.phone size={13}/> Call</button>
              <button className="btn btn-sm btn-paper"><I.mail size={13}/> Email</button>
            </div>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <h4 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>Schedule a viewing</h4>
            <p style={{ margin: '6px 0 16px', fontSize: 12.5, color: 'var(--ink-4)' }}>In-person · video tour · free transport</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
              {['Tue', 'Wed', 'Thu'].map((d, i) => (
                <button key={d} style={{ padding: '10px 0', borderRadius: 8, background: i === 1 ? 'var(--ink)' : 'var(--paper-warm)', color: i === 1 ? 'var(--bone)' : 'var(--ink)', border: '1px solid var(--line-soft)', fontSize: 12, cursor: 'pointer' }}>
                  <div style={{ fontSize: 10, opacity: 0.6 }}>{d}</div>
                  <div style={{ fontWeight: 500 }}>{18 + i}</div>
                </button>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6, marginTop: 6 }}>
              {['10:00', '14:00', '16:30'].map((t, i) => (
                <button key={t} style={{ padding: '8px 0', borderRadius: 8, background: 'var(--paper-warm)', border: '1px solid var(--line-soft)', fontSize: 12, cursor: 'pointer' }} className="t-mono">{t}</button>
              ))}
            </div>
            <button className="btn btn-coral btn-block" style={{ marginTop: 12 }}>Confirm viewing <I.arrowR size={14}/></button>
          </div>

          <div style={{ padding: 18, background: 'var(--paper-warm)', borderRadius: 12, fontSize: 12.5, color: 'var(--ink-3)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, color: 'var(--ink)', fontWeight: 500 }}>
              <I.shield size={14}/> Safe to buy
            </div>
            Funds held in independent escrow until title transfer. Unit confirmed within foreign quota.
            14-day cooling-off period included.
          </div>
        </aside>
      </section>

      {/* Similar units */}
      <section style={{ padding: '72px 40px' }}>
        <SectionHead eyebrow="Similar in this building" title="Other units in this project"/>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {PROPERTIES.filter(x => x.id !== u.id).slice(0, 4).map(prop => {
            const proj = PROJECTS.find(x => x.id === prop.projectId);
            return <PropertyCard key={prop.id} property={prop} project={proj} onClick={() => goto && goto('property', prop.id)}/>;
          })}
        </div>
      </section>

      <Footer/>
    </div>
  );
}

function Spec2({ l, v }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: 'var(--ink-4)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{l}</div>
      <div style={{ fontSize: 13.5, marginTop: 2 }}>{v}</div>
    </div>
  );
}

window.PropertyDetail = PropertyDetail;
