// ─────────────────────────────────────────────────────────────
// Website Mobile: Home, Project Detail, Property Detail, Smart Finder
// ─────────────────────────────────────────────────────────────

// ─── Mobile Home ───
function MobileHome() {
  const { currency } = useShare();
  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)', position: 'relative', paddingBottom: 110 }}>
      {/* Status bar */}
      <div className="statusbar"><span>9:41</span><span style={{ display: 'flex', gap: 4 }}>•••• 5G ▮</span></div>

      {/* Hero */}
      <div style={{ position: 'relative', margin: '0 12px', height: 460, borderRadius: 20, overflow: 'hidden', background: 'var(--ink)', color: 'var(--bone)' }}>
        <img src={PHOTOS.bangkok_sky} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', opacity: 0.55 }}/>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(20,32,31,.3) 0%, rgba(20,32,31,.92) 100%)' }}/>
        <MobileTopbar tone="dark"/>
        <div style={{ position: 'absolute', inset: 0, padding: '0 22px 22px', display: 'flex', flexDirection: 'column', justifyContent: 'end' }}>
          <span style={{ fontSize: 11, padding: '4px 10px', border: '1px solid rgba(248,244,234,.3)', borderRadius: 999, alignSelf: 'start', letterSpacing: '0.04em' }}>
            <span className="dot dot-coral" style={{ marginRight: 4 }}/> 142 units released
          </span>
          <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 44, letterSpacing: '-0.025em', lineHeight: 1, fontWeight: 400 }}>
            Pattaya, priced for<br/>
            <em style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>investors</em>.
          </h1>
          <p style={{ margin: '12px 0 0', fontSize: 13, color: 'rgba(248,244,234,.75)', lineHeight: 1.5 }}>
            Off-plan, resale & pool villas across Pattaya's Eastern Seaboard.
          </p>
          <button className="btn btn-coral btn-block btn-lg" style={{ marginTop: 18 }}>View available units <I.arrowR size={14}/></button>
          <button className="btn btn-block" style={{ marginTop: 8, background: 'rgba(248,244,234,.1)', color: 'var(--bone)', border: '1px solid rgba(248,244,234,.2)' }}>
            <I.sparkle size={14}/> 90-second Smart Finder
          </button>
        </div>
      </div>

      {/* Quick stats */}
      <div style={{ padding: '24px 18px 8px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
        {[['127', 'Projects'], ['฿2.9M', 'From'], ['8.1%', 'Top yield']].map(([v, l]) => (
          <div key={l} style={{ padding: 14, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em' }}>{v}</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>{l}</div>
          </div>
        ))}
      </div>

      {/* Search bar */}
      <div style={{ padding: '16px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line)' }}>
          <I.search size={16} color="var(--ink-3)"/>
          <span style={{ fontSize: 13.5, color: 'var(--ink-3)', flex: 1 }}>Anywhere · Any type · ฿3M–฿20M</span>
          <button style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--ink)', color: 'var(--bone)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.filter size={14}/></button>
        </div>
      </div>

      {/* Featured projects */}
      <div style={{ padding: '12px 18px 8px', display: 'flex', alignItems: 'end', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.015em', fontWeight: 400 }}>Investor shortlist</h2>
        <span style={{ fontSize: 12, color: 'var(--ink-4)' }}>See all <I.arrowR size={11} style={{ display: 'inline', verticalAlign: -2 }}/></span>
      </div>
      <div style={{ display: 'flex', gap: 10, padding: '8px 18px 24px', overflowX: 'auto' }}>
        {PROJECTS.slice(0, 4).map(p => (
          <article key={p.id} style={{ flex: '0 0 240px', background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)', overflow: 'hidden' }}>
            <div style={{ aspectRatio: '4/3', position: 'relative' }}>
              <img src={p.cover} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
              {p.tag && <span className={`tag tag-${p.tagTone}`} style={{ position: 'absolute', top: 10, left: 10 }}>{p.tag}</span>}
            </div>
            <div style={{ padding: '12px 14px 14px' }}>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 18, letterSpacing: '-0.01em', fontWeight: 400 }}>{p.name}</h3>
              <div style={{ fontSize: 11, color: 'var(--ink-4)', marginTop: 2 }}>{p.area}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 10 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 18 }}>{window.fmtPrice(p.startingPriceTHB, currency, { short: true })}</span>
                <span style={{ fontSize: 11, color: 'var(--coral-2)', fontWeight: 500 }}>{p.rentalYieldPct}% yield</span>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* Areas grid */}
      <div style={{ padding: '12px 18px 8px' }}>
        <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.015em', fontWeight: 400 }}>By area</h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, padding: '8px 18px 24px' }}>
        {window.AREAS.slice(0, 4).map(a => (
          <div key={a.id} style={{ position: 'relative', aspectRatio: '1', borderRadius: 12, overflow: 'hidden' }}>
            <img src={a.img} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}/>
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 40%, rgba(20,32,31,.8))' }}/>
            <div style={{ position: 'absolute', bottom: 10, left: 12, color: '#fff' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 400 }}>{a.name}</div>
              <div style={{ fontSize: 10.5, color: 'rgba(255,255,255,.7)' }}>{a.count} listings</div>
            </div>
          </div>
        ))}
      </div>

      {/* Investor module */}
      <div style={{ padding: '12px 18px 100px' }}>
        <div style={{ background: 'var(--ink)', color: 'var(--bone)', padding: '24px 22px', borderRadius: 16 }}>
          <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>For investors</span>
          <h3 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.015em', lineHeight: 1.05, fontWeight: 400 }}>
            Foreign-ownership made simple. <em style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>49% quota explained.</em>
          </h3>
          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <button className="btn btn-sm" style={{ background: 'var(--champagne)', color: 'var(--ink)', flex: 1 }}>Read guide</button>
            <button className="btn btn-sm" style={{ background: 'rgba(248,244,234,.1)', color: 'var(--bone)', border: '1px solid rgba(248,244,234,.18)' }}><I.calc size={13}/> Calculator</button>
          </div>
        </div>
      </div>

      <MobileStickyCTA/>
      <MobileBottomNav active="home"/>
    </div>
  );
}

// ─── Mobile Project Detail ───
function MobileProjectDetail() {
  const p = PROJECTS[0];
  const { currency } = useShare();
  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)', position: 'relative', paddingBottom: 130 }}>
      {/* Status bar */}
      <div className="statusbar"><span>9:41</span><span style={{ display: 'flex', gap: 4 }}>•••• 5G ▮</span></div>

      {/* Hero photo */}
      <div style={{ position: 'relative', height: 320, overflow: 'hidden' }}>
        <img src={p.cover} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
        <div style={{ position: 'absolute', top: 8, left: 0, right: 0, display: 'flex', justifyContent: 'space-between', padding: '0 16px' }}>
          <button style={{ width: 38, height: 38, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.chevL size={18}/></button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{ width: 38, height: 38, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.share size={16}/></button>
            <button style={{ width: 38, height: 38, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.heart size={16}/></button>
          </div>
        </div>
        <div style={{ position: 'absolute', bottom: 12, right: 12, padding: '4px 12px', borderRadius: 999, background: 'rgba(20,32,31,.7)', color: '#fff', fontSize: 11, fontFamily: 'var(--font-mono)' }}>1 / 48</div>
      </div>

      {/* Title block */}
      <div style={{ padding: '20px 18px 16px' }}>
        <div style={{ display: 'flex', gap: 6 }}>
          <span className={`tag tag-${p.tagTone}`}>{p.tag}</span>
          <span className="tag tag-paper"><I.shield size={10}/> AMP verified</span>
        </div>
        <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 36, letterSpacing: '-0.02em', lineHeight: 1.02, fontWeight: 400 }}>{p.name}</h1>
        <p style={{ margin: '6px 0 0', fontSize: 13, color: 'var(--ink-3)' }}>
          <I.pin size={11} style={{ display: 'inline', verticalAlign: -1, marginRight: 4 }}/>
          {p.area} · {p.developer}
        </p>

        {/* From price */}
        <div style={{ marginTop: 18, paddingTop: 18, borderTop: '1px solid var(--line-soft)' }}>
          <div style={{ fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>From</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1 }}>{window.fmtPrice(p.startingPriceTHB, currency, { short: true })}</span>
            <span style={{ fontSize: 12, color: 'var(--ink-4)' }} className="t-mono">฿132k/m²</span>
          </div>
        </div>

        {/* Stats */}
        <div style={{ marginTop: 20, display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
          {[['Yield', `${p.rentalYieldPct}%`], ['Completion', p.completion], ['Quota', `${p.foreignQuotaPct}%/49%`], ['Beach', `${p.distance_beach_m}m`]].map(([l, v]) => (
            <div key={l} style={{ padding: '12px 14px', background: 'var(--paper)', borderRadius: 10, border: '1px solid var(--line-soft)' }}>
              <div style={{ fontSize: 10.5, color: 'var(--ink-4)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{l}</div>
              <div style={{ fontSize: 18, fontFamily: 'var(--font-display)', marginTop: 2 }}>{v}</div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <p style={{ margin: '24px 0 0', fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.6 }}>{p.summary}</p>

        {/* Tabs preview */}
        <div style={{ marginTop: 28, display: 'flex', gap: 4, overflowX: 'auto' }}>
          {['Overview', 'Units', 'Amenities', 'Investment', 'Location', 'FAQ'].map((t, i) => (
            <button key={t} style={{ padding: '8px 12px', borderRadius: 999, background: i === 0 ? 'var(--ink)' : 'var(--paper)', color: i === 0 ? 'var(--bone)' : 'var(--ink-3)', border: i === 0 ? 0 : '1px solid var(--line-soft)', fontSize: 12, whiteSpace: 'nowrap', flexShrink: 0 }}>{t}</button>
          ))}
        </div>

        {/* Amenities chips */}
        <h3 style={{ margin: '24px 0 12px', fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Amenities</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {[
            ['Infinity pool', I.pool], ['Sky lobby', I.building], ['Private beach', I.wave], ['Wellness', I.sun], ['Co-work', I.users], ['EV charging', I.parking],
          ].map(([n, Ic]) => (
            <div key={n} style={{ padding: '10px 12px', background: 'var(--paper)', borderRadius: 8, border: '1px solid var(--line-soft)', fontSize: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
              <Ic size={14} color="var(--teal)"/>{n}
            </div>
          ))}
        </div>

        {/* Mini-map */}
        <h3 style={{ margin: '28px 0 12px', fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Location</h3>
        <div style={{ height: 160, borderRadius: 12, position: 'relative', overflow: 'hidden' }} className="map-bg">
          <button style={{ position: 'absolute', left: '55%', top: '40%', transform: 'translate(-50%, -100%)', padding: '6px 10px', background: 'var(--coral)', color: '#fff', fontSize: 11, borderRadius: 999, border: 0 }}>
            <I.pin size={10} style={{ display: 'inline', verticalAlign: -2 }}/> {p.name}
          </button>
        </div>
      </div>

      <MobileStickyCTA/>
    </div>
  );
}

// ─── Mobile Smart Finder ───
function MobileSmartFinder() {
  return (
    <div className="frame" style={{ background: 'var(--bone)', display: 'flex', flexDirection: 'column' }}>
      <div className="statusbar"><span>9:41</span><span style={{ display: 'flex', gap: 4 }}>•••• 5G ▮</span></div>

      <div style={{ padding: '4px 18px 16px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <button style={{ width: 36, height: 36, borderRadius: 999, background: 'var(--paper)', border: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.close size={16}/></button>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, color: 'var(--ink-3)', marginBottom: 4 }}>
            <span>Step 3 of 7</span>
            <span className="t-mono">43%</span>
          </div>
          <div className="progress"><div style={{ width: '43%', background: 'var(--coral)' }}/></div>
        </div>
      </div>

      <div style={{ flex: 1, padding: '24px 24px 16px', overflow: 'auto' }}>
        <span className="t-eyebrow" style={{ color: 'var(--coral-2)' }}>Smart Finder</span>
        <h1 style={{ margin: '12px 0 0', fontFamily: 'var(--font-display)', fontSize: 38, letterSpacing: '-0.02em', lineHeight: 1.02, fontWeight: 400 }}>
          What's your <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>budget</em> in THB?
        </h1>
        <p style={{ margin: '12px 0 0', fontSize: 14, color: 'var(--ink-3)' }}>
          Move the slider — we'll show only what's within reach.
        </p>

        <div style={{ marginTop: 40, padding: 22, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 56, letterSpacing: '-0.03em', lineHeight: 1 }}>฿14M</span>
            <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>≈ $390k</span>
          </div>
          <input type="range" min="2" max="80" defaultValue="14" style={{ width: '100%', accentColor: 'var(--coral)', marginTop: 18 }}/>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, fontSize: 10, color: 'var(--ink-4)' }} className="t-mono">
            <span>฿2M</span><span>฿20M</span><span>฿40M</span><span>฿80M+</span>
          </div>
        </div>

        <div style={{ marginTop: 16, padding: 14, background: 'var(--paper-warm)', borderRadius: 10, fontSize: 13, color: 'var(--ink-2)' }}>
          <strong style={{ color: 'var(--coral-2)' }}>72 listings</strong> match · 18 projects · 4 areas
        </div>

        {/* Live shortlist preview */}
        <div style={{ marginTop: 24, padding: 16, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 14 }}>
          <div style={{ fontSize: 11, color: 'var(--champagne)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Live preview</div>
          <h4 style={{ margin: '6px 0 14px', fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 400 }}>Top 3 matches</h4>
          {PROJECTS.slice(0, 3).map((p, i) => (
            <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderTop: i ? '1px solid rgba(248,244,234,.1)' : 0 }}>
              <div style={{ width: 38, height: 38, borderRadius: 6, background: `url(${p.cover}) center/cover`, flexShrink: 0 }}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                <div style={{ fontSize: 10.5, color: 'rgba(248,244,234,.55)' }}>{p.area}</div>
              </div>
              <span style={{ fontSize: 11, color: i === 0 ? '#7dca8e' : 'var(--champagne)', fontFamily: 'var(--font-mono)' }}>{[94, 88, 76][i]}%</span>
            </div>
          ))}
        </div>
      </div>

      {/* Sticky nav */}
      <div style={{ padding: '12px 18px 24px', borderTop: '1px solid var(--line-soft)', background: 'var(--paper)', display: 'flex', gap: 8 }}>
        <button className="btn btn-paper" style={{ width: 56, height: 50, padding: 0 }}><I.chevL size={18}/></button>
        <button className="btn btn-coral btn-lg" style={{ flex: 1, height: 50 }}>Continue <I.arrowR size={16}/></button>
      </div>
    </div>
  );
}

// ─── Mobile Property Detail ───
function MobilePropertyDetail() {
  const u = PROPERTIES[0];
  const p = PROJECTS.find(x => x.id === u.projectId);
  const { currency } = useShare();
  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)', position: 'relative', paddingBottom: 130 }}>
      <div className="statusbar"><span>9:41</span><span style={{ display: 'flex', gap: 4 }}>•••• 5G ▮</span></div>

      <div style={{ position: 'relative', height: 280, overflow: 'hidden' }}>
        <img src={u.cover} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
        <div style={{ position: 'absolute', top: 8, left: 0, right: 0, display: 'flex', justifyContent: 'space-between', padding: '0 16px' }}>
          <button style={{ width: 38, height: 38, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.chevL size={18}/></button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{ width: 38, height: 38, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.share size={16}/></button>
            <button style={{ width: 38, height: 38, borderRadius: 999, background: 'rgba(255,255,255,.94)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.heart size={16}/></button>
          </div>
        </div>
      </div>

      <div style={{ padding: '20px 18px 16px' }}>
        <span className="tag tag-coral">{u.hot ? 'High interest · 14 viewings' : u.listed}</span>
        <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 34, letterSpacing: '-0.02em', lineHeight: 1, fontWeight: 400 }}>{u.type} · {u.sqm} m²</h1>
        <p style={{ margin: '6px 0 0', fontSize: 13, color: 'var(--ink-3)' }}>{p.name} · {u.unit} · {u.view}</p>

        <div style={{ marginTop: 18, paddingTop: 18, borderTop: '1px solid var(--line-soft)' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 44, letterSpacing: '-0.02em', lineHeight: 1 }}>{window.fmtPrice(u.priceTHB, currency)}</div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 4 }} className="t-mono">
            ฿{Math.round(u.priceTHB / u.sqm).toLocaleString()}/m² · est. ฿85k/mo income
          </div>
        </div>

        <div style={{ display: 'flex', gap: 12, marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--line-soft)', fontSize: 13 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><I.bed size={14}/> {u.bedrooms || 'Studio'}</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><I.bath size={14}/> {u.baths}</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><I.ruler size={14}/> {u.sqm}m²</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><I.building size={14}/> {u.floor}F</span>
        </div>

        <p style={{ margin: '20px 0 0', fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.6 }}>
          Corner {u.type.toLowerCase()} with uninterrupted sea views, Italian millwork, Miele appliances, and freehold foreign-quota allocation.
        </p>

        <h3 style={{ margin: '28px 0 12px', fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Investment</h3>
        <div style={{ padding: 16, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {[['ADR', '฿4.8k'], ['Occ.', '74%'], ['Net yield', '5.8%']].map(([l, v]) => (
              <div key={l}>
                <div style={{ fontSize: 10, color: 'rgba(248,244,234,.6)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{l}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, marginTop: 2 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        <h3 style={{ margin: '28px 0 12px', fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Floor plan</h3>
        <div style={{ height: 200, background: 'var(--paper-warm)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
          <svg viewBox="0 0 200 120" style={{ width: '100%', height: '100%' }}>
            <rect x="10" y="10" width="180" height="100" fill="none" stroke="var(--ink-3)" strokeWidth="1.5"/>
            <line x1="10" y1="60" x2="80" y2="60" stroke="var(--ink-3)" strokeWidth="0.6"/>
            <line x1="80" y1="10" x2="80" y2="110" stroke="var(--ink-3)" strokeWidth="0.6"/>
            <line x1="80" y1="60" x2="190" y2="60" stroke="var(--ink-3)" strokeWidth="0.6"/>
            <text x="45" y="40" fontSize="6" fill="var(--ink-3)" textAnchor="middle">BR 1</text>
            <text x="135" y="40" fontSize="6" fill="var(--ink-3)" textAnchor="middle">Living</text>
            <text x="135" y="88" fontSize="6" fill="var(--ink-3)" textAnchor="middle">Kitchen</text>
            <rect x="170" y="60" width="20" height="50" fill="rgba(217,106,78,.15)" stroke="var(--coral)" strokeWidth="0.6"/>
          </svg>
        </div>

        <h3 style={{ margin: '28px 0 12px', fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>Listing agent</h3>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 14, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
          <img src={AGENTS[1].avatar} style={{ width: 48, height: 48, borderRadius: '50%', objectFit: 'cover' }}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 500 }}>{AGENTS[1].name}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{AGENTS[1].role} · {AGENTS[1].lang}</div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--ink-3)' }}>
              <I.starFill size={10} color="var(--champagne)"/> {AGENTS[1].rating}
            </div>
          </div>
          <button style={{ width: 38, height: 38, borderRadius: 999, background: '#25D366', border: 0, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.whatsapp size={16}/></button>
        </div>
      </div>

      {/* Sticky bottom CTA */}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: '14px 18px 24px', background: 'var(--paper)', borderTop: '1px solid var(--line)', boxShadow: '0 -8px 20px rgba(0,0,0,.05)' }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-paper" style={{ width: 50, padding: 0 }}><I.heart size={16}/></button>
          <button className="btn btn-paper" style={{ width: 50, padding: 0, background: '#25D366', color: '#fff', border: 0 }}><I.whatsapp size={16}/></button>
          <button className="btn btn-coral" style={{ flex: 1 }}>Book viewing <I.arrowR size={14}/></button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MobileHome, MobileProjectDetail, MobilePropertyDetail, MobileSmartFinder });
