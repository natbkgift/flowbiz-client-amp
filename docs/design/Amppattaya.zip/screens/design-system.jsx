// ─────────────────────────────────────────────────────────────
// Design System reference artboard
// ─────────────────────────────────────────────────────────────
function DesignSystem() {
  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)', padding: '40px 48px' }}>
      <header style={{ marginBottom: 40 }}>
        <span className="t-eyebrow">AMP Pattaya · Design System v1.0</span>
        <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 88, letterSpacing: '-0.03em', lineHeight: 0.98, fontWeight: 400 }}>
          A premium <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>investor-grade</em> UI<br/>
          for foreign buyers.
        </h1>
        <p style={{ margin: '24px 0 0', fontSize: 17, color: 'var(--ink-3)', maxWidth: 720, lineHeight: 1.55 }}>
          Editorial serif display + clean Geist body. Restrained sunset palette anchored
          on deep ocean teal and warm sand. Coral used sparingly for conversion moments.
          Champagne reserved for premium tags.
        </p>
      </header>

      {/* Color */}
      <DSSection title="Color" subtitle="Warm sand foundations, deep teal ink, coral conversion accent, champagne for luxury.">
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 24 }}>
          <div>
            <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 500 }}>Surfaces · Ink</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
              {[
                ['bone', '#f8f4ea', 'page'],
                ['sand-soft', '#f3ead9', 'section'],
                ['sand', '#efe6d2', ''],
                ['paper', '#ffffff', 'card'],
                ['paper-warm', '#fdfaf2', ''],
                ['line', '#d8cdb4', 'divider'],
                ['ink', '#14201f', 'text'],
                ['ink-2', '#2a3736', ''],
                ['ink-3', '#5b6764', 'secondary'],
                ['ink-4', '#8a938f', 'caption'],
                ['ink-5', '#b6b8b1', 'placeholder'],
                ['line-soft', '#e7ddc4', ''],
              ].map(([n, hex, role]) => (
                <Swatch key={n} hex={hex} name={n} role={role}/>
              ))}
            </div>

            <h4 style={{ margin: '24px 0 12px', fontSize: 13, fontWeight: 500 }}>Brand · Accent</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              {[
                ['teal',      '#0e3a3a', 'primary'],
                ['teal-2',    '#1a5854', ''],
                ['teal-3',    '#2c7a73', 'hover'],
                ['teal-pale', '#d9e4e0', ''],
                ['coral',     '#d96a4e', 'CTA'],
                ['coral-2',   '#c4533a', ''],
                ['coral-pale','#fae0d4', ''],
                ['champagne', '#c9a677', 'premium'],
              ].map(([n, hex, role]) => <Swatch key={n} hex={hex} name={n} role={role}/>)}
            </div>

            <h4 style={{ margin: '24px 0 12px', fontSize: 13, fontWeight: 500 }}>Status</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              {[
                ['green', '#2c7a3c'], ['amber', '#c08a1c'], ['red', '#b53a2c'], ['blue', '#2e5d8f'],
              ].map(([n, hex]) => <Swatch key={n} hex={hex} name={n}/>)}
            </div>
          </div>

          <div>
            <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 500 }}>Usage rules</h4>
            <div style={{ padding: 20, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.7 }}>
                <li><strong>Ink</strong> = body text + primary buttons.</li>
                <li><strong>Coral</strong> only on conversion CTAs (Book, Send).</li>
                <li><strong>Champagne</strong> for premium tags + dark-mode highlights.</li>
                <li><strong>Teal</strong> for hover, links, focus rings.</li>
                <li><strong>Sand</strong> family for all surfaces; never pure white as background.</li>
                <li><strong>Foreign-quota status</strong>: red ≥49, amber 35–48, green &lt;35.</li>
              </ul>
            </div>
          </div>
        </div>
      </DSSection>

      {/* Type */}
      <DSSection title="Typography" subtitle="Instrument Serif (editorial display) + Geist (utility body) + Geist Mono (numbers).">
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24, alignItems: 'start' }}>
          <div style={{ padding: 32, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 88, lineHeight: 0.98, letterSpacing: '-0.03em' }}>
              Investor-grade <em style={{ fontStyle: 'italic' }}>Pattaya</em>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 56, marginTop: 32, letterSpacing: '-0.025em' }}>
              Display · 56 / 0.98
            </div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 36, margin: '24px 0 0', fontWeight: 400, letterSpacing: '-0.02em' }}>Heading XL · 36</h2>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 24, margin: '14px 0 0', fontWeight: 400, letterSpacing: '-0.01em' }}>Heading L · 24</h3>
            <p style={{ margin: '20px 0 0', fontSize: 17, lineHeight: 1.55 }}>Lead body · 17 / 1.55. Used for hero descriptions and editorial pull-quotes.</p>
            <p style={{ margin: '12px 0 0', fontSize: 15, color: 'var(--ink-2)' }}>Body · 15 / 1.6. Default reading size for marketing copy.</p>
            <p style={{ margin: '12px 0 0', fontSize: 13, color: 'var(--ink-3)' }}>Small · 13 / 1.5. Cards, metadata, secondary information.</p>
            <p style={{ margin: '12px 0 0', fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Eyebrow · 11 caps · 0.06em tracking</p>
            <p style={{ margin: '12px 0 0', fontFamily: 'var(--font-mono)', fontSize: 13 }}>฿14,800,000 · 84 m² · 6.4% yield  → Mono · numbers, prices, KPIs.</p>
          </div>
          <div>
            <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 500 }}>Type rules</h4>
            <div style={{ padding: 20, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.7, color: 'var(--ink-2)' }}>
                <li><strong>Serif</strong> for emotion + headings. Always <em style={{ fontStyle: 'italic' }}>one italic emphasis</em> per hero.</li>
                <li><strong>Geist Sans</strong> for body, UI, buttons.</li>
                <li><strong>Geist Mono</strong> for any number, KPI, price, ratio.</li>
                <li><strong>Tracking</strong> tightens on display, loosens on eyebrows (caps).</li>
                <li>Never use Inter, Roboto, or system fonts. Avoid all-caps for body.</li>
              </ul>
            </div>
          </div>
        </div>
      </DSSection>

      {/* Buttons */}
      <DSSection title="Buttons & Tags" subtitle="Pill buttons. Coral is the conversion verb.">
        <div style={{ padding: 28, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
          <h4 style={{ margin: 0, fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Buttons · sizes</h4>
          <div style={{ marginTop: 14, display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <button className="btn btn-sm btn-coral">Small CTA</button>
            <button className="btn btn-coral">Default CTA <I.arrowR size={14}/></button>
            <button className="btn btn-lg btn-coral">Large CTA <I.arrowR size={16}/></button>
            <button className="btn btn-xl btn-coral">Extra large CTA <I.arrowR size={18}/></button>
          </div>

          <h4 style={{ margin: '28px 0 0', fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Variants</h4>
          <div style={{ marginTop: 14, display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <button className="btn btn-primary">Primary</button>
            <button className="btn btn-teal">Teal</button>
            <button className="btn btn-coral">Coral · CTA</button>
            <button className="btn btn-ghost">Ghost</button>
            <button className="btn btn-paper">Paper</button>
            <button className="btn btn-quiet">Quiet</button>
            <button className="btn" style={{ background: '#25D366', color: '#fff' }}><I.whatsapp size={14}/> WhatsApp</button>
            <button className="btn" style={{ background: '#06C755', color: '#fff' }}><I.line size={14}/> LINE</button>
          </div>

          <h4 style={{ margin: '28px 0 0', fontSize: 11, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Tags</h4>
          <div style={{ marginTop: 14, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <span className="tag">Default</span>
            <span className="tag tag-coral">New launch</span>
            <span className="tag tag-champagne">Best yield</span>
            <span className="tag tag-teal">Move-in ready</span>
            <span className="tag tag-dark">Foreign quota full</span>
            <span className="tag tag-green">Available</span>
            <span className="tag tag-amber">Limited</span>
            <span className="tag tag-red">Capped</span>
            <span className="tag tag-blue">New lead</span>
            <span className="tag tag-paper"><I.shield size={11}/> AMP verified</span>
          </div>
        </div>
      </DSSection>

      {/* Cards & Components */}
      <DSSection title="Components" subtitle="Project card, KPI tile, lead form, filter row, stage badge, kanban card.">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          <ProjectCard project={PROJECTS[0]} size="sm"/>
          <KPI title="Pipeline value" value="฿324M" delta="+฿28M" tone="good" sparkline={[280, 285, 295, 300, 305, 318, 324]}/>
          <div className="card" style={{ padding: 22 }}>
            <h4 style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>Lead row</h4>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {LEADS.slice(0, 3).map(l => (
                <div key={l.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span className="avatar avatar-sm" style={{ fontSize: 10 }}>{l.name.split(' ').map(s => s[0]).join('').slice(0, 2)}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 500 }}>{l.name} <CountryFlag c={l.country}/></div>
                    <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{l.last}</div>
                  </div>
                  <StageBadge stage={l.stage}/>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          <KanbanCard l={LEADS[0]}/>
          <KanbanCard l={LEADS[3]}/>
          <KanbanCard l={LEADS[4]}/>
        </div>
      </DSSection>

      {/* Iconography */}
      <DSSection title="Iconography" subtitle="64-icon set · 1.6px stroke · 24px viewport. Real-estate, CRM, channels.">
        <div style={{ padding: 28, background: 'var(--paper)', borderRadius: 14, border: '1px solid var(--line-soft)' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 6 }}>
            {Object.entries(window.I).slice(0, 48).map(([k, Ic]) => (
              <div key={k} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 12, borderRadius: 8 }}>
                <Ic size={20}/>
                <span style={{ fontSize: 9.5, color: 'var(--ink-4)', marginTop: 6, textAlign: 'center', fontFamily: 'var(--font-mono)' }}>{k}</span>
              </div>
            ))}
          </div>
        </div>
      </DSSection>

      {/* Principles */}
      <DSSection title="Principles" subtitle="Six rules that govern every screen.">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {[
            ['01', 'Investor first, not tourist', 'Yield, quota, ROI, capital growth. Never beach-club tropes. Imagery: architecture, never sandals.'],
            ['02', 'Trust before delight', 'Every screen shows verified status, escrow, license, agent face. Conversion follows trust.'],
            ['03', 'WhatsApp = the front door', 'Foreign buyers don\u2019t fill long forms. WhatsApp pillar present on every page above the fold.'],
            ['04', 'Currency-aware', 'Prices reconcile to THB but display in user currency. Persistent across session.'],
            ['05', 'Quota transparency', 'Foreign-quota % shown on every project. Live status. Red/amber/green semantic.'],
            ['06', 'Mobile-equal, not mobile-after', 'Sticky CTA bar on every mobile screen. Tap-target ≥ 44px. No desktop-only states.'],
          ].map(([n, t, d]) => (
            <div key={n} style={{ padding: 22, background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--coral-2)' }}>{n}</div>
              <h4 style={{ margin: '10px 0 6px', fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 400, letterSpacing: '-0.005em' }}>{t}</h4>
              <p style={{ margin: 0, fontSize: 13, color: 'var(--ink-3)', lineHeight: 1.55 }}>{d}</p>
            </div>
          ))}
        </div>
      </DSSection>
    </div>
  );
}

function DSSection({ title, subtitle, children }) {
  return (
    <section style={{ marginBottom: 56 }}>
      <header style={{ marginBottom: 22 }}>
        <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>{title}</h2>
        {subtitle && <p style={{ margin: '8px 0 0', fontSize: 14, color: 'var(--ink-3)', maxWidth: 720 }}>{subtitle}</p>}
      </header>
      {children}
    </section>
  );
}

function Swatch({ hex, name, role }) {
  const isLight = ['#f8f4ea', '#f3ead9', '#efe6d2', '#ffffff', '#fdfaf2', '#d8cdb4', '#e7ddc4', '#fae0d4', '#d9e4e0', '#f0e3cc', '#dbeed8', '#f8ebcd', '#f7d9d4', '#d6e2f0', '#b6b8b1'].includes(hex);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div style={{ aspectRatio: 1.2, borderRadius: 10, background: hex, border: '1px solid var(--line-soft)', position: 'relative' }}>
        {role && <span style={{ position: 'absolute', top: 6, left: 8, fontSize: 9, color: isLight ? 'var(--ink-3)' : 'rgba(255,255,255,.8)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{role}</span>}
      </div>
      <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--ink)' }}>{name}</span>
      <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--ink-4)' }}>{hex}</span>
    </div>
  );
}

window.DesignSystem = DesignSystem;
