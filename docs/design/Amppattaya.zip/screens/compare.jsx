// ─────────────────────────────────────────────────────────────
// Website Desktop: Compare (side-by-side)
// ─────────────────────────────────────────────────────────────
function Compare({ goto }) {
  const { compare, clearCompare, currency, toggleCompare } = useShare();
  // Always show at least 3 for the design — fallback to first 3
  const ids = compare.length >= 2 ? compare : PROJECTS.slice(0, 3).map(p => p.id);
  const items = ids.map(id => PROJECTS.find(p => p.id === id)).filter(Boolean);

  const rows = [
    { label: 'Starting price', get: (p) => window.fmtPrice(p.startingPriceTHB, currency, { short: true }), bold: true },
    { label: 'Price per m²',  get: (p) => window.fmtPrice(p.pricePerSqmTHB, currency) },
    { label: 'Bedrooms',      get: (p) => p.bedrooms.join(' · ') },
    { label: 'Floors',        get: (p) => `${p.floors} floors` },
    { label: 'Total units',   get: (p) => p.units },
    { label: 'Completion',    get: (p) => p.completion },
    { label: 'Status',        get: (p) => p.status },
    { label: 'Distance to beach', get: (p) => p.distance_beach_m ? `${p.distance_beach_m}m` : 'Beachfront' },
    { label: 'Area',          get: (p) => p.area },
    { label: 'Developer',     get: (p) => p.developer },
    { label: 'Gross yield',   get: (p) => `${p.rentalYieldPct}%`, highlight: 'max', valueOf: (p) => p.rentalYieldPct },
    { label: 'Foreign quota', get: (p) => `${p.foreignQuotaPct}% of 49%`, highlight: 'min', valueOf: (p) => p.foreignQuotaPct },
    { label: 'Foreign quota status', get: (p) => p.foreignQuotaPct < 35 ? 'Available' : p.foreignQuotaPct < 49 ? 'Limited' : 'Capped', tone: (p) => p.foreignQuotaPct < 35 ? 'green' : p.foreignQuotaPct < 49 ? 'amber' : 'red' },
    { label: 'Amenities count', get: (p) => p.amenities.length },
    { label: 'AMP verified',  get: () => '✓ Yes' },
    { label: 'Escrow protected', get: () => '✓ Yes' },
  ];

  // Compute highlight values per row
  const winners = rows.map(r => {
    if (!r.highlight || !r.valueOf) return null;
    const vals = items.map(r.valueOf);
    if (r.highlight === 'max') return Math.max(...vals);
    if (r.highlight === 'min') return Math.min(...vals);
    return null;
  });

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="projects" onNav={goto}/>

      <section style={{ padding: '40px 40px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between', marginBottom: 8 }}>
          <div>
            <span className="t-eyebrow">Compare · Side-by-side</span>
            <h1 style={{ margin: '10px 0 0', fontFamily: 'var(--font-display)', fontSize: 56, letterSpacing: '-0.025em', lineHeight: 1.04, fontWeight: 400 }}>
              Compare {items.length} <em style={{ fontStyle: 'italic' }}>investor-grade</em> projects
            </h1>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={clearCompare} className="btn btn-ghost">Clear all</button>
            <button className="btn btn-paper"><I.download size={14}/> Export PDF</button>
            <button className="btn btn-coral">Get advisor brief <I.arrowR size={14}/></button>
          </div>
        </div>
      </section>

      <section style={{ padding: '0 40px 80px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: `200px repeat(${items.length}, 1fr)`, gap: 0, background: 'var(--paper)', borderRadius: 18, border: '1px solid var(--line-soft)', overflow: 'hidden' }}>
          {/* Top row: project cards */}
          <div style={{ borderRight: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}/>
          {items.map(p => (
            <div key={p.id} style={{ borderRight: '1px solid var(--line-soft)', padding: 18, position: 'relative' }}>
              <button onClick={() => toggleCompare(p.id)} style={{ position: 'absolute', top: 10, right: 10, width: 26, height: 26, borderRadius: 999, background: 'var(--paper-warm)', border: '1px solid var(--line-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.close size={12}/></button>
              <div style={{ aspectRatio: '16/10', borderRadius: 10, background: `url(${p.cover}) center/cover`, marginBottom: 12 }}/>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em', fontWeight: 400 }}>{p.name}</h3>
              <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--ink-4)' }}>{p.area}</p>
              <button onClick={() => goto && goto('project', p.id)} className="btn btn-sm btn-paper" style={{ marginTop: 12 }}>View project <I.arrowR size={12}/></button>
            </div>
          ))}

          {/* Rows */}
          {rows.map((r, i) => {
            const isHeader = r.section;
            return (
              <React.Fragment key={i}>
                <div style={{ padding: '14px 22px', borderTop: '1px solid var(--line-soft)', borderRight: '1px solid var(--line-soft)', background: 'var(--paper-warm)', fontSize: 12.5, color: 'var(--ink-3)', display: 'flex', alignItems: 'center' }}>
                  {r.label}
                </div>
                {items.map((p, j) => {
                  const value = r.get(p);
                  const isWinner = winners[i] !== null && r.valueOf && r.valueOf(p) === winners[i];
                  const toneClass = r.tone ? `tag-${r.tone(p)}` : '';
                  return (
                    <div key={p.id} style={{
                      padding: '14px 22px',
                      borderTop: '1px solid var(--line-soft)',
                      borderRight: '1px solid var(--line-soft)',
                      background: isWinner ? 'var(--green-pale)' : 'transparent',
                      display: 'flex', alignItems: 'center', gap: 8,
                    }}>
                      <span style={{
                        fontSize: r.bold ? 18 : 13.5,
                        fontFamily: r.bold ? 'var(--font-display)' : 'inherit',
                        fontWeight: r.bold ? 400 : 500,
                        letterSpacing: r.bold ? '-0.01em' : 'inherit',
                      }}>{value}</span>
                      {isWinner && <span style={{ fontSize: 10, color: 'var(--green)', fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', display: 'inline-flex', alignItems: 'center', gap: 4 }}><I.check size={12}/> Best</span>}
                      {r.tone && <span className={`tag ${toneClass} tag-sm`}>{value}</span>}
                    </div>
                  );
                })}
              </React.Fragment>
            );
          })}

          {/* Action row */}
          <div style={{ padding: '14px 22px', borderTop: '1px solid var(--line-soft)', borderRight: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}/>
          {items.map(p => (
            <div key={p.id} style={{ padding: 18, borderTop: '1px solid var(--line-soft)', borderRight: '1px solid var(--line-soft)' }}>
              <button onClick={() => goto && goto('project', p.id)} className="btn btn-sm btn-coral btn-block" style={{ marginBottom: 6 }}>Book viewing <I.arrowR size={12}/></button>
              <button className="btn btn-sm btn-paper btn-block">Get floor plans</button>
            </div>
          ))}
        </div>

        {/* AMP recommendation */}
        <div style={{ marginTop: 32, padding: 32, background: 'var(--ink)', color: 'var(--bone)', borderRadius: 18, display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 40, alignItems: 'center' }}>
          <div>
            <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>AMP recommendation</span>
            <h3 style={{ margin: '12px 0 0', fontFamily: 'var(--font-display)', fontSize: 36, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>
              Our pick for <em style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>your profile</em>
            </h3>
          </div>
          <p style={{ margin: 0, fontSize: 15, color: 'rgba(248,244,234,.78)', lineHeight: 1.6 }}>
            Based on your shortlisted criteria — yield over 6.5%, foreign quota under 35%, completion within 18 months —
            <strong style={{ color: 'var(--champagne)' }}> Jomtien Bay Tower</strong> offers the strongest risk-adjusted return.
            It's also our pick for first-time foreign investors because of the on-site rental management.
          </p>
        </div>
      </section>

      <Footer/>
    </div>
  );
}

window.Compare = Compare;
