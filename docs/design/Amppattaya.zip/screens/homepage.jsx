// ─────────────────────────────────────────────────────────────
// Website Desktop: Homepage
// Investor-focused luxury, not resort. Architectural hero.
// ─────────────────────────────────────────────────────────────
function Homepage({ goto }) {
  const featured = PROJECTS.slice(0, 3);
  const [searchTab, setSearchTab] = React.useState('buy');

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="home" onNav={goto} tone="dark"/>

      {/* ─── Hero ─── */}
      <section style={{ position: 'relative', minHeight: 720, background: 'var(--ink)', color: 'var(--bone)', marginTop: -65, paddingTop: 65, overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0 }}>
          <img src={PHOTOS.bangkok_sky} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.55 }}/>
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(20,32,31,.55) 0%, rgba(20,32,31,.4) 30%, rgba(20,32,31,.95) 100%)' }}/>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 80% 20%, rgba(217,106,78,.18), transparent 50%)' }}/>
        </div>

        <div style={{ position: 'relative', padding: '80px 64px 64px', display: 'grid', gridTemplateColumns: '1.4fr 460px', gap: 56, alignItems: 'center', minHeight: 720 }}>
          <div>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 12px', borderRadius: 999, border: '1px solid rgba(248,244,234,.22)', background: 'rgba(248,244,234,.06)', fontSize: 11.5, letterSpacing: '0.04em' }}>
              <span className="dot dot-coral pulse" style={{ color: 'var(--coral)' }}/>
              Live · 142 units released this week
            </span>
            <h1 style={{
              margin: '24px 0 0',
              fontFamily: 'var(--font-display)',
              fontSize: 88, lineHeight: 0.98, letterSpacing: '-0.03em', fontWeight: 400,
              textWrap: 'balance', maxWidth: 880,
            }}>
              Pattaya, priced for<br/>
              <span style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>investors who measure</span><br/>
              in years, not weekends.
            </h1>
            <p style={{ margin: '24px 0 0', fontSize: 17, color: 'rgba(248,244,234,.78)', maxWidth: 540, lineHeight: 1.55 }}>
              A licensed brokerage matching foreign buyers and Thai investors with off-plan,
              resale and pool-villa inventory across Pattaya's Eastern Seaboard.
              Transparent yields. Verified foreign quota. Same-day reply.
            </p>

            <div style={{ display: 'flex', gap: 12, marginTop: 36 }}>
              <button onClick={() => goto && goto('projects')} className="btn btn-coral btn-lg">
                View available units <I.arrowR size={16}/>
              </button>
              <button onClick={() => goto && goto('finder')} className="btn btn-lg" style={{ background: 'rgba(248,244,234,.08)', color: 'var(--bone)', border: '1px solid rgba(248,244,234,.24)' }}>
                <I.sparkle size={16}/> 90-second Smart Finder
              </button>
            </div>

            {/* Quick stats under hero */}
            <div style={{ display: 'flex', gap: 40, marginTop: 56, paddingTop: 28, borderTop: '1px solid rgba(248,244,234,.14)' }}>
              {[['127', 'Active projects'], ['฿2.9M', 'Lowest entry'], ['8.1%', 'Top yield p.a.'], ['49%', 'Foreign quota']].map(([v, l], i) => (
                <div key={i}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.02em', lineHeight: 1 }}>{v}</div>
                  <div style={{ fontSize: 11.5, color: 'rgba(248,244,234,.55)', marginTop: 4, letterSpacing: '0.04em' }}>{l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Lead form right side */}
          <div>
            <LeadForm dark/>
          </div>
        </div>
      </section>

      {/* ─── Inline search bar — overlaps the hero/featured boundary ─── */}
      <div style={{ background: 'var(--bone)', padding: '0 40px', marginTop: -42, position: 'relative', zIndex: 5 }}>
        <div style={{ background: 'var(--paper)', borderRadius: 'var(--r-xl)', padding: 14, boxShadow: 'var(--shadow-lg)', border: '1px solid var(--line-soft)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 12, paddingLeft: 6 }}>
            {[['buy', 'Buy'], ['rent', 'Rent'], ['offplan', 'Off-plan'], ['villas', 'Villas']].map(([id, l]) => (
              <button key={id} onClick={() => setSearchTab(id)}
                style={{ padding: '6px 14px', borderRadius: 999, background: searchTab === id ? 'var(--ink)' : 'transparent', color: searchTab === id ? 'var(--bone)' : 'var(--ink-3)', border: 0, fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
                {l}
              </button>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr auto', gap: 0, alignItems: 'stretch' }}>
            <FieldDiv label="Location" value="Anywhere in Pattaya" icon={<I.pin size={16}/>}/>
            <FieldDiv label="Type" value="Condo, Villa, Pent…" divider/>
            <FieldDiv label="Bedrooms" value="Studio – 4 BR" divider/>
            <FieldDiv label="Budget" value="฿3M – ฿20M" divider/>
            <button onClick={() => goto && goto('listing')} className="btn btn-coral btn-lg" style={{ height: 56, padding: '0 28px', alignSelf: 'center', marginLeft: 8 }}>
              <I.search size={16}/> Search 384 listings
            </button>
          </div>
        </div>
      </div>

      {/* ─── Featured projects ─── */}
      <section style={{ padding: '88px 40px 24px' }}>
        <SectionHead
          eyebrow="Hand-picked, this quarter"
          title={<>The <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>investor-grade</em> shortlist.</>}
          kicker="Three projects we'd put our own money in. Verified developers, capital-protected payment terms, and clear exit liquidity."
          action={
            <button onClick={() => goto && goto('projects')} className="btn btn-ghost">
              All 127 projects <I.arrowR size={14}/>
            </button>
          }
        />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {featured.map(p => <ProjectCard key={p.id} project={p} onClick={() => goto && goto('project', p.id)}/>)}
        </div>
      </section>

      {/* ─── Investor breakdown / proof ─── */}
      <section style={{ padding: '64px 40px', background: 'var(--ink)', color: 'var(--bone)', marginTop: 80, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: 0, right: 0, width: 480, height: 480, background: 'radial-gradient(circle, rgba(201,166,119,.18), transparent 60%)', pointerEvents: 'none' }}/>
        <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 80, alignItems: 'center' }}>
          <div>
            <span className="t-eyebrow" style={{ color: 'var(--champagne)', opacity: 1 }}>Why Pattaya · Why now</span>
            <h2 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 56, letterSpacing: '-0.02em', lineHeight: 1.04, fontWeight: 400 }}>
              The Eastern Seaboard's next decade is being priced in
              <span style={{ fontStyle: 'italic', color: 'var(--champagne)' }}> now</span>.
            </h2>
            <p style={{ margin: '20px 0 0', fontSize: 15, color: 'rgba(248,244,234,.7)', lineHeight: 1.6, maxWidth: 460 }}>
              The U-Tapao airport expansion, high-speed rail to Bangkok, and EEC industrial zone are
              re-shaping the south. Median condo values are up 14% YoY in Wongamat.
            </p>
            <button onClick={() => goto && goto('invest')} className="btn btn-lg" style={{ marginTop: 32, background: 'var(--champagne)', color: 'var(--ink)', borderColor: 'var(--champagne)' }}>
              Read our 2026 market report <I.document size={14}/>
            </button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
            {[
              { v: '6.4%', l: 'Median gross yield, prime condo', delta: '+0.4 vs 2024', tone: 'good' },
              { v: '14.2%', l: 'YoY capital appreciation, Wongamat', delta: 'Top zone', tone: 'good' },
              { v: '92%', l: 'Foreign-quota units released first', delta: 'AMP priority allocation', tone: 'neutral' },
              { v: '21 days', l: 'Median time-on-market, ready units', delta: '-8 days YoY', tone: 'good' },
            ].map((s, i) => (
              <div key={i} style={{ background: 'rgba(248,244,234,.05)', border: '1px solid rgba(248,244,234,.1)', borderRadius: 16, padding: 26 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 56, letterSpacing: '-0.02em', lineHeight: 1, color: 'var(--bone)' }}>{s.v}</div>
                <div style={{ fontSize: 13, color: 'rgba(248,244,234,.65)', margin: '8px 0 14px' }}>{s.l}</div>
                <span style={{ fontSize: 11.5, color: s.tone === 'good' ? '#7dca8e' : 'var(--champagne)', fontFamily: 'var(--font-mono)' }}>{s.delta}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Areas ─── */}
      <section style={{ padding: '88px 40px' }}>
        <SectionHead
          eyebrow="Browse by area"
          title={<>Six zones. <em style={{ fontStyle: 'italic' }}>Six investment theses.</em></>}
          kicker="Pattaya is not one market. Each zone has different yield, tenant profile, and capital growth potential."
          action={<button onClick={() => goto && goto('areas')} className="btn btn-ghost">Compare areas <I.compare size={14}/></button>}
        />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {AREAS.map(a => (
            <article key={a.id} onClick={() => goto && goto('areas', a.id)} className="lift" style={{ position: 'relative', aspectRatio: '4/3', borderRadius: 16, overflow: 'hidden', cursor: 'pointer' }}>
              <img src={a.img} alt={a.name} className="zoom-on-hover" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
              <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(20,32,31,.05), rgba(20,32,31,.75))' }}/>
              <div style={{ position: 'absolute', inset: 0, padding: 22, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', color: '#fff' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                  <span className="t-eyebrow" style={{ color: 'rgba(255,255,255,.8)' }}>{a.beach}</span>
                  <span style={{ fontSize: 12, background: 'rgba(255,255,255,.18)', backdropFilter: 'blur(8px)', padding: '4px 10px', borderRadius: 999 }}>{a.count} listings</span>
                </div>
                <div>
                  <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: '-0.01em', fontWeight: 400 }}>{a.name}</h3>
                  <p style={{ margin: '4px 0 0', fontSize: 13, color: 'rgba(255,255,255,.8)' }}>{a.vibe}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ─── Smart Finder CTA ─── */}
      <section style={{ padding: '24px 40px 88px' }}>
        <div style={{ background: 'var(--sand-soft)', borderRadius: 24, padding: '64px 56px', display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 64, alignItems: 'center', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', right: -60, top: -60, width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, var(--champagne-pale), transparent 70%)' }}/>
          <div style={{ position: 'relative' }}>
            <span className="t-eyebrow">Smart Finder · 90 seconds</span>
            <h2 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 52, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>
              Tell us your budget,<br/>
              <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>we'll send a shortlist</em><br/>
              by end of day.
            </h2>
            <p style={{ margin: '20px 0 0', fontSize: 15, color: 'var(--ink-3)', maxWidth: 480 }}>
              Six questions. No call required. Get a curated PDF brief with 3–5 projects matched to your budget, timeline, and exit strategy.
            </p>
            <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
              <button onClick={() => goto && goto('finder')} className="btn btn-coral btn-lg">Start the brief <I.arrowR size={16}/></button>
              <button onClick={() => goto && goto('calculator')} className="btn btn-paper btn-lg"><I.calc size={16}/> Cost calculator</button>
            </div>
          </div>
          <div style={{ position: 'relative', background: 'var(--paper)', borderRadius: 16, padding: 28, border: '1px solid var(--line-soft)', boxShadow: 'var(--shadow-md)' }}>
            <span className="t-eyebrow" style={{ color: 'var(--ink-4)' }}>Sample output</span>
            <h4 style={{ margin: '8px 0 14px', fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.01em' }}>Your AMP shortlist</h4>
            {[
              ['Jomtien Bay Tower',   'Match 94%', 'var(--green)'],
              ['Central Marina Suites','Match 88%', 'var(--green)'],
              ['Na Jomtien Residence', 'Match 76%', 'var(--amber)'],
            ].map(([n, m, c], i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderTop: i ? '1px solid var(--line-soft)' : 'none' }}>
                <div style={{ width: 32, height: 32, background: 'var(--sand)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600 }}>{i+1}</div>
                <span style={{ fontSize: 13.5, flex: 1 }}>{n}</span>
                <span style={{ fontSize: 11, color: c, fontFamily: 'var(--font-mono)' }}>{m}</span>
              </div>
            ))}
            <button className="btn btn-sm btn-ghost btn-block" style={{ marginTop: 12 }}><I.document size={12}/> Download as PDF</button>
          </div>
        </div>
      </section>

      <TrustBar tone="sand"/>

      {/* ─── Testimonials + advisors ─── */}
      <section style={{ padding: '88px 40px' }}>
        <SectionHead
          eyebrow="Trust · Track record"
          title={<>Buyers from <em style={{ fontStyle: 'italic' }}>32 countries</em> have closed with us.</>}
          kicker="Multilingual advisory. Independent legal. Escrow on every transaction."
        />
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 28 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[
              { q: '"AMP walked me through foreign ownership rules in 20 minutes — and found a 7.2% net-yield 1BR three weeks later. The escrow process gave me peace of mind."', n: 'Sven L.', loc: 'Stockholm · Bought 1BR Jomtien', s: 5 },
              { q: '"They\'re the only Pattaya brokerage that gave me a written rental-return forecast before I signed. Numbers held up after 12 months."', n: 'David W.', loc: 'Singapore · Bought 2BR Wongamat', s: 5 },
              { q: '"Sasha managed everything from her side. I never had to fly. She filmed five viewings on FaceTime and helped my notary in Moscow."', n: 'Anna M.', loc: 'Moscow · Bought Penthouse', s: 5 },
              { q: '"3 units, 2 years. Each one cash-flowing within 60 days of handover. The property management team is the real moat."', n: 'James T.', loc: 'Sydney · Portfolio investor', s: 5 },
            ].map((t, i) => (
              <div key={i} style={{ padding: 24, background: 'var(--paper)', borderRadius: 16, border: '1px solid var(--line-soft)' }}>
                <div style={{ display: 'flex', gap: 1, color: 'var(--champagne)', marginBottom: 12 }}>
                  {Array(t.s).fill(0).map((_, j) => <I.starFill key={j} size={14}/>)}
                </div>
                <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6, color: 'var(--ink-2)' }}>{t.q}</p>
                <div style={{ marginTop: 18, fontSize: 12, color: 'var(--ink-4)' }}>
                  <strong style={{ color: 'var(--ink)', fontWeight: 500 }}>{t.n}</strong> · {t.loc}
                </div>
              </div>
            ))}
          </div>
          {/* Advisors panel */}
          <div style={{ background: 'var(--paper)', borderRadius: 16, padding: 28, border: '1px solid var(--line-soft)' }}>
            <span className="t-eyebrow">Your advisors</span>
            <h3 style={{ margin: '10px 0 22px', fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.01em', fontWeight: 400 }}>Speak in your language.</h3>
            {AGENTS.map((a, i) => (
              <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderTop: i ? '1px solid var(--line-soft)' : 0 }}>
                <img src={a.avatar} alt={a.name} style={{ width: 44, height: 44, borderRadius: '50%', objectFit: 'cover' }}/>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 500 }}>{a.name}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--ink-4)' }}>{a.role} · {a.lang}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--ink-3)' }}>
                  <I.starFill size={11} color="var(--champagne)"/> {a.rating}
                </div>
              </div>
            ))}
            <button onClick={() => goto && goto('contact')} className="btn btn-ghost btn-block" style={{ marginTop: 16 }}>Book a free advisory call</button>
          </div>
        </div>
      </section>

      {/* ─── Foreign quota module ─── */}
      <section style={{ padding: '0 40px 88px' }}>
        <div style={{ background: 'var(--paper-warm)', borderRadius: 24, padding: 48, border: '1px solid var(--line-soft)', display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 56, alignItems: 'center' }}>
          <div>
            <span className="t-eyebrow">Foreign ownership · Thailand</span>
            <h2 style={{ margin: '14px 0 0', fontFamily: 'var(--font-display)', fontSize: 44, letterSpacing: '-0.02em', lineHeight: 1.08, fontWeight: 400 }}>
              You can own a condo here outright. <em style={{ fontStyle: 'italic', color: 'var(--coral-2)' }}>Most foreign buyers don't realise.</em>
            </h2>
            <p style={{ margin: '20px 0 0', fontSize: 15, color: 'var(--ink-3)', lineHeight: 1.6 }}>
              Thai law lets non-residents own up to 49% of any condominium building in freehold,
              indefinitely. AMP confirms current quota status before you commit a single baht.
            </p>
            <button onClick={() => goto && goto('quota')} className="btn btn-ghost" style={{ marginTop: 24 }}>Read the explainer <I.arrowR size={14}/></button>
          </div>
          <div style={{ background: 'var(--paper)', borderRadius: 16, padding: 28, border: '1px solid var(--line-soft)' }}>
            <h4 style={{ margin: 0, fontSize: 12, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--ink-3)' }}>Foreign quota — live status</h4>
            <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
              {PROJECTS.slice(0, 4).map(p => {
                const pct = p.foreignQuotaPct;
                const tone = pct >= 49 ? 'var(--red)' : pct >= 35 ? 'var(--amber)' : 'var(--green)';
                return (
                  <div key={p.id}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
                      <span>{p.name}</span>
                      <span className="t-mono" style={{ fontSize: 12, color: tone }}>{pct}% / 49%</span>
                    </div>
                    <div className="progress" style={{ background: 'var(--line-soft)' }}>
                      <div style={{ width: `${(pct / 49) * 100}%`, background: tone }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ─── FAQ ─── */}
      <section style={{ padding: '0 40px 88px' }}>
        <SectionHead
          eyebrow="Common questions"
          title={<>The questions <em style={{ fontStyle: 'italic' }}>every foreign buyer</em> asks first.</>}
        />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {[
            ['Can foreigners own property in Thailand?', 'Yes — condominium units, freehold, up to 49% of any building. Villas use long-term lease or Thai company structures, which we set up via independent counsel.'],
            ['Do I need to be in Thailand to buy?', 'No. We handle remote viewings, contract review, and notarisation. 41% of our 2025 transactions closed without the buyer flying in.'],
            ['How are funds transferred?', 'A Foreign Exchange Transaction (FET) form proves the funds entered Thailand from abroad — required for repatriation later. We coordinate with your bank.'],
            ['What ongoing costs should I expect?', 'Common-area fees ~50–80 ฿/sqm/month, sinking fund (one-off), 12.5% rental tax if let, property tax now 0.02–0.1%. We give you a full cost sheet before offer.'],
            ['How does AMP make money?', 'Standard agent commission from the developer or seller. You pay nothing — and we share rental management fees only on units we let.'],
            ['What happens after I sign?', 'Independent lawyer reviews everything, escrow holds funds, you receive a chanote (title) at handover. Average closing time: 18 days.'],
          ].map(([q, a], i) => (
            <details key={i} style={{ padding: '20px 22px', background: 'var(--paper)', borderRadius: 12, border: '1px solid var(--line-soft)' }}>
              <summary style={{ fontSize: 15, fontWeight: 500, cursor: 'pointer', listStyle: 'none', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                {q}
                <I.plus size={16} color="var(--ink-4)"/>
              </summary>
              <p style={{ margin: '12px 0 0', fontSize: 13.5, color: 'var(--ink-3)', lineHeight: 1.6 }}>{a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* ─── Bottom CTA strip ─── */}
      <section style={{ padding: '0 40px 80px' }}>
        <div style={{ background: 'var(--ink)', color: 'var(--bone)', borderRadius: 24, padding: '56px 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 40 }}>
          <div>
            <span className="t-eyebrow" style={{ color: 'var(--champagne)' }}>Ready when you are</span>
            <h3 style={{ margin: '12px 0 0', fontFamily: 'var(--font-display)', fontSize: 40, letterSpacing: '-0.02em', lineHeight: 1.1, fontWeight: 400, maxWidth: 560 }}>
              Book a 20-minute call. No pressure. <em style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>No call-bots.</em>
            </h3>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn-lg" style={{ background: '#25D366', color: '#fff' }}><I.whatsapp size={16}/> WhatsApp</button>
            <button className="btn btn-lg" style={{ background: '#06C755', color: '#fff' }}><I.line size={16}/> LINE</button>
            <button onClick={() => goto && goto('contact')} className="btn btn-coral btn-lg">Book a viewing <I.arrowR size={16}/></button>
          </div>
        </div>
      </section>

      <Footer/>
    </div>
  );
}

// helper for hero search
function FieldDiv({ label, value, icon, divider }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', justifyContent: 'center',
      padding: '8px 18px',
      borderLeft: divider ? '1px solid var(--line-soft)' : 'none',
      cursor: 'pointer',
    }}>
      <span style={{ fontSize: 10.5, fontWeight: 500, color: 'var(--ink-4)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</span>
      <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14, color: 'var(--ink)', marginTop: 4 }}>
        {icon}{value}
      </span>
    </div>
  );
}

window.Homepage = Homepage;
