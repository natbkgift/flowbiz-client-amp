// ─────────────────────────────────────────────────────────────
// Website Desktop: Project Listing (filterable grid + map toggle)
// ─────────────────────────────────────────────────────────────
function ProjectListing({ goto }) {
  const { compare, toggleCompare, shortlist, toggleShortlist, currency } = useShare();
  const [view, setView] = React.useState('split');  // split | grid | map
  const [sort, setSort] = React.useState('relevance');
  const [filters, setFilters] = React.useState({
    areas: [], status: [], bedrooms: [], priceMax: 50, beach: 'any',
  });
  const [hover, setHover] = React.useState(null);

  // Apply filters
  const filtered = PROJECTS.filter(p => {
    if (filters.areas.length && !filters.areas.includes(p.area)) return false;
    if (filters.status.length && !filters.status.includes(p.statusKey)) return false;
    if (p.startingPriceTHB > filters.priceMax * 1_000_000) return false;
    return true;
  });

  const toggleArea = (a) => setFilters(f => ({ ...f, areas: f.areas.includes(a) ? f.areas.filter(x => x !== a) : [...f.areas, a] }));
  const toggleStatus = (s) => setFilters(f => ({ ...f, status: f.status.includes(s) ? f.status.filter(x => x !== s) : [...f.status, s] }));

  return (
    <div className="frame scroll-y" style={{ background: 'var(--bone)' }}>
      <Topbar active="projects" onNav={goto}/>

      {/* ── Header strip ── */}
      <div style={{ padding: '32px 40px 20px', borderBottom: '1px solid var(--line-soft)', background: 'var(--paper-warm)' }}>
        <div style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between', marginBottom: 18 }}>
          <div>
            <span className="t-eyebrow">Projects · New & off-plan</span>
            <h1 style={{ margin: '8px 0 0', fontFamily: 'var(--font-display)', fontSize: 44, letterSpacing: '-0.02em', lineHeight: 1.05, fontWeight: 400 }}>
              {filtered.length} projects across <em style={{ fontStyle: 'italic' }}>Pattaya</em>
            </h1>
          </div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <span className="seg">
              <button className={view === 'grid' ? 'is-active' : ''} onClick={() => setView('grid')}><I.grid size={14} style={{ display: 'inline', verticalAlign: -3, marginRight: 4 }}/> Grid</button>
              <button className={view === 'split' ? 'is-active' : ''} onClick={() => setView('split')}><I.list size={14} style={{ display: 'inline', verticalAlign: -3, marginRight: 4 }}/> Split</button>
              <button className={view === 'map' ? 'is-active' : ''} onClick={() => setView('map')}><I.map size={14} style={{ display: 'inline', verticalAlign: -3, marginRight: 4 }}/> Map</button>
            </span>
            <select className="select" value={sort} onChange={(e) => setSort(e.target.value)} style={{ width: 200, height: 38 }}>
              <option value="relevance">Sort: Most relevant</option>
              <option value="price-asc">Price · low to high</option>
              <option value="price-desc">Price · high to low</option>
              <option value="yield">Yield · highest</option>
              <option value="completion">Soonest completion</option>
            </select>
          </div>
        </div>

        {/* Inline filter chips */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="tag tag-paper" style={{ height: 32, padding: '0 12px' }}><I.filter size={13}/> Filters</span>
          <Chip label="Area" onClick={() => {}}/>
          <Chip label="Bedrooms" onClick={() => {}}/>
          <Chip label="Status" active={filters.status.length > 0}/>
          <Chip label="Price"/>
          <Chip label="Yield ≥ 6%"/>
          <Chip label="Foreign quota available"/>
          <Chip label="Beachfront"/>
          <Chip label="Completion year"/>
          {compare.length > 0 && (
            <span className="tag tag-dark" style={{ height: 32, padding: '0 12px', marginLeft: 'auto' }}>
              <I.compare size={12}/> {compare.length} to compare
            </span>
          )}
        </div>
      </div>

      {/* ── Main layout ── */}
      <div style={{ display: 'grid', gridTemplateColumns: view === 'grid' ? '288px 1fr' : view === 'map' ? '288px 1fr' : '288px 1.2fr 1.4fr', gap: 0, alignItems: 'start' }}>
        {/* Sidebar filters */}
        <aside style={{ padding: '28px 24px', borderRight: '1px solid var(--line-soft)', position: 'sticky', top: 65 }}>
          <FilterGroup title="Price (฿M)">
            <div style={{ padding: '8px 4px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 12 }}>
                <span style={{ color: 'var(--ink-3)' }}>0M</span>
                <span style={{ color: 'var(--ink)', fontWeight: 500 }} className="t-mono">฿{filters.priceMax}M+</span>
              </div>
              <input type="range" min="2" max="60" value={filters.priceMax}
                onChange={(e) => setFilters(f => ({ ...f, priceMax: +e.target.value }))}
                style={{ width: '100%', accentColor: 'var(--teal)' }}/>
            </div>
          </FilterGroup>
          <FilterGroup title="Area">
            {['Wongamat', 'Pratumnak Hill', 'Central Pattaya', 'Jomtien', 'Na Jomtien', 'Bang Saray'].map(a => (
              <FilterRow key={a} label={a} count={Math.floor(Math.random() * 20) + 5} on={filters.areas.includes(a)} onClick={() => toggleArea(a)}/>
            ))}
          </FilterGroup>
          <FilterGroup title="Status">
            {[['presale', 'Pre-sale'], ['construction', 'Under construction'], ['ready', 'Ready to move']].map(([k, l]) => (
              <FilterRow key={k} label={l} count={PROJECTS.filter(p => p.statusKey === k).length} on={filters.status.includes(k)} onClick={() => toggleStatus(k)}/>
            ))}
          </FilterGroup>
          <FilterGroup title="Bedrooms">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
              {['Studio', '1', '2', '3', '4', '5+'].slice(0, 4).map(b => (
                <button key={b} className="btn btn-sm btn-ghost" style={{ height: 32, padding: 0 }}>{b}</button>
              ))}
            </div>
          </FilterGroup>
          <FilterGroup title="Distance to beach">
            {[['any', 'Any'], ['front', 'Beachfront'], ['100', 'Under 100m'], ['500', 'Under 500m']].map(([k, l]) => (
              <FilterRow key={k} label={l} radio on={filters.beach === k} onClick={() => setFilters(f => ({ ...f, beach: k }))}/>
            ))}
          </FilterGroup>
          <FilterGroup title="Foreign quota">
            <FilterRow label="Foreign-quota available" count="" on/>
            <FilterRow label="Already capped at 49%" count=""/>
          </FilterGroup>
          <button className="btn btn-ghost btn-block btn-sm" style={{ marginTop: 12 }}>Reset all filters</button>
        </aside>

        {/* List */}
        {view !== 'map' && (
          <div style={{ padding: '28px 24px', display: 'grid', gridTemplateColumns: view === 'split' ? '1fr' : 'repeat(2, 1fr)', gap: 16, alignContent: 'start' }}>
            {filtered.map(p => (
              view === 'split' ? (
                <ListingRow key={p.id} p={p} hover={hover === p.id} onHover={(h) => setHover(h ? p.id : null)} onClick={() => goto && goto('project', p.id)} currency={currency} compareOn={compare.includes(p.id)} onCompare={() => toggleCompare(p.id)} savedOn={shortlist.includes(p.id)} onSave={() => toggleShortlist(p.id)}/>
              ) : (
                <div key={p.id} style={{ position: 'relative' }}>
                  <ProjectCard project={p} onClick={() => goto && goto('project', p.id)}/>
                  <button onClick={() => toggleCompare(p.id)} className="btn btn-sm" style={{ position: 'absolute', bottom: 18, right: 18, background: compare.includes(p.id) ? 'var(--ink)' : 'var(--paper)', color: compare.includes(p.id) ? 'var(--bone)' : 'var(--ink)', border: '1px solid var(--line)', height: 32 }}>
                    <I.compare size={12}/> Compare
                  </button>
                </div>
              )
            ))}
          </div>
        )}

        {/* Map */}
        {view !== 'grid' && (
          <div style={{ position: 'sticky', top: 65, height: 'calc(100vh - 65px)', minHeight: 800 }}>
            <MapPanel projects={filtered} highlightId={hover} onPick={(id) => goto && goto('project', id)} currency={currency}/>
          </div>
        )}
      </div>

      {/* Compare floating bar */}
      {compare.length > 0 && (
        <div style={{ position: 'sticky', bottom: 20, padding: '0 40px', zIndex: 30 }}>
          <div style={{ background: 'var(--ink)', color: 'var(--bone)', padding: '14px 22px', borderRadius: 16, display: 'flex', alignItems: 'center', gap: 16, boxShadow: 'var(--shadow-lg)' }}>
            <I.compare size={18}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500 }}>{compare.length} project{compare.length > 1 ? 's' : ''} selected to compare</div>
              <div style={{ fontSize: 11.5, color: 'rgba(248,244,234,.6)' }}>Add up to 4 · {compare.map(id => PROJECTS.find(p => p.id === id)?.name).join(' · ')}</div>
            </div>
            <button onClick={() => goto && goto('compare')} disabled={compare.length < 2} className="btn btn-sm" style={{ background: 'var(--coral)', color: '#fff', opacity: compare.length < 2 ? 0.6 : 1 }}>Compare now <I.arrowR size={14}/></button>
          </div>
        </div>
      )}

      <Footer/>
    </div>
  );
}

function Chip({ label, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      height: 32, padding: '0 12px', borderRadius: 999,
      border: '1px solid ' + (active ? 'var(--ink)' : 'var(--line)'),
      background: active ? 'var(--ink)' : 'var(--paper)',
      color: active ? 'var(--bone)' : 'var(--ink-2)',
      fontSize: 13, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6,
    }}>
      {label}
      <I.chevD size={11}/>
    </button>
  );
}

function FilterGroup({ title, children }) {
  return (
    <div style={{ marginBottom: 22, paddingBottom: 16, borderBottom: '1px solid var(--line-soft)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <h4 style={{ margin: 0, fontSize: 13, fontWeight: 500, letterSpacing: '0.02em' }}>{title}</h4>
        <I.chevU size={14} color="var(--ink-4)"/>
      </div>
      {children}
    </div>
  );
}

function FilterRow({ label, count, on, onClick, radio }) {
  return (
    <label onClick={onClick} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 4px', cursor: 'pointer', fontSize: 13 }}>
      <span style={{
        width: 16, height: 16,
        borderRadius: radio ? '50%' : 4,
        border: '1.4px solid ' + (on ? 'var(--ink)' : 'var(--line)'),
        background: on && !radio ? 'var(--ink)' : 'var(--paper)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        color: 'var(--bone)',
      }}>
        {on && !radio && <I.check size={11} strokeWidth={2.2}/>}
        {on && radio && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--ink)' }}/>}
      </span>
      <span style={{ flex: 1 }}>{label}</span>
      {count !== '' && count !== undefined && <span style={{ fontSize: 11, color: 'var(--ink-4)' }}>{count}</span>}
    </label>
  );
}

// Split-row listing
function ListingRow({ p, hover, onHover, onClick, currency, compareOn, onCompare, savedOn, onSave }) {
  return (
    <article
      onMouseEnter={() => onHover && onHover(true)}
      onMouseLeave={() => onHover && onHover(false)}
      onClick={onClick}
      className="lift"
      style={{
        background: 'var(--paper)',
        border: '1px solid ' + (hover ? 'var(--ink)' : 'var(--line-soft)'),
        borderRadius: 14,
        overflow: 'hidden',
        display: 'grid', gridTemplateColumns: '260px 1fr',
        cursor: 'pointer',
      }}>
      <div className="photo" style={{ height: 200 }}>
        <img src={p.cover} alt={p.name}/>
        {p.tag && <span className={`tag tag-${p.tagTone}`} style={{ position: 'absolute', top: 10, left: 10 }}>{p.tag}</span>}
      </div>
      <div style={{ padding: 20, display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'start', justifyContent: 'space-between', gap: 10 }}>
          <div>
            <h3 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.01em', fontWeight: 400 }}>{p.name}</h3>
            <p style={{ margin: '4px 0 0', fontSize: 12.5, color: 'var(--ink-4)' }}>
              <I.pin size={12} style={{ display: 'inline', verticalAlign: -2, marginRight: 4 }}/>
              {p.area} · {p.developer} · {p.completion}
            </p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: '-0.01em', lineHeight: 1 }}>
              {window.fmtPrice(p.startingPriceTHB, currency, { short: true })}
            </div>
            <span style={{ fontSize: 11, color: 'var(--ink-4)' }}>from</span>
          </div>
        </div>
        <p style={{ margin: '10px 0 14px', fontSize: 13, color: 'var(--ink-3)', lineHeight: 1.5 }}>{p.summary}</p>
        <div style={{ display: 'flex', gap: 14, fontSize: 12, color: 'var(--ink-3)', marginTop: 'auto' }}>
          <Spec icon={<I.bed size={13}/>} label={p.bedrooms.join(' · ')}/>
          <Spec icon={<I.trend size={13}/>} label={`${p.rentalYieldPct}% yield`}/>
          <Spec icon={<I.flag size={13}/>} label={`${p.foreignQuotaPct}%/49%`}/>
          <Spec icon={<I.wave size={13}/>} label={p.distance_beach_m ? `${p.distance_beach_m}m beach` : 'Beachfront'}/>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button onClick={(e) => { e.stopPropagation(); onClick && onClick(); }} className="btn btn-sm btn-paper">View details <I.arrowR size={12}/></button>
          <button onClick={(e) => { e.stopPropagation(); onCompare && onCompare(); }} className="btn btn-sm" style={{ background: compareOn ? 'var(--ink)' : 'transparent', color: compareOn ? 'var(--bone)' : 'var(--ink)', border: '1px solid var(--line)' }}><I.compare size={12}/> Compare</button>
          <button onClick={(e) => { e.stopPropagation(); onSave && onSave(); }} className="btn btn-sm btn-ghost" style={{ marginLeft: 'auto', color: savedOn ? 'var(--coral)' : 'var(--ink)' }}>{savedOn ? <I.heartFill size={12} color="var(--coral)"/> : <I.heart size={12}/>}</button>
        </div>
      </div>
    </article>
  );
}

function Spec({ icon, label }) {
  return <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>{icon}{label}</span>;
}

// Map panel
function MapPanel({ projects, highlightId, onPick, currency }) {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden' }}>
      <div className="map-bg" style={{ position: 'absolute', inset: 0 }}/>
      {/* Coastline shape (decorative) */}
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        <path d="M 65 -5 Q 70 30 60 50 Q 50 70 40 90 Q 30 105 0 100 L 100 105 L 105 -5 Z" fill="rgba(20,58,58,0.13)"/>
        <path d="M 65 0 Q 70 30 60 50 Q 50 70 40 90 Q 30 100 0 100" fill="none" stroke="rgba(20,58,58,0.18)" strokeWidth="0.3"/>
      </svg>

      {/* Map labels */}
      <div style={{ position: 'absolute', left: '8%', top: '20%', fontSize: 11, color: 'rgba(20,32,31,.4)', fontWeight: 500, letterSpacing: '0.12em' }}>GULF OF THAILAND</div>
      <div style={{ position: 'absolute', right: '8%', top: '6%', fontSize: 11, color: 'rgba(20,32,31,.4)', fontWeight: 500, letterSpacing: '0.1em' }}>SUKHUMVIT RD</div>
      <div style={{ position: 'absolute', right: '8%', bottom: '8%', fontSize: 11, color: 'rgba(20,32,31,.4)', fontWeight: 500 }}>U-TAPAO AIRPORT</div>

      {/* Pins */}
      {projects.map(p => {
        const active = highlightId === p.id;
        return (
          <button key={p.id} onClick={() => onPick && onPick(p.id)}
            style={{
              position: 'absolute', left: `${p.coords.x}%`, top: `${p.coords.y}%`,
              transform: `translate(-50%, -100%) scale(${active ? 1.1 : 1})`,
              transformOrigin: 'bottom center',
              padding: 0, border: 0, background: 'transparent', cursor: 'pointer',
              transition: 'transform .2s',
              zIndex: active ? 10 : 1,
            }}>
            <div style={{
              background: active ? 'var(--coral)' : 'var(--ink)',
              color: '#fff',
              padding: '6px 10px',
              borderRadius: 999,
              fontSize: 12, fontWeight: 500, fontFamily: 'var(--font-mono)',
              whiteSpace: 'nowrap',
              boxShadow: active ? '0 8px 20px rgba(217,106,78,.4)' : '0 2px 8px rgba(0,0,0,.18)',
            }}>
              {window.fmtPrice(p.startingPriceTHB, currency, { short: true })}
            </div>
            <div style={{ width: 0, height: 0, borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '6px solid ' + (active ? 'var(--coral)' : 'var(--ink)'), margin: '0 auto' }}/>
          </button>
        );
      })}

      {/* Hover card */}
      {highlightId && (() => {
        const p = projects.find(x => x.id === highlightId);
        if (!p) return null;
        return (
          <div style={{
            position: 'absolute', left: `${p.coords.x}%`, top: `${p.coords.y - 5}%`,
            transform: 'translate(-50%, -100%)',
            width: 240, marginTop: -20,
            background: 'var(--paper)', borderRadius: 12, overflow: 'hidden',
            boxShadow: 'var(--shadow-lg)', border: '1px solid var(--line-soft)',
            pointerEvents: 'none',
          }}>
            <div style={{ height: 100, background: `url(${p.cover}) center/cover` }}/>
            <div style={{ padding: '10px 14px' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>{p.name}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{p.area} · {window.fmtPrice(p.startingPriceTHB, currency, { short: true })}</div>
            </div>
          </div>
        );
      })()}

      {/* Map controls */}
      <div style={{ position: 'absolute', top: 20, right: 20, display: 'flex', flexDirection: 'column', gap: 6 }}>
        <button style={mapBtnStyle}><I.plus size={16}/></button>
        <button style={mapBtnStyle}><I.minus size={16}/></button>
      </div>
      <div style={{ position: 'absolute', top: 20, left: 20 }}>
        <span className="tag tag-paper" style={{ padding: '6px 12px', height: 'auto', fontSize: 12 }}><I.layers size={12}/> Satellite</span>
      </div>
    </div>
  );
}

const mapBtnStyle = { width: 36, height: 36, borderRadius: 8, background: 'var(--paper)', border: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', boxShadow: 'var(--shadow-sm)' };

window.ProjectListing = ProjectListing;
