// ─────────────────────────────────────────────────────────────
// Data store: curated images, project data, shared state
// (shortlist, comparison, currency, locale, filters)
// All exposed on window for cross-file access.
// ─────────────────────────────────────────────────────────────

// Curated Unsplash photos. Real Pattaya / Thailand luxury condo imagery
// where available, modern interiors elsewhere. Hand-picked, not random.
const photo = (id, w = 1200) =>
  `https://images.unsplash.com/${id}?w=${w}&q=80&auto=format&fit=crop`;

const PHOTOS = {
  // Hero / cityscape
  pattaya_skyline: photo('photo-1565967511849-76a60a516170'),       // tropical skyline
  pattaya_beach:   photo('photo-1552465011-b4e21bf6e79a'),          // pattaya / tropical beach
  pattaya_aerial:  photo('photo-1528181304800-259b08848526'),       // aerial tropical
  bangkok_sky:     photo('photo-1508009603885-50cf7c579365'),       // bangkok skyline
  sunset_palms:    photo('photo-1500382017468-9049fed747ef'),       // sunset palms
  ocean_resort:    photo('photo-1540541338287-41700207dee6'),       // ocean villa pool

  // Condo exteriors
  condo_modern_1:  photo('photo-1545324418-cc1a3fa10c00'),
  condo_modern_2:  photo('photo-1582719508461-905c673771fd'),
  condo_modern_3:  photo('photo-1512917774080-9991f1c4c750'),
  condo_modern_4:  photo('photo-1600596542815-ffad4c1539a9'),
  condo_modern_5:  photo('photo-1600585154340-be6161a56a0c'),
  condo_modern_6:  photo('photo-1600210492486-724fe5c67fb0'),
  condo_modern_7:  photo('photo-1613977257363-707ba9348227'),
  condo_modern_8:  photo('photo-1567496898669-ee935f5f647a'),

  // Interiors
  interior_1:      photo('photo-1600607687939-ce8a6c25118c'),       // luxury kitchen
  interior_2:      photo('photo-1600566753190-17f0baa2a6c3'),       // modern living
  interior_3:      photo('photo-1616594039964-ae9021a400a0'),       // bedroom
  interior_4:      photo('photo-1631679706909-1844bbd07221'),       // open plan
  interior_5:      photo('photo-1618221195710-dd6b41faaea6'),       // bedroom 2
  interior_6:      photo('photo-1560185007-cde436f6a4d0'),          // modern bath
  interior_7:      photo('photo-1556909114-f6e7ad7d3136'),          // living room
  interior_8:      photo('photo-1617806118233-18e1de247200'),       // dining

  // Amenities
  pool_1:          photo('photo-1571003123894-1f0594d2b5d9'),       // infinity pool
  pool_2:          photo('photo-1571896349842-33c89424de2d'),       // hotel pool
  gym:             photo('photo-1534438327276-14e5300c3a48'),       // gym
  lobby:           photo('photo-1564013799919-ab600027ffc6'),       // luxury lobby
  rooftop:         photo('photo-1542718610-a1d656d1884c'),          // rooftop terrace

  // People (agents)
  agent_1: photo('photo-1494790108377-be9c29b29330', 200),
  agent_2: photo('photo-1507003211169-0a1dd7228f2d', 200),
  agent_3: photo('photo-1573496359142-b8d87734a5a2', 200),
  agent_4: photo('photo-1500648767791-00dcc994a43e', 200),
  agent_5: photo('photo-1438761681033-6461ffad8d80', 200),

  // Misc
  beach_view:      photo('photo-1507525428034-b723cf961d3e'),       // beach view
  jomtien:         photo('photo-1552733407-5d5c46c3bb3b'),          // tropical
  na_jomtien:      photo('photo-1582610116397-edb318620f90'),       // coastal
  pratumnak:       photo('photo-1499793983690-e29da59ef1c2'),       // tropical aerial
  wongamat:        photo('photo-1545569341-9eb8b30979d9'),          // boat tropical
};

// Project catalog — 8 projects across Pattaya zones
const PROJECTS = [
  {
    id: 'amp-skyharbor',
    name: 'Skyharbor Residences',
    developer: 'AMP Property Group',
    area: 'Wongamat',
    coords: { x: 64, y: 22 },
    completion: 'Q4 2026',
    status: 'Under construction',
    statusKey: 'construction',
    units: 348,
    floors: 53,
    foreignQuotaPct: 32,    // % already taken of 49% allowed
    startingPriceTHB: 6_900_000,
    pricePerSqmTHB: 132_000,
    rentalYieldPct: 6.8,
    cover: PHOTOS.condo_modern_1,
    gallery: [PHOTOS.condo_modern_1, PHOTOS.pool_1, PHOTOS.interior_1, PHOTOS.lobby, PHOTOS.rooftop],
    distance_beach_m: 80,
    bedrooms: ['Studio', '1BR', '2BR', 'Penthouse'],
    tag: 'New launch',
    tagTone: 'coral',
    tagline: 'Beachfront living on Wongamat\u2019s last private cove.',
    summary: 'A 53-storey beachfront tower with private cove access, sky-lobby pools and direct beach walkway.',
    amenities: ['Infinity pool', 'Sky lobby', 'Private beach', 'Wellness floor', 'Co-work', 'EV charging'],
  },
  {
    id: 'amp-jomtien-bay',
    name: 'Jomtien Bay Tower',
    developer: 'Sansiri × AMP',
    area: 'Jomtien',
    coords: { x: 38, y: 64 },
    completion: 'Q2 2027',
    status: 'Pre-sale',
    statusKey: 'presale',
    units: 412,
    floors: 47,
    foreignQuotaPct: 18,
    startingPriceTHB: 3_950_000,
    pricePerSqmTHB: 98_000,
    rentalYieldPct: 7.4,
    cover: PHOTOS.condo_modern_2,
    gallery: [PHOTOS.condo_modern_2, PHOTOS.interior_2, PHOTOS.pool_2, PHOTOS.gym, PHOTOS.interior_3],
    distance_beach_m: 220,
    bedrooms: ['Studio', '1BR', '2BR'],
    tag: 'Best yield',
    tagTone: 'champagne',
    tagline: 'High-yield investor tower minutes from Beach Road.',
    summary: 'A scale investor-focused tower opposite Jomtien Beach with on-site rental management.',
    amenities: ['Rooftop pool', 'Co-living', 'Rental program', 'Smart locks', 'Pet-friendly'],
  },
  {
    id: 'amp-pratumnak-villas',
    name: 'Pratumnak Villas',
    developer: 'AMP Property Group',
    area: 'Pratumnak Hill',
    coords: { x: 52, y: 48 },
    completion: 'Ready to move',
    status: 'Completed',
    statusKey: 'ready',
    units: 14,
    floors: 3,
    foreignQuotaPct: 71,
    startingPriceTHB: 28_500_000,
    pricePerSqmTHB: 142_000,
    rentalYieldPct: 5.2,
    cover: PHOTOS.condo_modern_3,
    gallery: [PHOTOS.condo_modern_3, PHOTOS.interior_4, PHOTOS.ocean_resort, PHOTOS.interior_5],
    distance_beach_m: 380,
    bedrooms: ['3BR Villa', '4BR Villa'],
    tag: 'Move-in ready',
    tagTone: 'teal',
    tagline: 'Fourteen private hillside villas with full sea view.',
    summary: 'Limited collection of detached pool villas on Pratumnak Hill, all with unobstructed Gulf views.',
    amenities: ['Private pool', '24h security', 'Hillside garden', 'Servant quarters'],
  },
  {
    id: 'amp-na-jomtien',
    name: 'Na Jomtien Residence',
    developer: 'Property Perfect',
    area: 'Na Jomtien',
    coords: { x: 28, y: 78 },
    completion: 'Q1 2028',
    status: 'Pre-sale',
    statusKey: 'presale',
    units: 286,
    floors: 39,
    foreignQuotaPct: 8,
    startingPriceTHB: 4_500_000,
    pricePerSqmTHB: 105_000,
    rentalYieldPct: 6.9,
    cover: PHOTOS.condo_modern_4,
    gallery: [PHOTOS.condo_modern_4, PHOTOS.interior_6, PHOTOS.pool_1, PHOTOS.interior_7],
    distance_beach_m: 50,
    bedrooms: ['1BR', '2BR', '3BR'],
    tag: 'Early bird -12%',
    tagTone: 'coral',
    tagline: 'Direct beachfront access on the quieter southern coast.',
    summary: 'Beachfront low-rise on the quiet Na Jomtien stretch, ten minutes south of central Pattaya.',
    amenities: ['Beachfront', 'Infinity pool', 'Spa', 'Tennis', 'Kids club'],
  },
  {
    id: 'amp-central-marina',
    name: 'Central Marina Suites',
    developer: 'AP Thailand',
    area: 'Central Pattaya',
    coords: { x: 50, y: 38 },
    completion: 'Q3 2026',
    status: 'Under construction',
    statusKey: 'construction',
    units: 530,
    floors: 45,
    foreignQuotaPct: 41,
    startingPriceTHB: 2_980_000,
    pricePerSqmTHB: 89_000,
    rentalYieldPct: 8.1,
    cover: PHOTOS.condo_modern_5,
    gallery: [PHOTOS.condo_modern_5, PHOTOS.interior_8, PHOTOS.lobby, PHOTOS.gym],
    distance_beach_m: 450,
    bedrooms: ['Studio', '1BR'],
    tag: 'Highest yield',
    tagTone: 'champagne',
    tagline: 'Walking distance to Beach Road, Terminal 21, and the pier.',
    summary: 'Compact investor units in the centre of Pattaya, perfect for short-stay rental.',
    amenities: ['Sky pool', 'Co-work', 'Rental pool', 'Concierge'],
  },
  {
    id: 'amp-bangsare-view',
    name: 'Bang Saray View',
    developer: 'Origin Property',
    area: 'Bang Saray',
    coords: { x: 22, y: 88 },
    completion: 'Q4 2027',
    status: 'Pre-sale',
    statusKey: 'presale',
    units: 198,
    floors: 32,
    foreignQuotaPct: 4,
    startingPriceTHB: 3_200_000,
    pricePerSqmTHB: 92_000,
    rentalYieldPct: 6.4,
    cover: PHOTOS.condo_modern_6,
    gallery: [PHOTOS.condo_modern_6, PHOTOS.interior_1, PHOTOS.pool_2],
    distance_beach_m: 120,
    bedrooms: ['1BR', '2BR'],
    tag: 'Quiet zone',
    tagTone: 'teal',
    tagline: 'Quiet seaside escape, twenty minutes south.',
    summary: 'A boutique tower in the sleepy fishing village of Bang Saray, popular with retirees.',
    amenities: ['Beach club', 'Yoga deck', 'Library', 'Pet-friendly'],
  },
  {
    id: 'amp-skyline-plaza',
    name: 'Skyline Plaza Pattaya',
    developer: 'Sansiri',
    area: 'Central Pattaya',
    coords: { x: 56, y: 42 },
    completion: 'Ready to move',
    status: 'Completed',
    statusKey: 'ready',
    units: 612,
    floors: 56,
    foreignQuotaPct: 49,    // capped
    startingPriceTHB: 4_700_000,
    pricePerSqmTHB: 118_000,
    rentalYieldPct: 6.0,
    cover: PHOTOS.condo_modern_7,
    gallery: [PHOTOS.condo_modern_7, PHOTOS.interior_2, PHOTOS.rooftop],
    distance_beach_m: 200,
    bedrooms: ['Studio', '1BR', '2BR'],
    tag: 'Foreign quota full',
    tagTone: 'dark',
    tagline: 'Iconic 56-storey tower in the heart of Pattaya.',
    summary: 'Established luxury tower with proven rental returns and full amenity floor.',
    amenities: ['Sky pool', 'Cinema', 'Spa', 'Restaurant', 'Concierge'],
  },
  {
    id: 'amp-rayong-coast',
    name: 'Rayong Coast Villas',
    developer: 'AMP Property Group',
    area: 'Rayong',
    coords: { x: 12, y: 92 },
    completion: 'Q2 2027',
    status: 'Pre-sale',
    statusKey: 'presale',
    units: 22,
    floors: 2,
    foreignQuotaPct: 0,
    startingPriceTHB: 18_900_000,
    pricePerSqmTHB: 95_000,
    rentalYieldPct: 5.6,
    cover: PHOTOS.condo_modern_8,
    gallery: [PHOTOS.condo_modern_8, PHOTOS.interior_3],
    distance_beach_m: 0,
    bedrooms: ['3BR Villa', '4BR Villa'],
    tag: 'Beachfront villa',
    tagTone: 'champagne',
    tagline: 'Twenty-two private beachfront pool villas.',
    summary: 'Direct beachfront villa community an hour east of Pattaya.',
    amenities: ['Private beach', 'Pool villa', 'Concierge', 'Gym'],
  },
];

// Individual units / properties for resale + new
const PROPERTIES = [
  { id: 'u-001', projectId: 'amp-skyharbor',     unit: 'Tower A · 28-12', type: '2BR', bedrooms: 2, baths: 2, sqm: 84, priceTHB: 14_800_000, view: 'Sea view',     floor: 28, listed: '3 days ago',  cover: PHOTOS.condo_modern_1, hot: true },
  { id: 'u-002', projectId: 'amp-skyharbor',     unit: 'Tower B · 41-04', type: 'Penthouse', bedrooms: 3, baths: 3, sqm: 168, priceTHB: 39_500_000, view: 'Panoramic', floor: 41, listed: '1 week ago', cover: PHOTOS.interior_1, hot: true },
  { id: 'u-003', projectId: 'amp-jomtien-bay',   unit: 'Tower A · 18-22', type: '1BR', bedrooms: 1, baths: 1, sqm: 38, priceTHB: 4_650_000, view: 'Sea view',  floor: 18, listed: '2 days ago', cover: PHOTOS.interior_4 },
  { id: 'u-004', projectId: 'amp-jomtien-bay',   unit: 'Tower B · 09-14', type: 'Studio', bedrooms: 0, baths: 1, sqm: 28, priceTHB: 3_200_000, view: 'City',     floor: 9, listed: 'New',         cover: PHOTOS.interior_2 },
  { id: 'u-005', projectId: 'amp-pratumnak-villas', unit: 'Villa 06',     type: '3BR Villa', bedrooms: 3, baths: 4, sqm: 380, priceTHB: 32_500_000, view: 'Sea view', floor: 0, listed: '2 weeks ago', cover: PHOTOS.condo_modern_3, hot: true },
  { id: 'u-006', projectId: 'amp-central-marina', unit: 'Tower 1 · 22-08', type: 'Studio', bedrooms: 0, baths: 1, sqm: 26, priceTHB: 2_980_000, view: 'City',  floor: 22, listed: 'New', cover: PHOTOS.condo_modern_5 },
  { id: 'u-007', projectId: 'amp-skyline-plaza', unit: 'Tower 2 · 34-18', type: '2BR', bedrooms: 2, baths: 2, sqm: 76, priceTHB: 9_800_000, view: 'Sea & city', floor: 34, listed: '5 days ago', cover: PHOTOS.condo_modern_7 },
  { id: 'u-008', projectId: 'amp-na-jomtien',    unit: 'Tower A · 12-06', type: '2BR', bedrooms: 2, baths: 2, sqm: 68, priceTHB: 7_100_000, view: 'Pool',      floor: 12, listed: '1 day ago',  cover: PHOTOS.condo_modern_4 },
];

// Featured agents
const AGENTS = [
  { id: 'a1', name: 'Khun Apinya',  initials: 'AP', avatar: PHOTOS.agent_1, role: 'Senior Advisor',   lang: 'TH · EN', deals: 142, rating: 4.95 },
  { id: 'a2', name: 'Marcus Lee',   initials: 'ML', avatar: PHOTOS.agent_2, role: 'Investor Lead',    lang: 'EN · CN', deals: 88,  rating: 4.92 },
  { id: 'a3', name: 'Sasha Volkov', initials: 'SV', avatar: PHOTOS.agent_3, role: 'Russian-speaking', lang: 'RU · EN', deals: 64,  rating: 4.88 },
  { id: 'a4', name: 'Nattapong S.', initials: 'NS', avatar: PHOTOS.agent_4, role: 'Property Manager', lang: 'TH · EN', deals: 215, rating: 4.97 },
  { id: 'a5', name: 'Lin Wei',      initials: 'LW', avatar: PHOTOS.agent_5, role: 'Mandarin lead',    lang: 'CN · EN', deals: 53,  rating: 4.85 },
];

// Currencies
const CURRENCIES = {
  THB: { symbol: '฿',   rate: 1,         decimals: 0, locale: 'th-TH' },
  USD: { symbol: '$',   rate: 1 / 36,    decimals: 0, locale: 'en-US' },
  EUR: { symbol: '€',   rate: 1 / 39,    decimals: 0, locale: 'en-US' },
  CNY: { symbol: '¥',   rate: 1 / 5,     decimals: 0, locale: 'en-US' },
  RUB: { symbol: '₽',   rate: 1 / 0.4,   decimals: 0, locale: 'ru-RU' },
};

function fmtPrice(thb, currencyCode = 'THB', { short = false } = {}) {
  const c = CURRENCIES[currencyCode] || CURRENCIES.THB;
  const value = thb * c.rate;
  if (short) {
    if (value >= 1_000_000) return `${c.symbol}${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1)}M`;
    if (value >= 1_000) return `${c.symbol}${Math.round(value / 1_000)}k`;
    return `${c.symbol}${Math.round(value)}`;
  }
  return `${c.symbol}${Math.round(value).toLocaleString(c.locale)}`;
}

function fmtSqm(sqm) { return `${sqm.toLocaleString()} m²`; }

// Locales
const LOCALES = [
  { code: 'EN', name: 'English', flag: '🇬🇧' },
  { code: 'TH', name: 'ภาษาไทย', flag: '🇹🇭' },
  { code: 'RU', name: 'Русский', flag: '🇷🇺' },
  { code: 'CN', name: '中文', flag: '🇨🇳' },
];

// Areas
const AREAS = [
  { id: 'wongamat',  name: 'Wongamat',       count: 14, vibe: 'Quiet luxury, family',  beach: '5-star beaches', img: PHOTOS.wongamat },
  { id: 'pratumnak', name: 'Pratumnak Hill', count: 22, vibe: 'Hillside villas',        beach: 'Cosy Beach',     img: PHOTOS.pratumnak },
  { id: 'jomtien',   name: 'Jomtien',        count: 38, vibe: 'High-yield investor',    beach: 'Jomtien Beach',  img: PHOTOS.jomtien },
  { id: 'central',   name: 'Central Pattaya',count: 47, vibe: 'Urban, walk-to-everything', beach: 'Pattaya Beach', img: PHOTOS.pattaya_beach },
  { id: 'najomtien', name: 'Na Jomtien',     count: 19, vibe: 'Quiet beachfront',       beach: 'Na Jomtien',     img: PHOTOS.na_jomtien },
  { id: 'bangsare',  name: 'Bang Saray',     count: 11, vibe: 'Local fishing village',  beach: 'Bang Saray',     img: PHOTOS.beach_view },
];

// ─── App-wide shared state (React context lite)
const ShareCtx = React.createContext(null);

function ShareProvider({ children }) {
  const [shortlist, setShortlist] = React.useState(['amp-skyharbor', 'amp-jomtien-bay']);
  const [compare, setCompare] = React.useState([]);
  const [currency, setCurrency] = React.useState('THB');
  const [locale, setLocale] = React.useState('EN');

  const api = React.useMemo(() => ({
    shortlist, compare, currency, locale,
    setCurrency, setLocale,
    toggleShortlist: (id) => setShortlist(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]),
    toggleCompare:   (id) => setCompare(s => s.includes(id) ? s.filter(x => x !== id) : (s.length >= 4 ? s : [...s, id])),
    clearCompare:    () => setCompare([]),
  }), [shortlist, compare, currency, locale]);

  return <ShareCtx.Provider value={api}>{children}</ShareCtx.Provider>;
}

function useShare() { return React.useContext(ShareCtx); }

Object.assign(window, {
  PHOTOS, PROJECTS, PROPERTIES, AGENTS, CURRENCIES, LOCALES, AREAS,
  fmtPrice, fmtSqm,
  ShareProvider, ShareCtx, useShare,
});
